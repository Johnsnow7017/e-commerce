<?php
/**
 * This is core configuration file.
 *
 * Use it to configure core behavior of Cake.
 *
 * PHP versions 4 and 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)108.136
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       cake
 * @subpackage    cake.app.config
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */

/**
 * CakePHP Debug Level:
 *
 * Production Mode:
 * 	0: No error messages, errors, or warnings shown. Flash messages redirect.
 *
 * Development Mode:
 * 	1: Errors and warnings shown, model caches refreshed, flash messages halted.
 * 	2: As in 1, but also with full debug messages and SQL output.
 *
 * In production mode, flash messages redirect after a time interval.
 * In development mode, you need to click the flash message to continue.
 */
	Configure::write('debug', 2);

/**
 * CakePHP Log Level:
 *
 * In case of Production Mode CakePHP gives you the possibility to continue logging errors.
 *
 * The following parameters can be used:
 *  Boolean: Set true/false to activate/deactivate logging
 *    Configure::write('log', true);
 *
 *  Integer: Use built-in PHP constants to set the error level (see error_reporting)
 *    Configure::write('log', E_ERROR | E_WARNING);
 *    Configure::write('log', E_ALL ^ E_NOTICE);
 */
	Configure::write('log', true);

/**
 * Application wide charset encoding
 */
	Configure::write('App.encoding', 'UTF-8');

/**
 * To configure CakePHP *not* to use mod_rewrite and to
 * use CakePHP pretty URLs, remove these .htaccess
 * files:
 *
 * /.htaccess
 * /app/.htaccess
 * /app/webroot/.htaccess
 *
 * And uncomment the App.baseUrl below:
 */
	//Configure::write('App.baseUrl', env('SCRIPT_NAME'));

/**
 * Uncomment the define below to use CakePHP prefix routes.
 *
 * The value of the define determines the names of the routes
 * and their associated controller actions:
 *
 * Set to an array of prefixes you want to use in your application. Use for
 * admin or other prefixed routes.
 *
 * 	Routing.prefixes = array('admin', 'manager');
 *
 * Enables:
 *	`admin_index()` and `/admin/controller/index`
 *	`manager_index()` and `/manager/controller/index`
 *
 * [Note Routing.admin is deprecated in 1.3.  Use Routing.prefixes instead]
 */
	//Configure::write('Routing.prefixes', array('admin'));
    Configure::write('Routing.prefixes', array('admin'));
/**
 * Turn off all caching application-wide.
 *
 */
	//Configure::write('Cache.disable', true);

/**
 * Enable cache checking.
 *
 * If set to true, for view caching you must still use the controller
 * var $cacheAction inside your controllers to define caching settings.
 * You can either set it controller-wide by setting var $cacheAction = true,
 * or in each action using $this->cacheAction = true.
 *
 */
	//Configure::write('Cache.check', true);

/**
 * Defines the default error type when using the log() function. Used for
 * differentiating error logging and debugging. Currently PHP supports LOG_DEBUG.
 */
	define('LOG_ERROR', 2);

/**
 * The preferred session handling method. Valid values:
 *
 * 'php'	 		Uses settings defined in your php.ini.
 * 'cake'		Saves session files in CakePHP's /tmp directory.
 * 'database'	Uses CakePHP's database sessions.
 *
 * To define a custom session handler, save it at /app/config/<name>.php.
 * Set the value of 'Session.save' to <name> to utilize it in CakePHP.
 *
 * To use database sessions, run the app/config/schema/sessions.php schema using
 * the cake shell command: cake schema create Sessions
 *
 */
	//Configure::write('Session.save', 'php');
        Configure::write('Session.save', 'database');
        
/**
 * The model name to be used for the session model.
 *
 * 'Session.save' must be set to 'database' in order to utilize this constant.
 *
 * The model name set here should *not* be used elsewhere in your application.
 */
	Configure::write('Session.model', 'Session');

/**
 * The name of the table used to store CakePHP database sessions.
 *
 * 'Session.save' must be set to 'database' in order to utilize this constant.
 *
 * The table name set here should *not* include any table prefix defined elsewhere.
 *
 * Please note that if you set a value for Session.model (above), any value set for
 * Session.table will be ignored.
 *
 * [Note: Session.table is deprecated as of CakePHP 1.3]
 */
	Configure::write('Session.table', 'sessions');

/**
 * The DATABASE_CONFIG::$var to use for database session handling.
 *
 * 'Session.save' must be set to 'database' in order to utilize this constant.
 */
	//Configure::write('Session.database', 'default');

/**
 * The name of CakePHP's session cookie.
 *
 * Note the guidelines for Session names states: "The session name references
 * the session id in cookies and URLs. It should contain only alphanumeric
 * characters."
 * @link http://php.net/session_name
 */
	Configure::write('Session.cookie', 'CAKEPHP');

/**
 * Session time out time (in seconds).
 * Actual value depends on 'Security.level' setting.
 */
	Configure::write('Session.timeout', '120');

/**
 * If set to false, sessions are not automatically started.
 */
	Configure::write('Session.start', true);

/**
 * When set to false, HTTP_USER_AGENT will not be checked
 * in the session. You might want to set the value to false, when dealing with
 * older versions of IE, Chrome Frame or certain web-browsing devices and AJAX
 */
	Configure::write('Session.checkAgent', false);

/**
 * The level of CakePHP security. The session timeout time defined
 * in 'Session.timeout' is multiplied according to the settings here.
 * Valid values:
 *
 * 'high'   Session timeout in 'Session.timeout' x 10
 * 'medium' Session timeout in 'Session.timeout' x 100
 * 'low'    Session timeout in 'Session.timeout' x 300
 *
 * CakePHP session IDs are also regenerated between requests if
 * 'Security.level' is set to 'high'.
 */
	Configure::write('Security.level', 'medium');

/**
 * A random string used in security hashing methods.
 */
	Configure::write('Security.salt', 'DYhG93b0qyJfIxxfs2guVoUubWwvPiR2G0FgaC9mi');

/**
 * A random numeric string (digits only) used to encrypt/decrypt strings.
 */
	Configure::write('Security.cipherSeed', '7685930965324237453542P496749683645');

/**
 * Apply timestamps with the last modified time to static assets (js, css, images).
 * Will append a querystring parameter containing the time the file was modified. This is
 * useful for invalidating browser caches.
 *
 * Set to `true` to apply timestamps when debug > 0. Set to 'force' to always enable
 * timestamping regardless of debug value.
 */
	//Configure::write('Asset.timestamp', true);
/**
 * Compress CSS output by removing comments, whitespace, repeating tags, etc.
 * This requires a/var/cache directory to be writable by the web server for caching.
 * and /vendors/csspp/csspp.php
 *
 * To use, prefix the CSS link URL with '/ccss/' instead of '/css/' or use HtmlHelper::css().
 */
	//Configure::write('Asset.filter.css', 'css.php');

/**
 * Plug in your own custom JavaScript compressor by dropping a script in your webroot to handle the
 * output, and setting the config below to the name of the script.
 *
 * To use, prefix your JavaScript link URLs with '/cjs/' instead of '/js/' or use JavaScriptHelper::link().
 */
	//Configure::write('Asset.filter.js', 'custom_javascript_output_filter.php');

/**
 * The classname and database used in CakePHP's
 * access control lists.
 */
	Configure::write('Acl.classname', 'DbAcl');
	Configure::write('Acl.database', 'default');

/**
 * If you are on PHP 5.3 uncomment this line and correct your server timezone
 * to fix the date & time related errors.
 */
	date_default_timezone_set('Asia/Kolkata');

/**
 *
 * Cache Engine Configuration
 * Default settings provided below
 *
 * File storage engine.
 *
 * 	 Cache::config('default', array(
 *		'engine' => 'File', //[required]
 *		'duration'=> 3600, //[optional]
 *		'probability'=> 100, //[optional]
 * 		'path' => CACHE, //[optional] use system tmp directory - remember to use absolute path
 * 		'prefix' => 'cake_', //[optional]  prefix every cache file with this string
 * 		'lock' => false, //[optional]  use file locking
 * 		'serialize' => true, [optional]
 *	));
 *
 *
 * APC (http://pecl.php.net/package/APC)
 *
 * 	 Cache::config('default', array(
 *		'engine' => 'Apc', //[required]
 *		'duration'=> 3600, //[optional]
 *		'probability'=> 100, //[optional]
 * 		'prefix' => Inflector::slug(APP_DIR) . '_', //[optional]  prefix every cache file with this string
 *	));
 *
 * Xcache (http://xcache.lighttpd.net/)
 *
 * 	 Cache::config('default', array(
 *		'engine' => 'Xcache', //[required]
 *		'duration'=> 3600, //[optional]
 *		'probability'=> 100, //[optional]
 * 		'prefix' => Inflector::slug(APP_DIR) . '_', //[optional] prefix every cache file with this string
 *		'user' => 'user', //user from xcache.admin.user settings
 *      'password' => 'password', //plaintext password (xcache.admin.pass)
 *	));
 *
 *
 * Memcache (http://www.danga.com/memcached/)
 *
 * 	 Cache::config('default', array(
 *		'engine' => 'Memcache', //[required]
 *		'duration'=> 3600, //[optional]
 *		'probability'=> 100, //[optional]
 * 		'prefix' => Inflector::slug(APP_DIR) . '_', //[optional]  prefix every cache file with this string
 * 		'servers' => array(
 * 			'127.0.0.1:11211' // localhost, default port 11211
 * 		), //[optional]
 * 		'compress' => false, // [optional] compress data in Memcache (slower, but uses less memory)
 * 		'persistent' => true, // [optional] set this to false for non-persistent connections
 *	));
 *
 */
    Cache::config('default', array('engine' => 'File'));

    Configure::write('SHORT_SITE_TITLE', 'Samsung');

    Configure::write('MAIL_SYSTEM', 'smtp');
    Configure::write('SMTP_TIMEOUT', 15);
    Configure::write('SMTP_PORT', 25);
    Configure::write('SMTP_HOST', 'smtp.samsung.com');
    Configure::write('SMTP_USERNAME', 'mkt.india');
    Configure::write('SMTP_PASSWORD', 'abc135');
    Configure::write('FROM_EMAIL', 'Samsung <amreek.s@samsung.com>');


    Configure::write('Default_Timezone', '49');
    Configure::write('Default_Country', '99');
    Configure::write('Default_Currency', '5');

    include('auditlog.php');
    include('notificationlog.php');
    
    Configure::write("systemURL", "http://localhost:82/");
    Configure::write("URLDomPdf", "http://localhost:82/");
    Configure::write("URLforActions", "http://localhost:82/");
	
    Configure::write("buyerHost", "localhost:82"); //Without slash at end
    Configure::write("supplierHost", "localhost:82"); //Without slash at end
    Configure::write("buyerURL", "http://localhost:82"); //Without slash at end
    Configure::write("supplierURL", "http://localhost:82"); //Without slash at end
    Configure::write("URLDomPdf", "http://localhost:82"); //Without slash at end
    Configure::write("BASE_PATH", "E:/lokesh/eproc_dev/app/webroot/img/");
    Configure::write('Document_Path', "E:/lokesh/eproc_dev/app/webroot/files/");
    
    //FTP Details for Uploading file on FTP
    Configure::write('FTP_HOST', "107.110.101.148");
    Configure::write('FTP_USER', "ftpuser");
    Configure::write('FTP_PASS', "sdsi@12345");
    Configure::write('FTP_PATH',"/");
    

    // Actions
    Configure::write('ApproveRequestToView', '1'); //Buyer
    Configure::write('ApproveRequestToUnsubmit', '2'); //Buyer
    Configure::write('ClosureOfOverdue', '3'); //Buyer
    Configure::write('RepublishRfx', '8'); //Buyer

    Configure::write('InvitedSupplier', '4'); //Supplier
    Configure::write('ViewGranted', '5'); //Supplier
    Configure::write('UnsubmitGranted', '6'); //Supplier
    Configure::write('RepublishRFPSubmitAgain', '9'); //Supplier
    Configure::write('Submit', '10'); //Supplier


    Configure::write('RepublishAuction', '11'); //Buyer
    Configure::write('InvitedSupplierAuction', '12'); //Supplier
    // Actions Type related to rfx_action_related_msg table
    Configure::write('RequestToView', 'Request_to_view');

    Configure::write('DefaultUOM', 97);

    Configure::write('ChangeInRfx', '7');
    Configure::write('fileid', '33');
    ini_set('default_socket_timeout', 240);

    /*** Difference between two consecutive placed bid (Seconds) */
    Configure::write('BidPlaceDifference', 30);
    
    Configure::write('AllowedFileType', array('doc','png','jpg','pdf','docx','jpeg','gif','png', 'ppt', 'pptx', 'csv', 'xlsx', 'xls','DOC','PNG','JPG','PDF','DOCX','JPEG','GIF','PNG', 'PPT', 'PPTX', 'CSV', 'XLSX', 'XLS', 'dwg', 'DWG'));
    Configure::write('AllowFileSize' , 10 ); // MB size
    Configure::write('AllowSpecialChar' , array(" ", ">", "<", "@", "-", "_", "!", "#", "$", "%", ".", "'", ";", ":", "/",  "\"",  "|", "[", "]", "{", "}", "*", "&", "(", ")", "^", "%", "?", ",", "+", "=", "\n", "\r")); // MB size
    
    Configure::write('Attachement_Source', "FILES");
    Configure::write('ATTACHMENT_LIMIT', '50');
	
	Configure::write('MsgAllowFileSize' , 10 ); // MB size
    Configure::write('MsgAllowAttachLimit' , 5 ); // MB size

    Configure::write('IPCHECK' , false);
    Configure::write('IPCHECKRANGE' , array(""));
	
	
	Configure::write('ApproveSupplier', '13');
    Configure::write('ApproveRfx', '14');
    Configure::write('Default_Type', '1');
	
	Configure::write('ApproveRfx', '14');
	Configure::write('ApproveAuction', '15');
	Configure::write('TechnicalEvaluate', '16'); //Create Action for technical evaluator   
	Configure::write('CommercialEvaluate', '17'); //Create Action for Commercial evaluator
	Configure::write('DeleteTechEvaluator', '18'); //Buyer
	Configure::write('TechnicalReevaluate', '19'); //Create Action for Reevaluation to technical evaluator
	Configure::write('AuditEvent', '20');
	
	Configure::write('PageLimit' , 20 );
	Configure::write('CacheDB', false);
	
	Configure::write('BeforeDeadline' , 30); // MB size
Configure::write('PR_ENABLE', false);
Configure::write('Extra_Amount' , 'Roundoff Adjustment');
Configure::write('EMAIL_FECTH_LIMIT' , 10);
Configure::write('ESBAuthVO', array("cID" => "C10ML0986", "cPW" => "C10ML0986013489"));
Configure::write('SoapClient','http://wsstage.samsung.net/sibws/wsdl/WSGWBus/MLSendService');
Configure::write("senderMailAddr" , "pmt.rfx@stage.samsung.com");
     //Time interval at which live bidding time updates in live bidding view table
                Configure::write("LIVE_BIDDING_UPDATE_TIME", 15); //In Seconds
Configure::write('SoapClientPmg','http://test01.swa-portals.com/PMGSystem/ESBeProcurementBridge1.svc?wsdl');//PMG URL

Configure::write('AllowedMIMEType', array('application/octet-stream','Composite Document File V2 Document, No summary info','application/msword','image/png','image/jpeg','image/pjpeg','application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','image/gif','application/mspowerpoint','application/powerpoint','application/vnd.ms-powerpoint','application/x-mspowerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation', 'text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel','image/vnd.dwg','application/x-font-ttf'));

Configure::write('FileUploadErrorMsg','File uploading failed!!Access denied or Content type not allowed.');//File upload error message
 Configure::write('COMPANY_ALLOWED_ACCESS' , array('1','2669','91'));
 Configure::write('AUTO_GENERATE_MPID_COMPANY' , array('ORX'=>'2673','CHE'=>'2674'));
 Configure::write('FileImageType',array('png', 'jpg', 'jpeg','gif'));
  
  Configure::write('ORX_CHEIL_SUP_ID' , '2674,2675');
  Configure::write('orx_company_name' , 'sup3');
  Configure::write('cheil_company_name' , 'sup4');
  
  Configure::write('SoapMPRStatus','http://test01.swa-portals.com/PMGService/Service1.svc?wsdl');//MPR status URl
  
  Configure::write('SoapMPRStatus','http://107.110.101.146:8003/PMGService/Service1.svc?wsdl');//MPR status URl

Configure::write('Level3Category' , '410');
Configure::write('ApprovePo', '24');    
Configure::write('LOADSTER_COMPANY' , '2671');


//Configure::write('LOADSTER_COMPANY' , '2667'); for test





//commented as not On prod

//Configure::write('EmpSearchSoap','http://wsstage.samsung.net/sibws/wsdl/WSGWBus/EmpService');//Emp Search
//Configure::write('EmpSearchAuth', array("cID" => "C10LD0890", "cPW" => "C10LD0890235789")); //Emp search Auth
//Configure::write('SubmitApprovalSoap','http://wsstage.samsung.net/sibws/wsdl/WSGWBus/APSubmitService');//Approval Submit
//Configure::write('EmpSubmitAuth', array("cID" => "C10AP0913", "cPW" => "C10AP0913145789")); //Submit Approval Auth
//Configure::write('GetApprovalStatusSoap','http://wsstage.samsung.net/sibws/wsdl/WSGWBus/APStatusInquiryService');//Approval status check
//Configure::write('CostApprovalContractValues' , array('0'=>'Select contract value','<50 L'=>'<50 L','50 L - 70 L'=>'50 L - 70 L','>70 L'=>'>70 L'));
//Configure::write('CFOUserIdsForCostApprovalMapping' , array('215','216'));






//Configure::write('CFOUserIdsForCostApprovalMapping' , array('100','112')); for dev
