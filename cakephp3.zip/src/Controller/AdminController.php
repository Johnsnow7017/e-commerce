<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure\Engine\PhpConfig;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use App\Core\Setting;
use Cake\Core\App;
use Cake\Validation\Validator;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;

//use App\Model\Entity\Category;

class AdminController extends AppController {
    //var $helpers = array('DateFormat');
//public $helpers = array('DateFormat');
    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
        
    }
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('login','addUser');
    }
    public function shop() {
        
    }
    
    public function blog() {
        
    }

    public function blogSingle() {
        
    }

    public function cart() {
        
    }

    public function checkout() {
        
    }

    public function contactUs() {
        
    }

    public function error() {
        
    }

    public function index() {
        $this->viewBuilder()->layout('admin');
    }

    public function index2() {
         $this->viewBuilder()->layout('admin');
        
    }

    public function index3() {
         $this->viewBuilder()->layout('admin');
        
    }

    public function calendar() {
        $this->viewBuilder()->layout('admin');
    }

    public function chartjs() {
        $this->viewBuilder()->layout('admin');
    }

    public function chartjs2() {
        $this->viewBuilder()->layout('admin');
    }

    public function contacts() {
        $this->viewBuilder()->layout('admin');
    }

    public function eCommerce() {
        $this->viewBuilder()->layout('admin');
    }

    public function echarts() {
        $this->viewBuilder()->layout('admin');
    }

    public function fixed_footer() {
        $this->viewBuilder()->layout('admin');
    }

    public function fixed_sidebar() {
        $this->viewBuilder()->layout('admin');
    }

    public function form() {
        $this->viewBuilder()->layout('admin');
    }

    public function formAdvanced() {
        $this->viewBuilder()->layout('admin');
    }

    public function formButtons() {
        $this->viewBuilder()->layout('admin');
    }

    public function formUpload() {
        $this->viewBuilder()->layout('admin');
    }

    public function formValidation() {
        $this->viewBuilder()->layout('admin');
    }

    public function formWizards() {
        $this->viewBuilder()->layout('admin');
    }

    public function general_elements() {
        $this->viewBuilder()->layout('admin');
    }

    public function glyphicons() {
        $this->viewBuilder()->layout('admin');
    }

    public function icons() {
        $this->viewBuilder()->layout('admin');
    }

    public function inbox() {
        $this->viewBuilder()->layout('admin');
    }

    public function invoice() {
        $this->viewBuilder()->layout('admin');
    }

    public function level2() {
        $this->viewBuilder()->layout('admin');
    }

    

    public function map() {
        $this->viewBuilder()->layout('admin');
    }

    public function media_gallery() {
        $this->viewBuilder()->layout('admin');
    }

    public function morisjs() {
        $this->viewBuilder()->layout('admin');
    }

    public function other_charts() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_403() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_404() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_500() {
        $this->viewBuilder()->layout('admin');
    }

    public function plain_page() {
        $this->viewBuilder()->layout('admin');
    }

    public function pricing_tables() {
        $this->viewBuilder()->layout('admin');
    }

    public function profile() {
        $this->viewBuilder()->layout('admin');
    }

    public function projectDetail() {
        $this->viewBuilder()->layout('admin');
    }

    public function projects() {
        $this->viewBuilder()->layout('admin');
    }

    public function tables() {
        $this->viewBuilder()->layout('admin');
    }

    public function tablesDynamic() {
        $this->viewBuilder()->layout('admin');
    }

    public function typography() {
        $this->viewBuilder()->layout('admin');
    }

    public function widgets() {
        $this->viewBuilder()->layout('admin');
    }

    public function xx() {
        $this->viewBuilder()->layout('admin');
    }
    public function adminMasterCategories(){
        $this->viewBuilder()->layout('admin');
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all');
        $categories = $this->getResultArray('Categories',$query);
        $this->set("categories",$categories);
    }
    function adminAddCategory(){
        $this->viewBuilder()->layout('admin');
        $this->set('AllowFileSize',Configure::read('AllowFileSize'));
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all')->where(['categories.parent_category_id' => '0','categories.level' => '1']);
        $categories = $this->getResultArray('Categories',$query);
        $this->set("categories",$categories);
        
        if(!empty($this->request->data)){
//            $category_data = new Category($this->request->data);
//            $validate = $this->Category->validate($category_data);
//            debug($validate);die;
            if(trim($this->request->data['category_name']) == ''){
                $this->Flash->error(__('Category name can not be blank'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(!isset($this->request->data['ItemComponentDetail']['categories'])){
                $this->Flash->error(__('Please select parent category'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(trim($this->request->data['ItemComponentDetail']['categories']) == ''){
                $this->Flash->error(__('Please select parent category'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(trim($this->request->data['lastcategory'])== ''){
                $this->Flash->error(__('Parent category id should be numeric'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else {
                $cat_name = trim($this->request->data['category_name']);
                $created_by = '1';
                $status = 'Active';
                $created_date = date('Y-m-d H:m:s');
                $cat_levels = explode(">",$this->request->data['ItemComponentDetail']['categories']);
                $level = count($cat_levels)+1;
                $parent_category_id = $this->request->data['lastcategory'];
                $categories_reg = TableRegistry::get('Categories');
                $query = $categories_reg->find('all')->where(['ec_categories.parent_category_id' => $parent_category_id,'ec_categories.category_name' => $cat_name]);
                $category_exists = $this->getResultArray('Categories',$query);
                if(empty($category_exists)){
                    $query = $categories_reg->query();
                    $insert = $query->insert(['category_name','created_by', 'status','created_date','level','parent_category_id'])
                        ->values([
                            'category_name' => $cat_name,
                            'created_by' => $created_by,
                            'status' => $status,
                            'created_date' => $created_date,
                            'level' => $level,
                            'parent_category_id' => $parent_category_id
                        ])
                        ->execute();
                    if($insert){
                        $this->Flash->success(__('Category added successfully'));
                        $this->redirect(array('controller'=>'admin','action' => 'adminMasterCategories'));
                    }
                } else {
                    $this->Flash->error(__('This category name already exists for this parent category'));
                    $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
                }
            }
        }
    }
    function getSubcategory(){
//        debug($this->request->data('Key'));die;
//        if (isset($this->params["named"]["level"]) && !empty($this->request->params["named"]["level"])) {
//            $this->set('level', $this->request->params["named"]["level"]);
//        }
        $cat = $this->request->data('Key');
        $subcategoryarray = array();
        if (is_numeric($cat))
        {
            $categories_reg = TableRegistry::get('Categories');
            $query = $categories_reg->find('all')->where(['parent_category_id' => $cat]);
            $subcategories = $this->getResultArray('Categories',$query);
            if(count($subcategories)>1){
                foreach ($subcategories as $sub) {
                    $subcategoryarray[$sub['Categories']["category_id"]] = $sub['Categories']["category_name"];
                }
            } else {
                foreach ($subcategories as $sub) {
                    $subcategoryarray[$sub["category_id"]] = $sub["category_name"];
                }
            }
            
            $this->set("subcategoryarray", $subcategoryarray);
            $this->set("category", $cat);

        }else{
            $this->set("subcategoryarray", $subcategoryarray);
        }
    }
    function login(){
        if ($this->Auth->user()) {
            return $this->redirect($this->Auth->redirectUrl());
        } 
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                if($user['status'] == 'Inactive'){
                    $this->Flash->error(__('User is Inactive.Kindly activate first to login'));
                    $this->redirect(array('controller'=>'admin','action' => 'login'));
                } else {
                    $this->Auth->setUser($user);
                    $this->Flash->success(__('Login successful'));
                    $this->redirect(array('controller'=>'admin','action' => 'adminMasterCategories'));
                }
            } else {
                $this->Flash->error(__('User Id or Password is wrong'));
                $this->redirect(array('controller'=>'admin','action' => 'login'));
            }
        }
    }
    public function logout(){
        $this->Auth->logout();
        $this->redirect(array('controller'=>'admin','action' => 'login'));
    }
    function addUser() {
        if ($this->request->is('post')) {
            $validator = new Validator();
            $users_reg = TableRegistry::get('users');
            $this->request->data['name'] = $this->request->data['username'];
            $this->request->data['status'] = 'Inactive';
            $this->request->data['type'] = 'Admin';
            $this->request->data['created_date'] = date('Y-m-d H:m:s');
            $this->request->data['modified_date'] = date('Y-m-d H:m:s');
            $this->request->data['activation_key'] = 'abcdef1234567879ABCDEFGHIJKLMO#%$^#@DD@!XWDF#';
            $user = $users_reg->newEntity($this->request->data);
            if ($users_reg->save($user)) {
                $user_id = $users_reg->save($user)->user_id;
                if (!empty($user_id)) {
                    $email_to = $users_reg->save($user)->email;
                    $users_reg = TableRegistry::get('users');
                    $users_reg->updateAll(['created_by' => $user_id, 'modified_by' => $user_id], ['user_id' => $user_id]);
                    $url = Router::url([
                            'controller' => 'admin',
                            'action' => 'activateAccount/key:'.'abcdef1234567879ABCDEFGHIJKLMO#%$^#@DD@!XWDF#'.'/email:'.$users_reg->save($user)->email,
                        ]);
//                    $email_queue_reg = TableRegistry::get('email_queue');
//                    $email_queue_reg->insert(['subject','email_data','template','type','email_to','email_from','attachments','cc','status','added_by','added_date'])->values([
//                            'subject' => 'Activate Account',
//                            'email_data' => $url,
//                            'template' => 'Register',
//                            'type' => 'html',
//                            'email_to' => $email_to,
//                            'email_from' => 'ecommerce@activate.com',
//                            'attachments' => '',
//                            'cc' => '',
//                            'status' => 0,
//                            'added_by' => $user_id,
//                            'added_date' => date('Y-m-d H:m:s')
//                        ]);
                }
                $this->Flash->success(__($this->Error->getError("1")));
                $this->redirect(array('controller' => 'admin', 'action' => 'login'));
            } else {
                $this->Flash->error(__($this->Error->getError("2")));
                $this->redirect(array('controller' => 'admin', 'action' => 'addUser'));
            }
        }
    }

    function deactivateCategory(){
        if($this->request->params['pass'][0] != ''){
            $cat_id = $this->request->params['pass'][0];
            $categories_reg = TableRegistry::get('Categories');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cat_status = $categories_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id' => $cat_id]);
            if($update_cat_status){
                $this->Flash->success(__($this->Error->getError("3")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            } else {
                $this->Flash->error(__($this->Error->getError("4")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("4")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
        }
    }
    function activateCategory(){
        if($this->request->params['pass'][0] != ''){
            $cat_id = $this->request->params['pass'][0];
            $categories_reg = TableRegistry::get('Categories');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cat_status = $categories_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id' => $cat_id]);
            if($update_cat_status){
                $this->Flash->success(__($this->Error->getError("5")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            } else {
                $this->Flash->error(__($this->Error->getError("6")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("6")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
        }
    }
    function activateCategoryAll(){
        if(isset($this->request->data['cat_id']) && !empty($this->request->data['cat_id'])){
                $categories_reg = TableRegistry::get('Categories');
                $modifed_date = date('Y-m-d H:m:s');
                $update_cat_status = $categories_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id IN' =>  $this->request->data['cat_id']]);
                if($update_cat_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function deactivateCategoryAll(){
        if(isset($this->request->data['cat_id']) && !empty($this->request->data['cat_id'])){
                $categories_reg = TableRegistry::get('Categories');
                $modifed_date = date('Y-m-d H:m:s');
                $update_cat_status = $categories_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id IN' =>  $this->request->data['cat_id']]);
                if($update_cat_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    public function testFilter(){
        
    }
    public function uploadCategoryImage(){
        debug($this->request->data('file'));die;
        if(!empty($_FILES)){
                $file = $_FILES['file']['name'];
                //$file = parent::cleanString($file);
                if (strlen($file) <= 50) {
                    $fileprefix = 'abc'. "_" . time() . "_" . rand(1, 10000) . "_" . $file;
                    $fileNameArray = explode(".", $file);
                    $ext = $fileNameArray[count($fileNameArray) - 1];
                    $filename = '';
                    for ($n = 0; $n < count($fileNameArray) - 1; $n++) {
                        $filename = $filename . $fileNameArray[$n];
                    }
                    $filename = str_replace("_", " ", $filename);

                    if ($_FILES['file']["size"] > (Configure::read('AllowFileSize') * 1024 * 1024)) {
                        echo $this->Error->getError("3070");
                    } else if (in_array(strtolower($ext), Configure::read('AllowedFileType'))) {

//                        App::import("model", "QuestionAttachment");
//                        $this->QuestionAttachment = new QuestionAttachment();
//                        $this->QuestionAttachment->create();
//                        $attachment["QuestionAttachment"]["rfx_id"] = $rfx["Rfx"]["rfx_id"];
//                        $attachment["QuestionAttachment"]["document_name"] = $filename;
//                        $attachment["QuestionAttachment"]["document_file_name"] = $file;
//                        $attachment["QuestionAttachment"]["document_system_file_name"] = $fileprefix;
//                        $attachment["QuestionAttachment"]["question_id"] = $question_id;

                        $move_file = false;
                        if(false){
                        //if ((in_array(strtolower($ext), Configure::read('FileImageType')))) {
                            $move_upload = move_uploaded_file($_FILES['file']['tmp_name'], Configure::read('Document_Path') . "attachements/temp_attachments/" . $fileprefix);
                        } else {
                            $move_upload = move_uploaded_file($_FILES['file']['tmp_name'], Configure::read('Document_Path') . "attachements/" . $fileprefix);
                        }
                        
                        if($move_upload){
                            echo json_encode(array('status' => 'ok'));die;
                        } else {
                            echo json_encode(array('status' => 'error'));die;
                        }
//                        if ($move_file) {
//                            $attachment = parent::getSaveData('QuestionAttachment', $attachment);
//                            $rfx_id = $attachment['QuestionAttachment']['rfx_id'];
//                            $document_name = $attachment['QuestionAttachment']['document_name'];
//                            $document_file_name = $attachment['QuestionAttachment']['document_file_name'];
//                            $document_system_file_name = $attachment['QuestionAttachment']['document_system_file_name'];
//                            $destination_source = $attachment['QuestionAttachment']['destination_source'];
//
//                            $save = $this->QuestionAttachment->query("EXEC spRfxQuestionAttachmentInsert 
//                        @rfx_id='" . parent::spParams($rfx_id) . "',
//                        @question_id='" . parent::spParams($question_id) . "',
//                        @document_name='" . parent::spParams($document_name) . "',
//                        @document_file_name='" . parent::spParams($document_file_name) . "',
//                        @document_system_file_name='" . parent::spParams($document_system_file_name) . "',
//                        @destination_source='" . parent::spParams($destination_source) . "'                     
//                            ");
//                            if ($save) {
//                                // if ($this->QuestionAttachment->save($attachment)) {
//                                $last_id = $save[0][0]['InsertedId'];
//                                $last_id = $this->QuestionAttachment->id;
//                                if (Configure::read('Attachement_Source') == 'DB') {
//                                    $attachment["Attachment"]["reference_id"] = $last_id;
//                                    $attachment["Attachment"]["attachment_type"] = '9';
//                                    $attachment["Attachment"]["created_date"] = date("Y-m-d H:i:s");
//                                    $file_content = $attachment["Attachment"]["attachement_file_content"];
//                                    $file_name = $attachment["Attachment"]["attachment_file_name"];
//                                    $file_size = $attachment["Attachment"]["attachment_file_size"];
//                                    $file_type = $attachment["Attachment"]["attachment_file_type"];
//                                    $created_date = date("Y-m-d H:i:s");
//                                    $save1 = $this->Attachment->query("EXEC spAttachmentInsert 
//                                @reference_id='" . parent::spParams($attachmentid) . "',
//                                @attachment_type='9',
//                                @attachment_file_name='" . parent::spParams($file_name) . "',
//                                @attachement_file_content='" . parent::spParams($file_content) . "',
//                                @attachment_file_type='" . parent::spParams($file_type) . "',
//                                @attachment_file_size='" . parent::spParams($file_size) . "',
//
//                                @created_date='" . parent::spParams($created_date) . "'
//                        ");
//                                    // $this->Attachment->create();
//                                    // if (!$this->Attachment->save($attachment)) {
//                                    if ($save1) {
//                                        echo $this->Error->getError("3069");
//                                    }
//                                }
//                                echo "Success";
//                            } else {
//                                echo $this->Error->getError("3069");
//                            }
//                        }
                    } 
//                    else {
//                        echo $this->Error->getError("3071");
//                    }
                } else {
                    echo "Sorry! Attached filename is longer than 50 characters.";
                }
        }
    }
    public function adminAddProduct(){
        $this->viewBuilder()->layout('admin');
    }
    public function customerManagement(){
        $this->viewBuilder()->layout('admin');
        
    }
}
