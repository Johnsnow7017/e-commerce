<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use App\Core\Setting;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Core\Configure;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{


    var $helpers = array('Form', 'Html');


    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function initialize()
    {
         $this->loadComponent('Error');
        $this->loadComponent('Flash');
        $this->loadComponent('Auth', [
            'loginRedirect' => [
                'controller' => 'Admin',
                'action' => 'admin_add_category'
            ],
            'logoutRedirect' => [
                'controller' => 'Admin',
                'action' => 'login'
            ]
        ]);
    }

    /**
     * Before render callback.
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return \Cake\Network\Response|null|void
     */
    public function beforeRender(Event $event)
    {
        if (!array_key_exists('_serialize', $this->viewVars) &&
            in_array($this->response->type(), ['application/json', 'application/xml'])
        ) {
            $this->set('_serialize', true);
        }
        
    }
    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['login','addUser','adminAddCategory','adminMasterCategory']);
    }
    function getResultArray($model,$query){
        $query->hydrate(false); 
        $result = $query->toList();
        $final_result = array();
        $i = 0;
        if(count($result) == 1){
            $final_result[$model] = $result[0];
        } else {
           foreach($result as $res){
               $final_result[$i][$model] = $res;
               $i++;
           } 
        }
        return $final_result;
    }
    function getResultArrayAll($model,$query){
        $query->hydrate(false); 
        $result = $query->toList();
        $final_result = array();
        $i = 0;
        foreach($result as $res){
            $final_result[$i][$model] = $res;
            $i++;
        } 
        return $final_result;
    }
    function cleanPostData($dataArray, &$flag) {
        $finalArray = array();
        if (count($dataArray) > 0) {
            foreach ($dataArray as $key => $value) {
                if (is_array($value)) {
                    $finalArray[$key] = $this->cleanPostData($dataArray[$key], $flag);
                } else {
                    $cleanString = $this->paranoid($this->stripImages($this->stripScripts(html_entity_decode($value))), Configure::read('AllowSpecialChar'));
                    $finalArray[$key] = str_replace(chr(0), '', $cleanString);
                    if (html_entity_decode($value) != $cleanString) {
                        $flag = true;
                    }
                }
            }
        }
        return $finalArray;
    }
    function specialCharAllowedMessage() {
        $this->Flash->error(__('You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed'));
    }
    public function paranoid($string, $allowed = array()) {
        $allow = null;
        if (!empty($allowed)) {
                foreach ($allowed as $value) {
                        $allow .= "\\$value";
                }
        }

        if (is_array($string)) {
                $cleaned = array();
                foreach ($string as $key => $clean) {
                        $cleaned[$key] = preg_replace("/[^{$allow}a-zA-Z0-9]/", '', $clean);
                }
        } else {
                $cleaned = preg_replace("/[^{$allow}a-zA-Z0-9]/", '', $string);
        }
        return $cleaned;
    }
    function stripImages($str) {
        $str = preg_replace('/(<a[^>]*>)(<img[^>]+alt=")([^"]*)("[^>]*>)(<\/a>)/i', '$1$3$5<br />', $str);
        $str = preg_replace('/(<img[^>]+alt=")([^"]*)("[^>]*>)/i', '$2<br />', $str);
        $str = preg_replace('/<img[^>]*>/i', '', $str);
        return $str;
    }
    function stripScripts($str) {
       return preg_replace('/(<link[^>]+rel="[^"]*stylesheet"[^>]*>|<img[^>]*>|style="[^"]*")|<script[^>]*>.*?<\/script>|<style[^>]*>.*?<\/style>|<!--.*?-->/is', '', $str);
    }
    function notification($receiver_id, $rfx_id = null, $notification = "", $sender_id, $notification_type = null, $description, $rfx_web_id, $buyer_company = null, $supplier_company = null, $message = null, $supplier_company_list = null, $link = null, $rfxDetails = null, $is_auction = null, $receiver_user_id = null, $msgattachments = null) {		
   
	  if (!empty($description)) {
            $personalizations = $this->search_personalizations($description);
            $description = $this->replacePlaceHolder($description, $personalizations, $rfx_web_id, $buyer_company, $supplier_company, $message, $supplier_company_list, $rfxDetails, $msgattachments);
	  }
        if (!empty($link["notification_link"]) && $link["notification_link"] != null) {
            $description .= '<br /><a style="text-decoration: underline;" target="_blank" href="' . $link["notification_link"] . '">here</a>';
        }
        if (!empty($link["attachment_link"]) && $link["attachment_link"] != null) {
            $attachments = $link["attachment_link"];
        }
        if (!empty($notification)) {
            $personalizations = $this->search_personalizations($notification);
            $notification = $this->replacePlaceHolder($notification, $personalizations, $rfx_web_id, $buyer_company, $supplier_company);
        }
        App::import("model", "Notification");
        $this->Notification = new Notification();
        $this->Notification->create();
        $notificationdata["Notification"]["rfx_id"] = $rfx_id;
        $notificationdata["Notification"]["notification_text"] = $notification;
        $notificationdata['Notification']['notification_description'] = nl2br($description);
        if (!empty($notification_type)) {
            $notificationdata["Notification"]["notification_type"] = $notification_type;
        } else {
            $notificationdata["Notification"]["notification_type"] = 'System';
        }
        if ($is_auction != null && $is_auction != "") {
            $notificationdata['Notification']['is_auction'] = $is_auction;
        }
        else
            $notificationdata['Notification']['is_auction'] = 0;
        $notificationdata['Notification']['notification_attachment'] = @$attachments;
        $notificationdata["Notification"]["created_date"] = date("Y-m-d H:i:s");
        $notificationdata = $this->getSaveData('Notification', $notificationdata);		

		
        $save = $this->Notification->query("EXEC spNotificationInsert
            @rfx_id='" . $this->spParams($notificationdata["Notification"]["rfx_id"]) . "',
            @notification_text='" . $this->spParams($notificationdata["Notification"]["notification_text"]) . "', 
            @notification_description='" . $this->spParams($notificationdata["Notification"]["notification_description"]) . "',
            @notification_type='" . $this->spParams($notificationdata["Notification"]["notification_type"]) . "',   
            @is_auction='" . $this->spParams($notificationdata["Notification"]["is_auction"]) . "',
            @notification_attachment='" . $this->spParams($notificationdata["Notification"]["notification_attachment"]) . "', 
            @created_date='" . $this->spParams($notificationdata["Notification"]["created_date"]) . "'
            ");
        if ($save) {
            // if ($this->Notification->save($notificationdata)) {
            //    $inserted_notification_id = $this->Notification->getInsertId();
            $inserted_notification_id = $save[0][0]['InsertedId'];
            if ($receiver_user_id == null || $receiver_user_id == '') {
                $receiver_user_id = '';
            }			
            $this->notificationMapping($inserted_notification_id, $sender_id, $receiver_id, $receiver_user_id);
            return $inserted_notification_id;
        } else {
            return null;
        }
    }
    function notificationMapping($notification_id, $sender_id, $receiver_id, $receiver_user_id = null) {
        App::import("model", "NotificationUser");
        $this->NotificationUser = new NotificationUser();
        $this->NotificationUser->create();
        $notificationdata["NotificationUser"]["notification_id"] = $notification_id;
        $notificationdata["NotificationUser"]["sender_id"] = $sender_id;
        $notificationdata["NotificationUser"]["receiver_id"] = $receiver_id;
        if ($receiver_user_id != null && $receiver_user_id != "") {
            $notificationdata["NotificationUser"]["receiver_user_id"] = $receiver_user_id;
        }
        $save = $this->NotificationUser->query("EXEC spNotificationMappingInsert
            @notification_id='".$this->spParams($notification_id)."',
            @sender_id='".$this->spParams($sender_id)."',
            @receiver_id='".$this->spParams($receiver_id)."',
            @receiver_user_id='".$this->spParams($receiver_user_id)."'");

        // $this->NotificationUser->save($notificationdata);
    }
    function search_personalizations($body) {
        $personalizations = array();
        $matches = array();
        $pattern = '/\[\[[^\]]+\]\]/';
        if (preg_match_all($pattern, $body, $matches) < 1) {
            return $personalizations;
        }
        foreach ($matches[0] as $str) {
            $p = array();
            $p['search'] = $str;
            $a = explode('|', trim($str, '[]'));
            $p['field'] = $a[0];
            $p['default'] = (isset($a[1])) ? $a[1] : false;
            array_push($personalizations, $p);
        }
        return $personalizations;
    }
    function replacePlaceHolder($body, $personalizations, $rfx_web_id, $buyer_company_name = null, $supplier_company_name = null, $message = null, $supplier_company_list = null, $rfxDetails = null, $msgattachments = null) {
        foreach ($personalizations as $p) {
            switch (strtolower($p['field'])) {
                case 'rfxid':
                    $replace = $rfx_web_id;
                    break;
                case 'auctionid':
                    $replace = $rfx_web_id;
                    break;
                case 'requestid':
                    $replace = $rfx_web_id;
                    break;
                case 'suppliername':
                    $replace = $supplier_company_name;
                    break;
                case 'buyername':
                    $replace = $buyer_company_name;
                    break;
                case 'message':
                    $replace = $message;
                    break;
                case 'listofsupplier':
                    $replace = "";
                    foreach ($supplier_company_list as $supplier_company) {
                        $replace .= "<br/>";
                        $replace .= $supplier_company;
                    }
                    break;
                case 'deadline':
                    $replace = $rfxDetails['deadline'];
                    break;
                case 'attachmentlist':
                    $replace = "";
                    foreach ($msgattachments as $attachment_id => $attachment_name) {

                        $replace .= "<a href='" . Router::url(array('controller' => "rfx_responses", 'action' => "download_msg_attachment/attachmentid:" . $attachment_id), true) . "'>" . $attachment_name . "</a>";
                        $replace .= "<br/>";
                    }
                    break;
            }
            $body = str_replace($p['search'], $replace, $body);
        }
        return $body;
    }
}




	

