<?php
namespace App\Model\Table;

use Cake\Database\Expression\QueryExpression;
use Cake\Database\Schema\Table as Schema;
use Cake\Database\Type;
use Cake\I18n\FrozenTime;
use Cake\ORM\Table;

/**
 * EmailQueue Model
 *
 */
class EmailQueueTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('ec_email_queue');
        //$this->displayField('subject');
        $this->primaryKey('queue_id');

        
    }

}
