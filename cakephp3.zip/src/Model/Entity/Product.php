<?php
namespace App\Model\Entity;
use Cake\ORM\Entity;
/**
 * Category Entity.
 */
class Product extends Entity
{
   protected $_accessible = [
        '*' => true,
        'user_id' => false,
    ];
}