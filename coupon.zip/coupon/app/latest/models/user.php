<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of action
 *
 * @author Brajendra
 */
//App::uses('AppModel', 'Model');
//App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');

class User extends AppModel {
    var $name = 'User';
    var $primaryKey = 'user_id';
    
//    public $validate = array(
//        'username' => array(
//            'required' => array(
//                'rule' => 'notBlank',
//                'message' => 'A username is required'
//            )
//        ),
//        'password' => array(
//            'required' => array(
//                'rule' => 'notBlank',
//                'message' => 'A password is required'
//            )
//        ),
//    );
    
    

}

?>