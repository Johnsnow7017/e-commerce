<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of date_format
 *
 * @author lgarg
 */
namespace App\View\Helper;

use Cake\View\Helper;

class DateFormatHelper extends Helper {
    var $name = 'DateFormat';
    var $format = 'd-M-Y';    //put your code here

    function format($date = "", $format = "") {
        if($format !="") {
            $this->format = $format;
        }
        if(is_object($date)){
            $dateTime = strtotime(date_format($date, 'Y-m-d'));
        }else{
            $dateTime = strtotime($date);
        }

        return date($this->format, $dateTime);
    }

}
?>
