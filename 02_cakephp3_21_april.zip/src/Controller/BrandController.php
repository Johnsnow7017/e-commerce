<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure\Engine\PhpConfig;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use App\Core\Setting;
use Cake\Core\App;
use Cake\Validation\Validator;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;


class BrandController extends AppController {
    //var $helpers = array('DateFormat');
//public $helpers = array('DateFormat');
    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
        
    }
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('index');
    }
   
    public function index(){
        $this->viewBuilder()->layout('admin');
        $brands_reg = TableRegistry::get('brands');
        $query = $brands_reg->find('all');
        $brands = $this->getResultArray('Brand',$query);
        $this->set("brands",$brands);
    }
    function addBrand(){
        $this->viewBuilder()->layout('admin');
        if(!empty($this->request->data)){
            if(trim($this->request->data['brand_name']) == ''){
                $this->Flash->error(__('Category name can not be blank'));
                $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
            } else {
                $brand_name = trim($this->request->data['brand_name']);
                $created_by = '1';
                $modified_by = '1';
                $status = 'Active';
                $created_date = date('Y-m-d H:m:s');
                $modified_date = date('Y-m-d H:m:s');
                $brands_reg = TableRegistry::get('brands');
                $query = $brands_reg->find('all')->where(['brand_name' => $brand_name]);
                $brand_exists = $this->getResultArray('Brand',$query);
                if(empty($brand_exists)){
                    $query = $brands_reg->query();
                    $insert = $query->insert(['brand_name','status','created_by','created_date','modified_by','modified_date'])
                        ->values([
                            'brand_name' => $brand_name,
                            'status' => $status,
                            'created_by' => $created_by,
                            'created_date' => $created_date,
                            'modified_by' => $modified_by,
                            'modified_date' => $modified_date
                        ])
                        ->execute();
                    if($insert){
                        $this->Flash->success(__('Brand added successfully'));
                        $this->redirect(array('controller'=>'Brand','action' => 'index'));
                    }
                } else {
                    $this->Flash->error(__('This brand name already exists'));
                    $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
                }
            }
        }
    }
   
    function deactivateBrand(){
        if($this->request->params['pass'][0] != ''){
            $brand_id = $this->request->params['pass'][0];
            $brands_reg = TableRegistry::get('brands');
            $modifed_date = date('Y-m-d H:m:s');
            $update_brand_status = $brands_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['brand_id' => $brand_id]);
            if($update_brand_status){
                $this->Flash->success(__($this->Error->getError("Brand deactivated successfully")));
                $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Brand can not be deactivated")));
                $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Brand can not be deactivated")));
            $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
        }
    }
    function activateBrand(){
        if($this->request->params['pass'][0] != ''){
            $brand_id = $this->request->params['pass'][0];
            $brands_reg = TableRegistry::get('brands');
            $modifed_date = date('Y-m-d H:m:s');
            $update_brand_status = $brands_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['brand_id' => $brand_id]);
            if($update_brand_status){
                $this->Flash->success(__($this->Error->getError("Brand activated successfully")));
                $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Brand can not be activated")));
                $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Brand can not be activated")));
            $this->redirect(array('controller' => 'Brand', 'action' => 'index'));
        }
    }
    function activateBrandAll(){
        if(isset($this->request->data['brand_id']) && !empty($this->request->data['brand_id'])){
                $brands_reg = TableRegistry::get('brands');
                $modifed_date = date('Y-m-d H:m:s');
                $update_brand_status = $brands_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['brand_id IN' =>  $this->request->data['brand_id']]);
                if($update_brand_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function deactivateBrandAll(){
        if(isset($this->request->data['brand_id']) && !empty($this->request->data['brand_id'])){
                $brands_reg = TableRegistry::get('brands');
                $modifed_date = date('Y-m-d H:m:s');
                $update_brand_status = $brands_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['brand_id IN' =>  $this->request->data['brand_id']]);
                if($update_brand_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function editBrand(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $brand_id = $this->request->params['pass'][0];
            if(trim($brand_id) == ''){
                $this->Flash->error(__('Sorry! brand not exists.'));
                $this->redirect(array('controller'=>'Brand','action' => 'index'));
            } else {
                $brand_id = $this->request->params['pass'][0];
                $brands_reg = TableRegistry::get('brands');
                $query = $brands_reg->find('all')->where(['brand_id' => $brand_id]);
                $brand = $this->getResultArray('Brand',$query);
                if(empty($brand)){
                    $this->Flash->error(__('Sorry! No such brand id exists'));
                    $this->redirect(array('controller'=>'Brand','action' => 'index'));
                } else {
                    $this->set("brand",$brand);
                    if(!empty($this->request->data)){
                        $postDataChanged = false;
                        if (isset($this->request->data) && count($this->request->data) > 0) {
                            $postData = parent::cleanPostData($this->request->data, $postDataChanged);
                        }
                        if ($postDataChanged == true) {
                            $this->Flash->error(__('You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed'));
                            $this->redirect(array('controller'=>'Brand','action' => 'editBrand/'.$brand_id));
                        } else {
                            $brand_name = trim($this->request->data['brand_name']);
                            $modified_by = '1';
                            $modified_date = date('Y-m-d H:m:s');
                            $brands_reg = TableRegistry::get('brands');
                            $query = $brands_reg->find('all')->where(['brand_name' => $brand_name]);
                            $brand_exists = $this->getResultArray('Brand',$query);
                            if(empty($brand_exists)){
                                $brands_reg = TableRegistry::get('brands');
                                $update_brand_name = $brands_reg->updateAll(['brand_name' =>$brand_name, 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modified_date], ['brand_id' => $brand_id]);
                                if($update_brand_name){
                                    $this->Flash->success(__('Brand edited successfully'));
                                    $this->redirect(array('controller'=>'Brand','action' => 'index'));
                                }
                            } else {
                                $this->Flash->error(__('This brand name already exists'));
                                $this->redirect(array('controller'=>'Brand','action' => 'editBrand/'.$brand_id));
                            }
                        } 
                    }
                }
            }
        }
    }
}
