<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

class FrontsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
        $this->loadComponent('RequestHandler');

    }

    public function shop() {
        
    }

    public function blog() {
        
    }

    public function blogSingle() {
        
    }

    public function cart() {
        
    }

    public function checkout() {
        
    }

    public function contactUs() {
        
    }

    public function error() {
        
    }

    public function index() {
        $this->viewBuilder()->layout('front');
        
        $shop_settings_reg = TableRegistry::get('shop_settings');
        $user_id = $this->Auth->user('user_id');
//        debug($user_id);
        $query = $shop_settings_reg->find('all')->where(['shop_settings.user_id' => $user_id]);
        $shop_details = $this->getResultArray('ShopSettings',$query);
        //debug($shop_details);die;
        $this->set('shop_details',$shop_details);
        
        
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all')->where(['Categories.level' => 1,'Categories.parent_category_id' => 0]);
        $category_details = $this->getResultArray('Categories',$query);
//        debug($category_details);die;
        $this->set('category_details',$category_details);
                
    }
    
    public function categoryMainFilter(){
        //debug("a");die;
        $this->viewBuilder()->layout('front');
        if($this->request->params['pass'][0] != ''){
            $cat_id = $this->request->params['pass'][0];
            $attribute_cat_mapping_reg = TableRegistry::get('attribute_category_mappings');
            $query = $attribute_cat_mapping_reg->find('all')->where(['attribute_category_mappings.category_id' => $cat_id]);
            $attribute_cat_mapping_details = $this->getResultArray('AttributecategoryMapping',$query);
            //debug($attribute_cat_mapping_details);die;
            $attribute_array = array();
            if(!empty($attribute_cat_mapping_details)){
                foreach($attribute_cat_mapping_details as $attribute_cat_mapping_details1){
                    $attribute_id = $attribute_cat_mapping_details1['AttributecategoryMapping']['attribute_id'];
                    $attributes_reg = TableRegistry::get('attribute_masters');
                    $query = $attributes_reg->find('all')->where(['attribute_masters.attribute_id' => $attribute_id]);
                    $attribute_details = $this->getResultArray('AttributeMaster',$query);
                    if(!empty($attribute_details)){
                        $features_reg = TableRegistry::get('feature_masters');
                        $query = $features_reg->find('all')->where(['feature_masters.attribute_id' => $attribute_id]);
                        $feature_details = $this->getResultArrayAll('FeatureMaster',$query);
                        $feature_array = array();
                        if(!empty($feature_details)){
                            foreach($feature_details as $feature_details1){
                                $feature_array[$feature_details1['FeatureMaster']['feature_id']]['feature_id']= $feature_details1['FeatureMaster']['feature_id'];
                                $feature_array[$feature_details1['FeatureMaster']['feature_id']]['feature_name']= $feature_details1['FeatureMaster']['feature_name'];
                                $feature_array[$feature_details1['FeatureMaster']['feature_id']]['status']= $feature_details1['FeatureMaster']['status'];
                            }
                        }
                        $attribute_array[$attribute_details['AttributeMaster']['attribute_id']]['attribute_name'] = $attribute_details['AttributeMaster']['attribute_name'];
                        $attribute_array[$attribute_details['AttributeMaster']['attribute_id']]['public_name'] = $attribute_details['AttributeMaster']['public_name'];
                        $attribute_array[$attribute_details['AttributeMaster']['attribute_id']]['attribute_type'] = $attribute_details['AttributeMaster']['attribute_type'];
                        $attribute_array[$attribute_details['AttributeMaster']['attribute_id']]['status'] = $attribute_details['AttributeMaster']['status'];
                        $attribute_array[$attribute_details['AttributeMaster']['attribute_id']]['feature_values'] = $feature_array;
                    }
                }
            }
            $this->set("category_id",$cat_id);
            $this->set("attribute_array",$attribute_array);
        } else {
            $this->Flash->error(__($this->Error->getError("7")));
            $this->redirect(array('controller' => 'fronts', 'action' => 'index'));
        }
        
    }

    public function filterProduct(){
        $this->viewBuilder()->layout = false;
        //$this->viewBuilder()->layout('full_blank');
        if ($this->request->is('ajax')) {
//        print_r ($this->request->data['features']);
        $feature_arr = $this->request->data['features'];
        $cat_id = $this->request->data['category_id'];
        if(!empty($feature_arr)){
            $filter_feature_values = array_filter($feature_arr);
            if(!empty($filter_feature_values)){
                $product_attribute_feature_reg = TableRegistry::get('product_attribute_feature_mappings');
                $query = $product_attribute_feature_reg->find('all')->where(['feature_id IN' =>  $filter_feature_values]);
                $product_attribute_feature_details = $this->getResultArrayAll('ProductAttributeFeatureMapping',$query);
                if(!empty($product_attribute_feature_details)){
                    $categories_reg = TableRegistry::get('Categories');
                    $query = $categories_reg->find('all')->where(['categories.parent_category_id' => $cat_id])->orWhere(['categories.category_id' => $cat_id]);
                    $categories = $this->getResultArrayAll('Categories',$query);
                    $cat_id_arr = array();
                    if(!empty($categories)){
                        foreach($categories as $categories1){
                            $cat_id_arr[] = $categories1['Categories']['category_id'];
                        }
                    }
                    $filter_product_id_array = array();
                    for($p=0;$p<500;$p++){
                        $m[] = $product_attribute_feature_details;
                    }
                    
                    foreach($m as $product_attribute_feature_details){
                    foreach($product_attribute_feature_details as $product_attribute_feature_details1){
                        $products_reg = TableRegistry::get('Products');
                        $query = $products_reg->find('all')->where(['product_id' => $product_attribute_feature_details1['ProductAttributeFeatureMapping']['product_id']]);
                        $product_detail = $this->getResultArray('Products', $query);
                        if(!empty($product_detail)){
                            $mapped_cat_ids = $product_detail['Products']['mapped_category_id'];
                            $categories = str_replace('#', '', $product_detail['Products']['mapped_category_id']);
                            $categories = explode(',', $categories);
                            $filter_cat = array();
                            if(!empty($categories) && !empty($cat_id_arr)){
                                foreach($cat_id_arr as $cat_id_arr1){
                                    if(in_array($cat_id_arr1, $categories)){
                                        $filter_cat[] = $cat_id_arr1;
                                    }
                                }
                            }
                            if(!empty($filter_cat)){
                                $filter_product_id_array[] = $product_detail;
                            }
                        }
                    }
                    }
                    
                    $this->set("filter_product_id_array",$filter_product_id_array);
                    $this->render("filter_product");
                }
            } else {
                
            }
        } else {
            
        }
        }
    }
    
    
    public function login() {
        $this->viewBuilder()->layout('front');
//        require_once ('webroot/gmail_api/libraries/Google/autoload.php');
        require_once(ROOT . DS . 'vendor' . DS . 'gmail_api' . DS . 'libraries'. DS . 'Google'. DS . 'autoload.php');
    }

    public function productDetails() {
        
    }
    

    public function googleLogin(){
        //session_start(); //session start

require_once(ROOT . DS . 'vendor' . DS . 'gmail_api' . DS . 'libraries'. DS . 'Google'. DS . 'autoload.php');

//Insert your cient ID and secret 
//You can get it from : https://console.developers.google.com/

$client_id = '110143934619-2q71616ccmc6kv1vvjb1smem07hg1ear.apps.googleusercontent.com'; 
$client_secret = 'KduHeDvaIGTUtbzWOCq5Ox9w';
$redirect_uri = 'http://localhost:8081/cakephp3/shops/login';

//database
//$db_username = "root"; //Database Username
//$db_password = ""; //Database Password
//$host_name = "localhost:8081"; //Mysql Hostname
//$db_name = 'cakephp3'; //Database Name

//incase of logout request, just unset the session var
//$_GET['logout'] = 'a';
if (isset($_GET['logout'])) {
  unset($_SESSION['access_token']);
}

/************************************************
  Make an API request on behalf of a user. In
  this case we need to have a valid OAuth 2.0
  token for the user, so we need to send them
  through a login flow. To do this we need some
  information from our API console project.
 ************************************************/
$client = new Google_Client();
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);
$client->addScope("email");
$client->addScope("profile");

/************************************************
  When we create the service here, we pass the
  client to it. The client then queries the service
  for the required scopes, and uses that when
  generating the authentication URL later.
 ************************************************/
$service = new Google_Service_Oauth2($client);

/************************************************
  If we have a code back from the OAuth 2.0 flow,
  we need to exchange that with the authenticate()
  function. We store the resultant access token
  bundle in the session, and redirect to ourself.
*/
  
if (isset($_GET['code'])) {
  $client->authenticate($_GET['code']);
  $_SESSION['access_token'] = $client->getAccessToken();
  header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
  exit;
}


/************************************************
  If we have an access token, we can make
  requests, else we generate an authentication URL.
 ************************************************/
if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
  $client->setAccessToken($_SESSION['access_token']);
} else {
  $authUrl = $client->createAuthUrl();
}
$user = $service->userinfo->get(); //get user info 
debug($user);die;


    }
}
