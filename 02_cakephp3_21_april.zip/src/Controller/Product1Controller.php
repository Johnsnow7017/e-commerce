<?php
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
class ProductController extends Controller {

    public function index() {
    //create an fill products table for this example
        /* Load Model datasource */
        //App::import('Model', 'ConnectionManager');
        //$con = new ConnectionManager;
        //$cn = $con->getDataSource('default');
        /* User table schema */
        $sql = "CREATE TABLE IF NOT EXISTS products(
								id INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
								name VARCHAR( 255 ) NOT NULL ,
								price VARCHAR( 20 ) NOT NULL ,
								created DATETIME NOT NULL ,
                                                                modified DATETIME NOT NULL ,
								PRIMARY KEY ( `id` ) ,
								INDEX ( `name` )
								)";
        if(true){
		//if ($cn->query($sql)) {
            /* Load User Model */
            $this->loadModel('Product');
            /* Records array */
            $records_arr = array('Product' => array(
                    array('id' => 1, 'name' => 'pencil', 'price' => '2'),
                    array('id' => 2, 'name' => 'ruler', 'price' => '3'),
                    array('id' => 3, 'name' => 'eraser', 'price' => '2.5'),
                    ));
            foreach ($records_arr as $arr) {
                /* Save data to User table  */
                if ($this->Product->save($arr)) {
                    
                }
            }
            //$this->Session->setFlash(__('Product Table Created Successfully in Database'),'default',array('class'=>''));
        } else {

            $this->Session->setFlash(__('Product Table Already Exist !!!'), 'default', array('class' => ''));
        }

        //find all products
        $products = $this->Product->find('all');
        debug($products);die;
        //set counter to display number of products in a cart
        $counter = 0;
        if ($this->Session->read('Counter')) {
            $counter = $this->Session->read('Counter');
        }
        //pass variable to view
        $this->set(compact('products', 'counter'));
    }

    public function view($id = null) {
        $this->Product->id = $id;
        //check if product exists in database
        if (!$this->Product->exists()) {
            throw new NotFoundException(__('Invalid product'));
        }
        //read product data
        $product = $this->Product->read(null, $id);
        
        //set counter to display number of products in a cart
        $counter = 0;
        if ($this->Session->read('Counter')) {
            $counter = $this->Session->read('Counter');
        }
        //pass variable to view
        $this->set(compact('product', 'counter'));
    }

    public function add_to_cart($id = null) {
        $this->Product->id = $id;
        //check if product exists in database
       if (!$this->Product->exists()) {
            throw new NotFoundException(__('Invalid product'));
        }

        //check if prodocut is in a cart
        $productsInCart = $this->Session->read('Cart');
        $alreadyIn = false;
        foreach ($productsInCart as $productInCart) {
            if ($productInCart['Product']['id'] == $id) {
                $alreadyIn = true;
            }
        }
        //if product isn't in a cart add it and set counter value
        if (!$alreadyIn) {
            $amount = count($productsInCart);
            $this->Session->write('Cart.' . $amount, $this->Product->read(null, $id));
            $this->Session->write('Counter', $amount + 1);
            $this->Session->setFlash(__('Product added to cart'));
        } else {
            $this->Session->setFlash(__('Product already in cart'));
        }


        $this->redirect(array('controller' => 'products', 'action' => 'index'));
    }

    public function delete($id = null) {
        if (is_null($id)) {
            throw new NotFoundException(__l('Invalid request'));
        }
        //delete product from cart
        if ($this->Session->delete('Cart.' . $id)) {
            //sort cart elements 
            $cart = $this->Session->read('Cart');
            sort($cart);
            $this->Session->write('Cart', $cart);
            //updeate counter
            $this->Session->write('Counter', count($cart));
            $this->Session->setFlash('Product has been deleted');
        }
        return $this->redirect(array('action' => 'cart'));
    }

    public function cart() {
        //show all elemnts in a cart
        $cart = array();

        if ($this->Session->check('Cart')) {
            $cart = $this->Session->read('Cart');
        }

        $this->set(compact('cart'));
    }

    public function empty_cart() {
        //delete cart with all elements and counter
        $this->Session->delete('Cart');
        $this->Session->delete('Counter');
        $this->redirect(array('controller' => 'products', 'action' => 'index'));
    }

}