<?php
namespace App\Model\Table;

use App\Model\Entity\Configuration;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

use Cake\Database\Schema\Table as SchemaTable;

/**
 * Users Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Roles
 * @property \Cake\ORM\Association\HasMany $Posts
 */
class CategoriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->table('categories');
        $this->primaryKey('category_id');
        
//        $table = new SchemaTable(null);
//        $table
//            ->addColumn('category_name', [
//                'type' => 'varchar',
//                'length' => 500,
//                'null' => false
//            ])
//            ->addColumn('category_id', [
//                'type' => 'int',
//                'length' => 11,
//                'null' => false
//            ]);
//            $this->schema($table);
            
        
    }
    
//    public function validationDefault(Validator $validator) {
//        $validator
//            ->validatePresence('category_name');
//
//        return $validator;
//    }
//     

    
}
