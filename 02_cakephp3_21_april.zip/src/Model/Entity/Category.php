<?php
namespace App\Model\Entity;
use Cake\ORM\Entity;
/**
 * Category Entity.
 */
class Category extends Entity
{
   
}