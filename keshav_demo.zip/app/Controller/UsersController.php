<?php
App::uses('AppController', 'Controller');
/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class UsersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');


    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('add', 'logout');
    }

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
		$this->set('user', $this->User->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->User->create();
//                        debug($this->request->data);die;
			if ($this->User->save($this->request->data)) {
                                $this->User->query("update users set status = 'Inactive' where username='".$this->request->data['User']['username']."'");
				$this->Session->setFlash(__('The user has been saved.'));
				return $this->redirect(array('controller' => 'Posts', 'action' => 'index'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->User->save($this->request->data)) {
				$this->Session->setFlash(__('The user has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
			$this->request->data = $this->User->find('first', $options);
		}
	}
        
        public function activate($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
//                $this->User->create();
                $activate1 = $this->User->query("update users set status = 'Active' where id='".$id."'");
                if ($activate1) {
                        $this->Session->setFlash(__('The user has been activated successfully.'));
                        return $this->redirect(array('action' => 'index'));
                } else {
                        $this->Session->setFlash(__('The user could not be activated. Please, try again.'));
                        return $this->redirect(array('action' => 'index'));
                }
		
	}
        
        public function deactivate($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
//                $this->User->create();
                $activate = $this->User->query("update users set status = 'Inactive' where id='".$id."'");
                if ($activate) {
                        $this->Session->setFlash(__('The user has been deactivated successfully.'));
                        return $this->redirect(array('action' => 'index'));
                } else {
                        $this->Session->setFlash(__('The user could not be deactivated. Please, try again.'));
                        return $this->redirect(array('action' => 'index'));
                }
		
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->User->id = $id;
		if (!$this->User->exists()) {
			throw new NotFoundException(__('Invalid user'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->User->delete()) {
			$this->Session->setFlash(__('The user has been deleted.'));
		} else {
			$this->Session->setFlash(__('The user could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

    public function login() {
        if ($this->request->is('post')) {
            if ($this->Auth->login()) {
                $options = array('conditions' => array("username" => $this->request->data['User']['username']));
                $data = $this->User->find('first',$options);
                if($data['User']['status'] == 'Inactive'){
                    $this->Session->setFlash(__(''));
                    $this->Session->setFlash(__('Sorry! User is Inactive. Kindly contact with admin'));
                    return $this->redirect($this->Auth->redirect(array('controller' => 'Users', 'action' => 'login')));
                } else {
                    return $this->redirect($this->Auth->redirect(array('controller' => 'Users', 'action' => 'index')));
                }
            }
            $this->Session->setFlash(__('Invalid username or password, try again'));
        }
    }
    
    public function user_list(){
        die;
    }

    public function logout() {
        //return $this->redirect($this->Auth->logout());
        return $this->redirect($this->Auth->logout($this->Auth->redirect(array('controller' => 'Posts', 'action' => 'visitors'))));
    }
}
