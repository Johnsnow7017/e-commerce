1. Create DB
		--Create new database by name "selgatek"
		-- Then exceute the selgatek.sql file in db database sql  (selgatek/selgatek.sql)

2. selgatek\admin\production\index.php 
		--Go to line no 148 and change db credentials

3. selgatek/config.php
		--change db credentials
		