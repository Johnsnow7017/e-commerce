-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2017 at 06:27 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `selgatek`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `message` varchar(8000) NOT NULL,
  `created_date` datetime NOT NULL,
  `send_ip` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`contact_id`, `name`, `email`, `subject`, `message`, `created_date`, `send_ip`) VALUES
(1, 'sdtgfyg', 'abc@gmail.com', 'dfghk', 'fsdhk', '2017-04-10 05:04:53', 'sdfg'),
(2, 'tyui', 'abc@gmail.com', 'dfjh', 'ghkl', '2017-04-10 05:04:21', '10710'),
(3, 'dafshj', 'abc@gmail.com', 'sdfgjk', 'gh', '2017-04-10 05:04:47', '10710'),
(4, 'sdtfgyu', 'wer@gmail.com', 'fyui', 'ertyu', '2017-04-10 06:04:42', '10710'),
(5, 'sdfg', 'afdshg@gmail.com', 'fdh', 'fdg', '2017-04-10 06:04:05', '10710'),
(6, 'sf', 'H3333@gmail.com', 'dfghj', 'fghj', '2017-04-10 06:04:47', '10710'),
(7, 'dfgtfh', 'www111112222@gmail.com', 'dfgj', 'dfgj', '2017-04-10 06:04:40', '10710'),
(8, 'dfgtfh', 'www111112222@gmail.com', 'dfgj', 'dfgj', '2017-04-10 06:04:16', '10710');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'admin', 'admin@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
