<?php
//        die;
         if (isset($_POST) && !empty($_POST)) {
             $login_username  = trim($_POST['username']);
             $pwd = trim($_POST['password']);
             
            include('../../config.php');
            
            $sql = "Select user_id from users where username='".$login_username."' and password='".$pwd."'";
            $result_user = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result_user) > 0) {
                session_start();
                $_SESSION['username'] = $login_username;
                $_SESSION['password'] = $pwd;
                header("Location: index.php");
            }
            
         }   
            

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Realestate</title>
    <link href="../admincss/bootstrap.min.css" rel="stylesheet">
    <link href="../admincss/font-awesome.min.css" rel="stylesheet">
    <link href="../admincss/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="login.php" method="post">
              <h1>Login Form</h1>
              <div>
                  <input type="text" id='username' name='username' value="<?php if (isset($login_username) && $login_username != '') {
                echo $login_username;
            } ?>" class="form-control" placeholder="Username" required="">
              </div>
              <div>
                  <input type="password" id='password' name='password' value="<?php if (isset($password) && $password != '') {
                echo $password;
            } ?>" class="form-control" placeholder="Password" required="">
              </div>
              <div>
                <input type="submit" value="Login"/>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
