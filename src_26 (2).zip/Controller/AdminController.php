<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure\Engine\PhpConfig;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use App\Core\Setting;
use Cake\Core\App;
use Cake\Validation\Validator;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;

//use App\Model\Entity\Category;

class AdminController extends AppController {
    //var $helpers = array('DateFormat');
//public $helpers = array('DateFormat');
    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
        
    }
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('login','addUser');
    }
    public function shop() {
        
    }
    
    public function blog() {
        
    }

    public function blogSingle() {
        
    }

    public function cart() {
        
    }

    public function checkout() {
        
    }

    public function contactUs() {
        
    }

    public function error() {
        
    }

    public function index() {
        $this->viewBuilder()->layout('admin');
    }

    public function index2() {
         $this->viewBuilder()->layout('admin');
        
    }

    public function index3() {
         $this->viewBuilder()->layout('admin');
        
    }

    public function calendar() {
        $this->viewBuilder()->layout('admin');
    }

    public function chartjs() {
        $this->viewBuilder()->layout('admin');
    }

    public function chartjs2() {
        $this->viewBuilder()->layout('admin');
    }

    public function contacts() {
        $this->viewBuilder()->layout('admin');
    }

    public function eCommerce() {
        $this->viewBuilder()->layout('admin');
    }

    public function echarts() {
        $this->viewBuilder()->layout('admin');
    }

    public function fixed_footer() {
        $this->viewBuilder()->layout('admin');
    }

    public function fixed_sidebar() {
        $this->viewBuilder()->layout('admin');
    }

    public function form() {
        $this->viewBuilder()->layout('admin');
    }

    public function formAdvanced() {
        $this->viewBuilder()->layout('admin');
    }

    public function formButtons() {
        $this->viewBuilder()->layout('admin');
    }

    public function formUpload() {
        $this->viewBuilder()->layout('admin');
    }

    public function formValidation() {
        $this->viewBuilder()->layout('admin');
    }

    public function formWizards() {
        $this->viewBuilder()->layout('admin');
    }

    public function generalElements() {
        $this->viewBuilder()->layout('admin');
    }

    public function glyphicons() {
        $this->viewBuilder()->layout('admin');
    }

    public function icons() {
        $this->viewBuilder()->layout('admin');
    }

    public function inbox() {
        $this->viewBuilder()->layout('admin');
    }

    public function invoice() {
        $this->viewBuilder()->layout('admin');
    }

    public function level2() {
        $this->viewBuilder()->layout('admin');
    }

    

    public function map() {
        $this->viewBuilder()->layout('admin');
    }

    public function media_gallery() {
        $this->viewBuilder()->layout('admin');
    }

    public function morisjs() {
        $this->viewBuilder()->layout('admin');
    }

    public function other_charts() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_403() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_404() {
        $this->viewBuilder()->layout('admin');
    }

    public function page_500() {
        $this->viewBuilder()->layout('admin');
    }

    public function plain_page() {
        $this->viewBuilder()->layout('admin');
    }

    public function pricingTables() {
        $this->viewBuilder()->layout('admin');
    }

    public function profile() {
        $this->viewBuilder()->layout('admin');
    }

    public function projectDetail() {
        $this->viewBuilder()->layout('admin');
    }

    public function projects() {
        $this->viewBuilder()->layout('admin');
    }

    public function tables() {
        $this->viewBuilder()->layout('admin');
    }

    public function tablesDynamic() {
        $this->viewBuilder()->layout('admin');
    }

    public function typography() {
        $this->viewBuilder()->layout('admin');
    }

    public function widgets() {
        $this->viewBuilder()->layout('admin');
    }

    public function xx() {
        $this->viewBuilder()->layout('admin');
    }
    public function adminMasterCategories(){
        $this->viewBuilder()->layout('admin');
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all')->where(['created_by' => $this->Auth->user('user_id')]);
        $categories = $this->getResultArray('Categories',$query);
        $this->set("categories",$categories);
    }
    function adminAddCategory(){
        $this->viewBuilder()->layout('admin');
        $this->set('AllowFileSize',Configure::read('AllowFileSize'));
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all')->where(['categories.parent_category_id' => '0','categories.level' => '1']);
        $categories = $this->getResultArray('Categories',$query);
        $this->set("categories",$categories);
        
        //debug($this->Auth->user('mapped_category_id'));die;
        
        $hsn_reg = TableRegistry::get('hsn_code_details');
        $query = $hsn_reg->find('all')->where(['mapped_parent_category_id' => $this->Auth->user('mapped_category_id')]);
        $hsn_codes = $this->getResultArray('HSN',$query);
        $hc_array = array("0"=>"Select HSN Code");
        if(!empty($hsn_codes)){
            foreach($hsn_codes as $hc){
                $hc_array[$hc['HSN']['hsn_code_id']] = $hc['HSN']['hsn_code'];
            }
        }
        $this->set("hsn_codes",$hc_array);
        
        
        if(!empty($this->request->data)){
//            $category_data = new Category($this->request->data);
//            $validate = $this->Category->validate($category_data);
//            debug($validate);die;
            if(trim($this->request->data['category_name']) == ''){
                $this->Flash->error(__('Category name can not be blank'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(!isset($this->request->data['ItemComponentDetail']['categories'])){
                $this->Flash->error(__('Please select parent category'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(trim($this->request->data['ItemComponentDetail']['categories']) == ''){
                $this->Flash->error(__('Please select parent category'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else if(trim($this->request->data['lastcategory'])== ''){
                $this->Flash->error(__('Parent category id should be numeric'));
                $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
            } else {
                
                $cat_name = trim($this->request->data['category_name']);
                $hsn_code_id = $this->request->data['hsn_code'];
                $created_by = $this->Auth->user('user_id');
                $status = 'Active';
                $created_date = date('Y-m-d H:m:s');
                $cat_levels = explode(">",$this->request->data['ItemComponentDetail']['categories']);
                $level = count($cat_levels)+1;
                
                $parent_category_id = $this->request->data['lastcategory'];
                $categories_reg = TableRegistry::get('categories');
                $query = $categories_reg->find('all')->where(['parent_category_id' => $parent_category_id,'category_name' => $cat_name]);
                $category_exists = $this->getResultArray('Categories',$query);
                if(empty($category_exists)){
                    $query = $categories_reg->query();
                    $insert = $query->insert(['category_name','created_by', 'status','created_date','level','parent_category_id','hsn_code_id'])
                        ->values([
                            'category_name' => $cat_name,
                            'created_by' => $created_by,
                            'status' => $status,
                            'created_date' => $created_date,
                            'level' => $level,
                            'parent_category_id' => $parent_category_id,
                            'hsn_code_id' => $hsn_code_id
                        ])
                        ->execute();
                    if($insert){
                        $this->Flash->success(__('Category added successfully'));
                        $this->redirect(array('controller'=>'admin','action' => 'adminMasterCategories'));
                    }
                } else {
                    $this->Flash->error(__('This category name already exists for this parent category'));
                    $this->redirect(array('controller'=>'admin','action' => 'adminAddCategory'));
                }
            }
        }
    }
    
    
    function addTaxDetail(){
        $this->viewBuilder()->layout('admin');
        if ($this->request->is('post')) {
            //debug($this->request->data);die;
            
            $user_tax_mappings_reg = TableRegistry::get('user_tax_mappings');
            
            $tax_type = trim($this->request->data['tax_type']);
            $state_id = trim($this->request->data['state']);
            $user_gstin_number = trim($this->request->data['user_gstin_number']);
            $tax_registration_name = trim($this->request->data['tax_registration_name']);
            $tax_payer_type = trim($this->request->data['tax_payer_type']);
            $trade_name = trim($this->request->data['trade_name']);
            $dor = trim($this->request->data['dor']);
            $dor = NULL;
//            debug($this->request->data);
//            debug($this->request->data['dor']);die;
            $gross_turnover = trim($this->request->data['gross_turnover']);
            $aggregate_turnover = trim($this->request->data['aggregate_turnover']);
            $gstin_username = trim($this->request->data['gstin_username']);
            
            $created_by = $this->Auth->user('user_id');
            $created_date = date('Y-m-d H:m:s');
            //debug($user_id);die;
            
            //$query = $user_tax_mappings_reg->find('all')->where(['code' => $code]);
            //$customer_code_exists = $this->getResultArray('Customer',$query);
            //if(empty($customer_code_exists)){
             $query = $user_tax_mappings_reg->query();
                    $insert = $query->insert(['user_id','tax_type','state_id','user_gstin_number','tax_registration_name','tax_payer_type','trade_name','date_of_registration','gross_turnover','aggregate_turnover','gstin_username','created_date','created_by'])
                        ->values([
                            'user_id' => $created_by,
                            'tax_type' => $tax_type,
                            'state_id' => $state_id,
                            'user_gstin_number' => $user_gstin_number,
                            'tax_registration_name' => $tax_registration_name,
                            'tax_payer_type' => $tax_payer_type,
                            'trade_name' => $trade_name,
                            'date_of_registration' => $dor,
                            'gross_turnover' => $gross_turnover,
                            'aggregate_turnover' => $aggregate_turnover,
                            'gstin_username' => $gstin_username,
                            'created_date' => $created_date,
                            'created_by' => $created_by
                        ])
                        ->execute();
                    if($insert){
                        $modified_date = date('Y-m-d H:m:s');
                        $users_reg = TableRegistry::get('users');
                        $users_reg->updateAll(['is_tax_details_filled' => '1', 'modified_by' => $created_by,'modified_date' => $modified_date], ['user_id' => $created_by]);
                    
                        $this->Flash->success(__('Tax details saved successfully'));
                        $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                    }
//            } else {
//                $this->Flash->error(__('This Customer code already exists'));
//                $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
//            }
        }
    }
    
    
    function getSubcategory(){
//        debug($this->request->data('Key'));die;
//        if (isset($this->params["named"]["level"]) && !empty($this->request->params["named"]["level"])) {
//            $this->set('level', $this->request->params["named"]["level"]);
//        }
        $cat = $this->request->data('Key');
        $subcategoryarray = array();
        if (is_numeric($cat))
        {
            $categories_reg = TableRegistry::get('Categories');
            $query = $categories_reg->find('all')->where(['parent_category_id' => $cat,'created_by' => $this->Auth->user('user_id')]);
            $subcategories = $this->getResultArray('Categories',$query);
            if(count($subcategories)>1){
                foreach ($subcategories as $sub) {
                    $subcategoryarray[$sub['Categories']["category_id"]] = $sub['Categories']["category_name"];
                }
            } else {
                foreach ($subcategories as $sub) {
                    $subcategoryarray[$sub["category_id"]] = $sub["category_name"];
                }
            }
            
            $this->set("subcategoryarray", $subcategoryarray);
            $this->set("category", $cat);

        }else{
            $this->set("subcategoryarray", $subcategoryarray);
        }
    }
    function getCustmerAddress(){
        $cus_id = $this->request->data('Key');
//        debug($cus_id);die;
        if (is_numeric($cus_id))
        {
            $customer_reg = TableRegistry::get('customers');
            $query = $customer_reg->find('all')->where(['customer_id' => $cus_id]);
            $customer_details = $this->getResultArray('Customer',$query);
           // debug($customer_details);die;
            $main_address = '';
            if(!empty($customer_details)){
                if($customer_details['Customer']['address_line1'] != ''){
                    $main_address .= $customer_details['Customer']['address_line1'];
                }
                if($customer_details['Customer']['address_line2'] != ''){
                    $main_address .= '<br/>';
                    $main_address .= $customer_details['Customer']['address_line2'];
                }
                if($customer_details['Customer']['address_line3'] != ''){
                    $main_address .= '<br/>';
                    $main_address .= $customer_details['Customer']['address_line3'];
                }
            }
            //debug($main_address);die;
            echo $main_address;die;
//            $this->set("main_address", $main_address);
        } else {
            $main_address = '';
            echo $main_address;die;
        }
    }
    function login(){
        if ($this->Auth->user()) {
            return $this->redirect($this->Auth->redirectUrl());
        } 
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                if($user['status'] == 'Inactive'){
                    $this->Flash->error(__('User is Inactive.Kindly activate first to login'));
                    $this->redirect(array('controller'=>'admin','action' => 'login'));
                } else {
                    if(($user['is_tax_details_filled'] == '')){
                        $this->Auth->setUser($user);
                        $this->Flash->error(__('Login successful. Please fill tax details before do anything.'));
                        $this->redirect(array('controller'=>'Admin','action' => 'addTaxDetail'));
                    } else {
                        $this->Auth->setUser($user);
                        $this->Flash->success(__('Login successful'));
                        $this->redirect(array('controller'=>'admin','action' => 'adminMasterCategories'));
                    }
                }
            } else {
                $this->Flash->error(__('User Id or Password is wrong'));
                $this->redirect(array('controller'=>'admin','action' => 'login'));
            }
        }
    }
    public function logout(){
        $this->Auth->logout();
        $this->redirect(array('controller'=>'admin','action' => 'login'));
    }
    function addUser() {
        
        $categories_reg = TableRegistry::get('Categories');
        $query = $categories_reg->find('all')->where(['level' => '1','status' => 'Active','parent_category_id' => '0']);
        $parent_categories = $this->getResultArray('Categories',$query);
        if(!empty($parent_categories)){
            $pc_array = array("0"=>"Select Parent Category");
            foreach($parent_categories as $pc){
                $pc_array[$pc['Categories']['category_id']] = $pc['Categories']['category_name'];
            }
        }
        $this->set('parent_categories',$pc_array);
        
        if ($this->request->is('post')) {
            $validator = new Validator();
            $users_reg = TableRegistry::get('users');
            $this->request->data['name'] = $this->request->data['username'];
            $this->request->data['status'] = 'Inactive';
            $this->request->data['type'] = 'Admin';
            $this->request->data['created_date'] = date('Y-m-d H:m:s');
            $this->request->data['modified_date'] = date('Y-m-d H:m:s');
            $this->request->data['activation_key'] = 'abcdef1234567879ABCDEFGHIJKLMO#%$^#@DD@!XWDF#';
            $this->request->data['mapped_category_id'] = $this->request->data['category'];
            $user = $users_reg->newEntity($this->request->data);
            if ($users_reg->save($user)) {
                $user_id = $users_reg->save($user)->user_id;
                if (!empty($user_id)) {
                    $email_to = $users_reg->save($user)->email;
                    $users_reg = TableRegistry::get('users');
                    $users_reg->updateAll(['created_by' => $user_id, 'modified_by' => $user_id], ['user_id' => $user_id]);
                    $url = Router::url([
                            'controller' => 'admin',
                            'action' => 'activateAccount/key:'.'abcdef1234567879ABCDEFGHIJKLMO#%$^#@DD@!XWDF#'.'/email:'.$users_reg->save($user)->email,
                        ]);
//                    $email_queue_reg = TableRegistry::get('email_queue');
//                    $email_queue_reg->insert(['subject','email_data','template','type','email_to','email_from','attachments','cc','status','added_by','added_date'])->values([
//                            'subject' => 'Activate Account',
//                            'email_data' => $url,
//                            'template' => 'Register',
//                            'type' => 'html',
//                            'email_to' => $email_to,
//                            'email_from' => 'ecommerce@activate.com',
//                            'attachments' => '',
//                            'cc' => '',
//                            'status' => 0,
//                            'added_by' => $user_id,
//                            'added_date' => date('Y-m-d H:m:s')
//                        ]);
                }
                $this->Flash->success(__($this->Error->getError("1")));
                $this->redirect(array('controller' => 'admin', 'action' => 'login'));
            } else {
                $this->Flash->error(__($this->Error->getError("2")));
                $this->redirect(array('controller' => 'admin', 'action' => 'addUser'));
            }
        }
    }

    function deactivateCategory(){
        if($this->request->params['pass'][0] != ''){
            $cat_id = $this->request->params['pass'][0];
            $categories_reg = TableRegistry::get('Categories');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cat_status = $categories_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id' => $cat_id]);
            if($update_cat_status){
                $this->Flash->success(__($this->Error->getError("3")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            } else {
                $this->Flash->error(__($this->Error->getError("4")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("4")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
        }
    }
    
    function deactivateCustomer(){
        if($this->request->params['pass'][0] != ''){
            $customer_id = $this->request->params['pass'][0];
            $customers_reg = TableRegistry::get('Customers');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cus_status = $customers_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['customer_id' => $customer_id]);
            if($update_cus_status){
                $this->Flash->success(__($this->Error->getError("Customer deactivated successfully.")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Some error in activating user.")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! This customer Id does not exists.")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
        }
    }
    
    function activateCategory(){
        if($this->request->params['pass'][0] != ''){
            $cat_id = $this->request->params['pass'][0];
            $categories_reg = TableRegistry::get('Categories');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cat_status = $categories_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id' => $cat_id]);
            if($update_cat_status){
                $this->Flash->success(__($this->Error->getError("5")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            } else {
                $this->Flash->error(__($this->Error->getError("6")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("6")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminMasterCategories'));
        }
    }
    
    function activateCustomer(){
        if($this->request->params['pass'][0] != ''){
            $customer_id = $this->request->params['pass'][0];
            $customers_reg = TableRegistry::get('Customers');
            $modifed_date = date('Y-m-d H:m:s');
            $update_cus_status = $customers_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['customer_id' => $customer_id]);
            if($update_cus_status){
                $this->Flash->success(__($this->Error->getError("Customer Activated Successfully.")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Some error in activating user.")));
                $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! This customer Id does not exists.")));
            $this->redirect(array('controller' => 'admin', 'action' => 'adminCustomerList'));
        }
    }
    
    function activateCategoryAll(){
        if(isset($this->request->data['cat_id']) && !empty($this->request->data['cat_id'])){
                $categories_reg = TableRegistry::get('Categories');
                $modifed_date = date('Y-m-d H:m:s');
                $update_cat_status = $categories_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id IN' =>  $this->request->data['cat_id']]);
                if($update_cat_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function deactivateCategoryAll(){
        if(isset($this->request->data['cat_id']) && !empty($this->request->data['cat_id'])){
                $categories_reg = TableRegistry::get('Categories');
                $modifed_date = date('Y-m-d H:m:s');
                $update_cat_status = $categories_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['category_id IN' =>  $this->request->data['cat_id']]);
                if($update_cat_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    public function testFilter(){
        
    }
    public function uploadCategoryImage(){
        debug($this->request->data('file'));die;
        if(!empty($_FILES)){
                $file = $_FILES['file']['name'];
                //$file = parent::cleanString($file);
                if (strlen($file) <= 50) {
                    $fileprefix = 'abc'. "_" . time() . "_" . rand(1, 10000) . "_" . $file;
                    $fileNameArray = explode(".", $file);
                    $ext = $fileNameArray[count($fileNameArray) - 1];
                    $filename = '';
                    for ($n = 0; $n < count($fileNameArray) - 1; $n++) {
                        $filename = $filename . $fileNameArray[$n];
                    }
                    $filename = str_replace("_", " ", $filename);

                    if ($_FILES['file']["size"] > (Configure::read('AllowFileSize') * 1024 * 1024)) {
                        echo $this->Error->getError("3070");
                    } else if (in_array(strtolower($ext), Configure::read('AllowedFileType'))) {

//                        App::import("model", "QuestionAttachment");
//                        $this->QuestionAttachment = new QuestionAttachment();
//                        $this->QuestionAttachment->create();
//                        $attachment["QuestionAttachment"]["rfx_id"] = $rfx["Rfx"]["rfx_id"];
//                        $attachment["QuestionAttachment"]["document_name"] = $filename;
//                        $attachment["QuestionAttachment"]["document_file_name"] = $file;
//                        $attachment["QuestionAttachment"]["document_system_file_name"] = $fileprefix;
//                        $attachment["QuestionAttachment"]["question_id"] = $question_id;

                        $move_file = false;
                        if(false){
                        //if ((in_array(strtolower($ext), Configure::read('FileImageType')))) {
                            $move_upload = move_uploaded_file($_FILES['file']['tmp_name'], Configure::read('Document_Path') . "attachements/temp_attachments/" . $fileprefix);
                        } else {
                            $move_upload = move_uploaded_file($_FILES['file']['tmp_name'], Configure::read('Document_Path') . "attachements/" . $fileprefix);
                        }
                        
                        if($move_upload){
                            echo json_encode(array('status' => 'ok'));die;
                        } else {
                            echo json_encode(array('status' => 'error'));die;
                        }
//                        if ($move_file) {
//                            $attachment = parent::getSaveData('QuestionAttachment', $attachment);
//                            $rfx_id = $attachment['QuestionAttachment']['rfx_id'];
//                            $document_name = $attachment['QuestionAttachment']['document_name'];
//                            $document_file_name = $attachment['QuestionAttachment']['document_file_name'];
//                            $document_system_file_name = $attachment['QuestionAttachment']['document_system_file_name'];
//                            $destination_source = $attachment['QuestionAttachment']['destination_source'];
//
//                            $save = $this->QuestionAttachment->query("EXEC spRfxQuestionAttachmentInsert 
//                        @rfx_id='" . parent::spParams($rfx_id) . "',
//                        @question_id='" . parent::spParams($question_id) . "',
//                        @document_name='" . parent::spParams($document_name) . "',
//                        @document_file_name='" . parent::spParams($document_file_name) . "',
//                        @document_system_file_name='" . parent::spParams($document_system_file_name) . "',
//                        @destination_source='" . parent::spParams($destination_source) . "'                     
//                            ");
//                            if ($save) {
//                                // if ($this->QuestionAttachment->save($attachment)) {
//                                $last_id = $save[0][0]['InsertedId'];
//                                $last_id = $this->QuestionAttachment->id;
//                                if (Configure::read('Attachement_Source') == 'DB') {
//                                    $attachment["Attachment"]["reference_id"] = $last_id;
//                                    $attachment["Attachment"]["attachment_type"] = '9';
//                                    $attachment["Attachment"]["created_date"] = date("Y-m-d H:i:s");
//                                    $file_content = $attachment["Attachment"]["attachement_file_content"];
//                                    $file_name = $attachment["Attachment"]["attachment_file_name"];
//                                    $file_size = $attachment["Attachment"]["attachment_file_size"];
//                                    $file_type = $attachment["Attachment"]["attachment_file_type"];
//                                    $created_date = date("Y-m-d H:i:s");
//                                    $save1 = $this->Attachment->query("EXEC spAttachmentInsert 
//                                @reference_id='" . parent::spParams($attachmentid) . "',
//                                @attachment_type='9',
//                                @attachment_file_name='" . parent::spParams($file_name) . "',
//                                @attachement_file_content='" . parent::spParams($file_content) . "',
//                                @attachment_file_type='" . parent::spParams($file_type) . "',
//                                @attachment_file_size='" . parent::spParams($file_size) . "',
//
//                                @created_date='" . parent::spParams($created_date) . "'
//                        ");
//                                    // $this->Attachment->create();
//                                    // if (!$this->Attachment->save($attachment)) {
//                                    if ($save1) {
//                                        echo $this->Error->getError("3069");
//                                    }
//                                }
//                                echo "Success";
//                            } else {
//                                echo $this->Error->getError("3069");
//                            }
//                        }
                    } 
//                    else {
//                        echo $this->Error->getError("3071");
//                    }
                } else {
                    echo "Sorry! Attached filename is longer than 50 characters.";
                }
        }
    }
    public function adminAddProduct(){
        $this->viewBuilder()->layout('admin');
    }
    public function customerManagement(){
        $this->viewBuilder()->layout('admin');
        
    }
    public function adminCustomerList(){
        $this->viewBuilder()->layout('admin');
        $customer_reg = TableRegistry::get('customers');
        $query = $customer_reg->find('all');
        $customers = $this->getResultArray('Customer',$query);
        $this->set("customers",$customers);
        
    }
    
    function adminViewCustomer(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $customer_id = $this->request->params['pass'][0];
            if(trim($customer_id) == ''){
                $this->Flash->error(__('Sorry! Customer id not exists.'));
                $this->redirect(array('controller'=>'Admin','action' => 'adminCustomerList'));
            } else {
                $customer_id = $this->request->params['pass'][0];
                $customer_reg = TableRegistry::get('customers');
                $query = $customer_reg->find('all')->where(['customer_id' => $customer_id]);
                $customer = $this->getResultArray('Customer',$query);
                if(empty($customer)){
                    $this->Flash->error(__('Sorry! No such customer id exists'));
                    $this->redirect(array('controller'=>'Admin','action' => 'adminCustomerList'));
                } else {
                    $this->set("customer",$customer);
                }
            }
        }
    }
    
    
    public function adminAddCustomer(){
        $this->viewBuilder()->layout('admin');
        if ($this->request->is('post')) {
            //debug($this->request->data);die;
            
            $customer_reg = TableRegistry::get('customers');
            
            $type = trim($this->request->data['type']);
            $code = trim($this->request->data['code']);
            $customer_name = trim($this->request->data['customer_name']);
            $gstin_number = trim($this->request->data['gstin_number']);
            $pan_number = trim($this->request->data['pan_number']);
            $contact_name = trim($this->request->data['contact_name']);
            $mobile = trim($this->request->data['mobile']);
            $address_line1 = trim($this->request->data['address_line1']);
            $address_line2 = trim($this->request->data['address_line2']);
            $address_line3 = trim($this->request->data['address_line3']);
            $country_id = trim($this->request->data['country']);
            $state_id = trim($this->request->data['state']);
            $city_id = trim($this->request->data['city']);
            $pincode = trim($this->request->data['pincode']);
            $email = trim($this->request->data['email']);
            $website = trim($this->request->data['website']);
            
            $query = $customer_reg->find('all')->where(['code' => $code]);
            $customer_code_exists = $this->getResultArray('Customer',$query);
            if(empty($customer_code_exists)){
             $query = $customer_reg->query();
                    $insert = $query->insert(['customer_name','type','code','gstin_number','pan_number','contact_name','mobile','address_line1','address_line2','address_line3','country_id','state_id','city_id','pincode','email','website'])
                        ->values([
                            'customer_name' => $customer_name,
                            'type' => $type,
                            'code' => $code,
                            'gstin_number' => $gstin_number,
                            'pan_number' => $pan_number,
                            'contact_name' => $contact_name,
                            'mobile' => $mobile,
                            'address_line1' => $address_line1,
                            'address_line2' => $address_line2,
                            'address_line3' => $address_line3,
                            'country_id' => $country_id,
                            'state_id' => $state_id,
                            'city_id' => $city_id,
                            'pincode' => $pincode,
                            'email' => $email,
                            'website' => $website
                        ])
                        ->execute();
                    if($insert){
                        $this->Flash->success(__('Customer added successfully'));
                        $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                    }
            } else {
                $this->Flash->error(__('This Customer code already exists'));
                $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
            }
        }
    }
    
    function generateInvoice(){
        $this->viewBuilder()->layout('admin');
        $product_reg = TableRegistry::get('product_details');
        $query = $product_reg->find('all')->where(['created_by' => $this->Auth->user('user_id')]);
        $product_details = $this->getResultArray('Product',$query);
        $all_products= array();
        if(!empty($product_details)){
            foreach($product_details as $pd){
                $all_products[$pd['Product']['product_id']] = $pd['Product']['product_name'];
            }
        }
        $this->set("all_products",$all_products);
    }
    
    function generateInvoiceMain($po_id = null){
        $this->viewBuilder()->layout('admin');
        //debug($po_id);die;
        $customer_reg = TableRegistry::get('customers');
        $query = $customer_reg->find('all');
        $customer = $this->getResultArray('Customer',$query);
        $customers_array = array(""=>"");
        if(!empty($customer)){
            foreach($customer as $cus){
                $customers_array[$cus['Customer']['customer_id']] = $cus['Customer']['customer_name'];
            }
        }
        
        $this->set("customers",$customers_array);
        
        
        $user_tax_reg = TableRegistry::get('user_tax_mappings');
        $query = $user_tax_reg->find('all')->where(['user_id' =>  $this->Auth->user('user_id')]);
        $user_tax_mapping = $this->getResultArray('UserTaxMapping',$query);
        //debug($user_tax_mapping);
        $this->set("user_tax_mapping",$user_tax_mapping);
        
        
        
        if ($this->request->is('post')) {
            $unique_product_name_ids = $this->request->data['users_list'];
            $unique_product_ids = implode(",",$unique_product_name_ids);
            $this->set("unique_product_name_ids",$unique_product_ids);
            if(!empty($unique_product_name_ids)){
                
                
                $invoice_web_id = $this->generateInvoiceWebId();
                //debug($invoice_web_id);die;
                $this->set("invoice_web_id",$invoice_web_id);
                
                $invoice_date = date('d-M-Y');
                $this->set("invoice_date",$invoice_date);
                
                $product_reg = TableRegistry::get('product_details');
                $query = $product_reg->find('all')->where(['product_id IN' =>  $unique_product_name_ids,'created_by' => $this->Auth->user('user_id')]);
                $product_details1 = $this->getResultArray('Product',$query);
                if(!empty($product_details1)){
                    foreach($product_details1 as $key=>$product_details){
                        $mapped_cat_ids = $product_details['Product']['mapped_category_ids'];
                        $categories = str_replace('#', '', $product_details['Product']['mapped_category_ids']);
                        $categories = explode(',', $categories);
                        $cat_arr = array();
                        foreach($categories as $category){
                            $categories_reg = TableRegistry::get('Categories');
                            $query = $categories_reg->find('all')->where(['category_id' => $category]);
                            $categories = $this->getResultArray('Categories',$query);
                            //debug($categories);
                            $hsn_code_id = $categories['Categories']['hsn_code_id'];

                            //debug($hsn_code_id);

                            $hsn_details_reg = TableRegistry::get('hsn_code_details');
                            $query = $hsn_details_reg->find('all')->where(['hsn_code_id' => $hsn_code_id]);
                            $hsn_details = $this->getResultArray('HSN',$query);

                            break;
                        }
                        $product_details1[$key]['Product']['hsn_details'] = $hsn_details;
                    }
                }
                //debug($product_details1);die;
                $this->set('product_details',$product_details1);
                
                
                
                
                
                $po_issued_company_name = $user_tax_mapping['UserTaxMapping']['company_name'];
                $po_issued_company_address = $user_tax_mapping['UserTaxMapping']['company_address'];
                $po_issued_company_gstin_number = $user_tax_mapping['UserTaxMapping']['user_gstin_number'];
                $created_by = $this->Auth->user('user_id');
                $created_date = date('Y-m-d H:m:s');
                
                $po_details_reg = TableRegistry::get('po_details');
                $query = $po_details_reg->query();
                    $insert = $query->insert(['po_web_id','po_issued_company_name', 'po_issued_company_address','po_issued_company_gstin_number','created_by','created_date'])
                        ->values([
                            'po_web_id' => $invoice_web_id,
                            'po_issued_company_name' => $po_issued_company_name,
                            'po_issued_company_address' => $po_issued_company_address,
                            'po_issued_company_gstin_number' => $po_issued_company_gstin_number,
                            'created_by' => $created_by,
                            'created_date' => $created_date
                        ])
                        ->execute();
                    if($insert){
                        //debug($insert->lastInsertId('po_details'));die;
                        $po_id = $insert->lastInsertId('po_details');
                        if(!empty($product_details1)){
                            foreach($product_details1 as $prod_det){
                                
                                
                                $product_id = $prod_det['Product']['product_id'];
                                $product_name = $prod_det['Product']['product_name'];
                                $quantity = $prod_det['Product']['quantity'];
                                $price_without_tax = $prod_det['Product']['price_without_tax'];
                                $created_by = $this->Auth->user('user_id');
                                $created_date = date('Y-m-d H:m:s');
                
                                $po_item_mapping_reg = TableRegistry::get('po_item_mappings');
                                $query = $po_item_mapping_reg->query();
                                    $insert_item = $query->insert(['po_id','product_id', 'product_name','quantity','price','created_by','created_date'])
                                        ->values([
                                            'po_id' => $po_id,
                                            'product_id' => $product_id,
                                            'product_name' => $product_name,
                                            'quantity' => $quantity,
                                            'price' => $price_without_tax,
                                            'created_by' => $created_by,
                                            'created_date' => $created_date
                                        ])
                                        ->execute();
                            }
                        }
                    }
            } else {
                $this->Flash->error(__('Product name is mandatory, Please fill it.'));
                $this->redirect(array('controller'=>'Admin','action' => 'generateInvoice'));
            }
        } else {
            if($po_id != '' || $po_id != null){
                $po_item_mapping_reg = TableRegistry::get('po_item_mappings');
                $query = $po_item_mapping_reg->find('all')->where(['po_id' => $po_id]);
                $po_item_details = $this->getResultArray('Product',$query);
                $this->set("po_item_details",$po_item_details);
                
                $po_reg = TableRegistry::get('po_details');
                $query = $po_reg->find('all')->where(['po_id' => $po_id]);
                $po_details = $this->getResultArray('PO',$query);
                
                $invoice_web_id = $po_details['PO']['po_web_id'];
                
                $this->set("invoice_web_id",$invoice_web_id);
                
                $invoice_date = date('d-M-Y');
                $this->set("invoice_date",$invoice_date);
            }
        }
    }
    function generateInvoiceWebId(){
        $po_reg = TableRegistry::get('po_details');
        $query = $po_reg->find('all');
        $po_details = $this->getResultArray('PO',$query);
        $po_count = count($po_details);
        $po_count = $po_count + 1;
        $comanyString = 'INVOICE';
        $pocountpadding = str_pad($po_count, 5, "0", STR_PAD_LEFT);
        $invoicewebid = strtoupper($comanyString . "-RFX-" . $pocountpadding);
        
        $query = $po_reg->find('all')->where(['po_web_id' => $invoicewebid]);
        $po_details1 = $this->getResultArray('PO',$query);
        
        if (!empty($po_details1)) {
            return $this->countPo($comanyString, $po_count);
        } else {
            return $invoicewebid;
        }
    }
    function countPo($comanyString, $po_count) {
        $po_count = $po_count + 1;
        $pocountpadding = str_pad($po_count, 5, "0", STR_PAD_LEFT);
        $invoicewebid = strtoupper($comanyString . "-RFX-" . $pocountpadding);
        
        $po_reg = TableRegistry::get('po_details');
        $query = $po_reg->find('all')->where(['po_web_id' => $invoicewebid]);
        $po_details1 = $this->getResultArray('PO',$query);
        // $rfxwebidcheck = $this->Rfx->find("count", array("conditions" => array("rfx_web_id" => $rfxwebid)));
        if (!empty($po_details1)) {
            return $this->countPo($comanyString, $po_count);
        } else {
            return $invoicewebid;
        }
    }

    function savePoDetails(){
        if ($this->request->is('post')) {
            if(!empty($this->request->data)){
                if($this->request->data['customer_name'] != '' && $this->request->data['customer_name'] != 'No elements found' && is_numeric($this->request->data['customer_name'])){
                    $customer_id = $this->request->data['customer_name'];
                    $customer_reg = TableRegistry::get('customers');
                    $query = $customer_reg->find('all')->where(['customer_id'=>$customer_id]);
                    $customer = $this->getResultArray('Customer',$query);
                    if(!empty($customer)){
                        $customer_name = $customer['Customer']['customer_name'];
                    }   
                } else {
                    $customer_name = $this->request->data['customer_name_typed'];
                }
                
                if($this->request->data['buttopn_type'] == 1 && $customer_name == ''){
                    $this->Flash->error(__('Sorry! Invoice can not be generated. Please fill customer name first.'));
                    $this->redirect(array('controller'=>'Admin','action' => 'generateInvoice'));
                }
                
                $invoice_web_id = $this->request->data['invoice_web_id'];
                
                $billing_address = $this->request->data['billing_address'];
                $shipping_address = $this->request->data['shipping_address'];
                $modified_by = $this->Auth->user('user_id');
                $modified_date = date('Y-m-d H:m:s');
                
                $po_detail_reg = TableRegistry::get('po_details');
                $query = $po_detail_reg->find('all')->where(['po_web_id' => $invoice_web_id]);
                $po_details = $this->getResultArray('PO',$query);
                $po_id = $po_details['PO']['po_id'];
                
                $query = $po_detail_reg->query();
                $update = $query->update()
                        ->set([
                            'payment_due_date' => NULL,
                            'customer_name' => $customer_name,
                            'billing_address' => $billing_address,
                            'shipping_address' => $shipping_address,
                            'modified_by' => $modified_by,
                            'modified_date' => $modified_date
                        ])
                        ->where(['po_web_id'=>$invoice_web_id])
                        ->execute();
                if($update){
                    
                }
                
                if($this->request->data['product_ids'] != ''){
                    $product_ids = $this->request->data['product_ids'];
                    $product_id_array = explode(",",$product_ids);
                    //debug($product_id_array);die;
                    if(!empty($product_id_array)){
                        foreach($product_id_array as $product_id){
                            if(isset($this->request->data['quantity'][$product_id]) && $this->request->data['quantity'][$product_id] != ''){
                                $quantity = $this->request->data['quantity'][$product_id];
                            } else {
                                $quantity = 0;
                            }
                            
                            if(isset($this->request->data['price'][$product_id]) && $this->request->data['price'][$product_id] != ''){
                                $price_per_unit = $this->request->data['quantity'][$product_id];
                            } else {
                                $price_per_unit = 0;
                            }
                            
                            $total_price_array[] = ($price_per_unit) * $quantity;
                            
                            if(isset($this->request->data['discount'][$product_id]) && $this->request->data['discount'][$product_id] != ''){
                                $discount = $this->request->data['discount'][$product_id];
                            } else {
                                $discount = 0;
                            }
                            
                            
                            if(isset($this->request->data['taxable_amount'][$product_id]) && $this->request->data['taxable_amount'][$product_id] != ''){
                                $taxable_amount = $this->request->data['taxable_amount'][$product_id];
                            } else {
                                $taxable_amount = 0;
                            }
                            
                            $total_taxable_amount_array[] = $taxable_amount;
                            
                            if(isset($this->request->data['igst_percent'][$product_id]) && $this->request->data['igst_percent'][$product_id] != ''){
                                $igst_percent = $this->request->data['igst_percent'][$product_id];
                            } else {
                                $igst_percent = 0;
                            }
                            
                            if(isset($this->request->data['igst_amount'][$product_id]) && $this->request->data['igst_amount'][$product_id] != ''){
                                $igst_amount = $this->request->data['igst_amount'][$product_id];
                            } else {
                                $igst_amount = 0;
                            }
                            
                            $total_igst_amount_array[] = $igst_amount;
                            
                            
                            if(isset($this->request->data['cgst_percent'][$product_id]) && $this->request->data['cgst_percent'][$product_id] != ''){
                                $cgst_percent = $this->request->data['cgst_percent'][$product_id];
                            } else {
                                $cgst_percent = 0;
                            }
                            
                            if(isset($this->request->data['cgst_amount'][$product_id]) && $this->request->data['cgst_amount'][$product_id] != ''){
                                $cgst_amount = $this->request->data['cgst_amount'][$product_id];
                            } else {
                                $cgst_amount = 0;
                            }
                            
                            
                            $total_cgst_amount_array[] = $cgst_amount;
                            
                            
                            if(isset($this->request->data['sgst_percent'][$product_id]) && $this->request->data['sgst_percent'][$product_id] != ''){
                                $sgst_percent = $this->request->data['sgst_percent'][$product_id];
                            } else {
                                $sgst_percent = 0;
                            }
                            
                            if(isset($this->request->data['sgst_amount'][$product_id]) && $this->request->data['sgst_amount'][$product_id] != ''){
                                $sgst_amount = $this->request->data['sgst_amount'][$product_id];
                            } else {
                                $sgst_amount = 0;
                            }
                            
                            $total_sgst_amount_array[] = $sgst_amount;
                            
                            if(isset($this->request->data['cess'][$product_id]) && $this->request->data['cess'][$product_id] != ''){
                                $cess = $this->request->data['cess'][$product_id];
                            } else {
                                $cess = 0;
                            }
                            
                            
                            if(isset($this->request->data['misc_charges'][$product_id]) && $this->request->data['misc_charges'][$product_id] != ''){
                                $misc_charges = $this->request->data['misc_charges'][$product_id];
                            } else {
                                $misc_charges = 0;
                            }
                            
                            $modified_by = $this->Auth->user('user_id');
                            $modified_date = date('Y-m-d H:m:s');
                
                            $po_item_mapping_reg = TableRegistry::get('po_item_mappings');
                            $query = $po_item_mapping_reg->query();
                            $update_item = $query->update()
                                ->set([
                                    'quantity' => $quantity,
                                    'price' => $price_per_unit,
                                    'total_tax' => $taxable_amount,
                                    'discount' => $discount,
                                    'igst_percent' => $igst_percent,
                                    'igst_amount' => $igst_amount,
                                    'cgst_percent' => $cgst_percent,
                                    'cgst_amount' => $cgst_amount,
                                    'sgst_percent' => $sgst_percent,
                                    'sgst_amount' => $sgst_amount,
                                    'cess' => $cess,
                                    'misc_charges' => $misc_charges,
                                    'modified_by' => $modified_by,
                                    'modified_date' => $modified_date
                                ])
                                ->where(['po_id'=>$po_id,'product_id' => $product_id])
                                ->execute();
                        }
                        $this->Flash->success(__('Invoice Saved successfully'));
                        $this->redirect(array('controller'=>'Admin','action' => 'generateInvoiceMain',$po_id));
                    }
                }
            }
        }
        
    }
}
