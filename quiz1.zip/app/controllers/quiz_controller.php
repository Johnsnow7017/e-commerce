<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class QuizController extends AppController {
//    var $name = 'Actions';
	
	public function beforeFilter() {
            parent::beforeFilter();
	}
    
    public function index() {
    
        
    }
    public function exam(){
        
    }
}

?>
