-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2017 at 12:21 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `group_id` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`exam_id`, `name`, `description`, `group_id`) VALUES
(1, 'sdf', 'scdvff', '1');

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_1_mappings`
--

CREATE TABLE `exam_section_1_mappings` (
  `section_1_mapping_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `exam_web_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `i_question_id` int(11) NOT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_section_1_mappings`
--

INSERT INTO `exam_section_1_mappings` (`section_1_mapping_id`, `table_id`, `exam_web_id`, `user_id`, `i_question_id`, `correct_answer`, `given_answer`, `correct`) VALUES
(50, 1, 'SAM-EXAM-1-0001', 1, 24, 4, 1, 'No'),
(48, 1, 'SAM-EXAM-1-0001', 1, 43, 3, 1, 'No'),
(47, 1, 'SAM-EXAM-1-0001', 1, 59, 1, 1, 'Yes'),
(46, 1, 'SAM-EXAM-1-0001', 1, 34, 3, 5, 'No'),
(45, 1, 'SAM-EXAM-1-0001', 1, 25, 4, 1, 'No'),
(44, 1, 'SAM-EXAM-1-0001', 1, 54, 2, 1, 'No'),
(43, 1, 'SAM-EXAM-1-0001', 1, 31, 5, 2, 'No'),
(42, 1, 'SAM-EXAM-1-0001', 1, 41, 2, 2, 'Yes'),
(41, 1, 'SAM-EXAM-1-0001', 1, 64, 4, 2, 'No'),
(40, 1, 'SAM-EXAM-1-0001', 1, 13, 1, 1, 'Yes'),
(39, 1, 'SAM-EXAM-1-0001', 1, 51, 4, 1, 'No'),
(38, 1, 'SAM-EXAM-1-0001', 1, 16, 5, 1, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `exam_user_mgmts`
--

CREATE TABLE `exam_user_mgmts` (
  `table_id` int(11) NOT NULL,
  `exam_web_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_start_time` datetime DEFAULT NULL,
  `log_ip` varchar(200) DEFAULT NULL,
  `exam_close_time` datetime DEFAULT NULL,
  `section_1_attempted` varchar(100) NOT NULL,
  `section_2_attempted` varchar(100) DEFAULT NULL,
  `section_3_attempted` varchar(100) DEFAULT NULL,
  `section_4_attempted` varchar(100) DEFAULT NULL,
  `section_5_attempted` varchar(100) DEFAULT NULL,
  `section_1_marks` int(11) DEFAULT NULL,
  `section_2_marks` int(11) DEFAULT NULL,
  `section_3_marks` int(11) DEFAULT NULL,
  `section_4_marks` int(11) DEFAULT NULL,
  `section_5_marks` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_user_mgmts`
--

INSERT INTO `exam_user_mgmts` (`table_id`, `exam_web_id`, `user_id`, `exam_start_time`, `log_ip`, `exam_close_time`, `section_1_attempted`, `section_2_attempted`, `section_3_attempted`, `section_4_attempted`, `section_5_attempted`, `section_1_marks`, `section_2_marks`, `section_3_marks`, `section_4_marks`, `section_5_marks`) VALUES
(1, 'SAm-EXAM-1-0001', 1, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `information_ordering_questions`
--

CREATE TABLE `information_ordering_questions` (
  `info_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `information_ordering_questions`
--

INSERT INTO `information_ordering_questions` (`info_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`) VALUES
(1, 'uuuuuuuuuuuuu', 'information_ordering_test', '3', NULL, NULL),
(2, 'ppppp', 'information_ordering_test', '2', '2_1496418997_8546_Jellyfish.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `intelligent_questions`
--

CREATE TABLE `intelligent_questions` (
  `i_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intelligent_questions`
--

INSERT INTO `intelligent_questions` (`i_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`) VALUES
(1, 'AAAA', 'intelligence_test', '3', '1_1496417228_7829_Desert.jpg', NULL),
(2, 'uiui', 'intelligence_test', '2', '2_1496468824_7913_Desert.jpg', NULL),
(3, 'uiui', 'intelligence_test', '5', '3_1496468837_4251_Hydrangeas.jpg', NULL),
(4, 'uiui', 'intelligence_test', '3', '4_1496468848_7667_Penguins.jpg', NULL),
(5, 'uiui', 'intelligence_test', '5', '5_1496468860_4196_Koala.jpg', NULL),
(6, 'uiui', 'intelligence_test', '4', '6_1496468871_1832_Tulips.jpg', NULL),
(7, 'uiui', 'intelligence_test', '1', '7_1496469015_1372_Penguins.jpg', NULL),
(8, 'uiui', 'intelligence_test', '3', '8_1496469042_896_Koala.jpg', NULL),
(9, 'uiui', 'intelligence_test', '5', '9_1496469056_4991_Tulips.jpg', NULL),
(10, 'uiui', 'intelligence_test', '4', '10_1496469083_5853_Jellyfish.jpg', NULL),
(11, 'uiui', 'intelligence_test', '4', '11_1496469105_8830_Tulips.jpg', NULL),
(12, 'uiui', 'intelligence_test', '4', '12_1496469118_6262_Penguins.jpg', NULL),
(13, 'uiui', 'intelligence_test', '1', '13_1496469607_4350_Hydrangeas.jpg', NULL),
(14, 'AAAA', 'intelligence_test', '3', '1_1496417228_7829_Desert.jpg', NULL),
(15, 'uiui', 'intelligence_test', '2', '2_1496468824_7913_Desert.jpg', NULL),
(16, 'uiui', 'intelligence_test', '5', '3_1496468837_4251_Hydrangeas.jpg', NULL),
(17, 'uiui', 'intelligence_test', '3', '4_1496468848_7667_Penguins.jpg', NULL),
(18, 'uiui', 'intelligence_test', '5', '5_1496468860_4196_Koala.jpg', NULL),
(19, 'uiui', 'intelligence_test', '4', '6_1496468871_1832_Tulips.jpg', NULL),
(20, 'uiui', 'intelligence_test', '1', '7_1496469015_1372_Penguins.jpg', NULL),
(21, 'uiui', 'intelligence_test', '3', '8_1496469042_896_Koala.jpg', NULL),
(22, 'uiui', 'intelligence_test', '5', '9_1496469056_4991_Tulips.jpg', NULL),
(23, 'uiui', 'intelligence_test', '4', '10_1496469083_5853_Jellyfish.jpg', NULL),
(24, 'uiui', 'intelligence_test', '4', '11_1496469105_8830_Tulips.jpg', NULL),
(25, 'uiui', 'intelligence_test', '4', '12_1496469118_6262_Penguins.jpg', NULL),
(26, 'uiui', 'intelligence_test', '1', '13_1496469607_4350_Hydrangeas.jpg', NULL),
(27, 'AAAA', 'intelligence_test', '3', '1_1496417228_7829_Desert.jpg', NULL),
(28, 'uiui', 'intelligence_test', '2', '2_1496468824_7913_Desert.jpg', NULL),
(29, 'uiui', 'intelligence_test', '5', '3_1496468837_4251_Hydrangeas.jpg', NULL),
(30, 'uiui', 'intelligence_test', '3', '4_1496468848_7667_Penguins.jpg', NULL),
(31, 'uiui', 'intelligence_test', '5', '5_1496468860_4196_Koala.jpg', NULL),
(32, 'uiui', 'intelligence_test', '4', '6_1496468871_1832_Tulips.jpg', NULL),
(33, 'uiui', 'intelligence_test', '1', '7_1496469015_1372_Penguins.jpg', NULL),
(34, 'uiui', 'intelligence_test', '3', '8_1496469042_896_Koala.jpg', NULL),
(35, 'uiui', 'intelligence_test', '5', '9_1496469056_4991_Tulips.jpg', NULL),
(36, 'uiui', 'intelligence_test', '4', '10_1496469083_5853_Jellyfish.jpg', NULL),
(37, 'uiui', 'intelligence_test', '4', '11_1496469105_8830_Tulips.jpg', NULL),
(38, 'uiui', 'intelligence_test', '4', '12_1496469118_6262_Penguins.jpg', NULL),
(39, 'uiui', 'intelligence_test', '1', '13_1496469607_4350_Hydrangeas.jpg', NULL),
(40, 'AAAA', 'intelligence_test', '3', '1_1496417228_7829_Desert.jpg', NULL),
(41, 'uiui', 'intelligence_test', '2', '2_1496468824_7913_Desert.jpg', NULL),
(42, 'uiui', 'intelligence_test', '5', '3_1496468837_4251_Hydrangeas.jpg', NULL),
(43, 'uiui', 'intelligence_test', '3', '4_1496468848_7667_Penguins.jpg', NULL),
(44, 'uiui', 'intelligence_test', '5', '5_1496468860_4196_Koala.jpg', NULL),
(45, 'uiui', 'intelligence_test', '4', '6_1496468871_1832_Tulips.jpg', NULL),
(46, 'uiui', 'intelligence_test', '1', '7_1496469015_1372_Penguins.jpg', NULL),
(47, 'uiui', 'intelligence_test', '3', '8_1496469042_896_Koala.jpg', NULL),
(48, 'uiui', 'intelligence_test', '5', '9_1496469056_4991_Tulips.jpg', NULL),
(49, 'uiui', 'intelligence_test', '4', '10_1496469083_5853_Jellyfish.jpg', NULL),
(50, 'uiui', 'intelligence_test', '4', '11_1496469105_8830_Tulips.jpg', NULL),
(51, 'uiui', 'intelligence_test', '4', '12_1496469118_6262_Penguins.jpg', NULL),
(52, 'uiui', 'intelligence_test', '1', '13_1496469607_4350_Hydrangeas.jpg', NULL),
(53, 'AAAA', 'intelligence_test', '3', '1_1496417228_7829_Desert.jpg', NULL),
(54, 'uiui', 'intelligence_test', '2', '2_1496468824_7913_Desert.jpg', NULL),
(55, 'uiui', 'intelligence_test', '5', '3_1496468837_4251_Hydrangeas.jpg', NULL),
(56, 'uiui', 'intelligence_test', '3', '4_1496468848_7667_Penguins.jpg', NULL),
(57, 'uiui', 'intelligence_test', '5', '5_1496468860_4196_Koala.jpg', NULL),
(58, 'uiui', 'intelligence_test', '4', '6_1496468871_1832_Tulips.jpg', NULL),
(59, 'uiui', 'intelligence_test', '1', '7_1496469015_1372_Penguins.jpg', NULL),
(60, 'uiui', 'intelligence_test', '3', '8_1496469042_896_Koala.jpg', NULL),
(61, 'uiui', 'intelligence_test', '5', '9_1496469056_4991_Tulips.jpg', NULL),
(62, 'uiui', 'intelligence_test', '4', '10_1496469083_5853_Jellyfish.jpg', NULL),
(63, 'uiui', 'intelligence_test', '4', '11_1496469105_8830_Tulips.jpg', NULL),
(64, 'uiui', 'intelligence_test', '4', '12_1496469118_6262_Penguins.jpg', NULL),
(65, 'uiui', 'intelligence_test', '1', '13_1496469607_4350_Hydrangeas.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personality_test_questions`
--

CREATE TABLE `personality_test_questions` (
  `p_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `option_a` varchar(500) DEFAULT NULL,
  `option_b` varchar(500) DEFAULT NULL,
  `option_c` varchar(500) DEFAULT NULL,
  `option_d` varchar(500) DEFAULT NULL,
  `option_e` varchar(500) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personality_test_questions`
--

INSERT INTO `personality_test_questions` (`p_question_id`, `question_desc`, `question_type`, `question_img_path`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_answer`, `status`) VALUES
(1, 'jksdklsjdlksjld', 'personality_test', '1_1496423919_2358_Desert.jpg', 'hjgjhHhui', 'H', 'UIH', 'UIYH', 'UIH', '3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `quiz_id` int(11) NOT NULL,
  `quiz_name` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `selective_attension_questions`
--

CREATE TABLE `selective_attension_questions` (
  `se_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selective_attension_questions`
--

INSERT INTO `selective_attension_questions` (`se_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`) VALUES
(1, 'BBBBBBBBBBBBBBBBBBBBBBBBBBBB', 'selective_attension_test', '4', '1_1496417491_6189_Tulips.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `spatial_scanning_questions`
--

CREATE TABLE `spatial_scanning_questions` (
  `sp_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spatial_scanning_questions`
--

INSERT INTO `spatial_scanning_questions` (`sp_question_id`, `question_desc`, `question_type`, `question_img_path`, `status`) VALUES
(1, 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC', 'spatial_scanning_test', NULL, NULL),
(2, 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC', 'spatial_scanning_test', '2_1496417885_2482_Desert.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sp_question_option_mappings`
--

CREATE TABLE `sp_question_option_mappings` (
  `mapping_id` int(11) NOT NULL,
  `sp_question_id` int(11) NOT NULL,
  `shortest_route_from` varchar(100) NOT NULL,
  `option_a` varchar(20) NOT NULL,
  `option_b` varchar(20) NOT NULL,
  `option_c` varchar(20) NOT NULL,
  `option_d` varchar(20) NOT NULL,
  `option_e` varchar(20) NOT NULL,
  `correct_answer` varchar(10) NOT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_question_option_mappings`
--

INSERT INTO `sp_question_option_mappings` (`mapping_id`, `sp_question_id`, `shortest_route_from`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_answer`, `status`) VALUES
(1, 1, 'A To P', '1', '2', '3', '4', '5', '1', NULL),
(2, 1, 'B To Q', '7', '6', '4', '9', '10', '3', NULL),
(3, 1, 'C To R', '6', '8', '3', '5', '1', '1', NULL),
(4, 1, 'D To S', '2', '5', '7', '3', '1', '5', NULL),
(5, 1, 'E To T', '6', '9', '3', '10', '1', '3', NULL),
(6, 1, 'F To U', '2', '4', '7', '5', '1', '4', NULL),
(7, 1, 'H To V', '10', '9', '6', '7', '8', '4', NULL),
(8, 1, 'I To W', '4', '5', '6', '7', '8', '1', NULL),
(9, 1, 'J To X', '9', '8', '7', '6', '5', '2', NULL),
(10, 1, 'K To Y', '2', '4', '6', '8', '9', '1', NULL),
(11, 2, 'r', 'tyyu', 'tyu', 'tu', 'tyut', 'yut', '2', NULL),
(12, 2, 'ut', 'ut', 'yu', 'tgyut', 'yu', 'tyu', '3', NULL),
(13, 2, 'tyutyu', 'tyu', 't', 'yjt', 'tg', 'yut', '2', NULL),
(14, 2, 'yut', 'yut', 'yut', 'YU', 'TYU', 'TYU', '4', NULL),
(15, 2, 'TYU', 'T', 'YUT', 'YUT', 'YUT', 'YUT', '4', NULL),
(16, 2, 'YU', 'TYU', 'TYU', 'TYU', 'TYU', 'T', '2', NULL),
(17, 2, 'YUT', 'YUT', 'YU', 'TYU', 'TYU', 'T', '2', NULL),
(18, 2, 'YUT', 'YUT', 'YUT', 'YU', 'TYU', 'TYU', '4', NULL),
(19, 2, 'T', 'YUT', 'YUT', 'YU', 'TYU', 'T', '5', NULL),
(20, 2, 'YUT', 'YUT', 'YUT', 'YU', 'TYU', 'T', '2', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `type`, `status`, `created_date`, `modified_date`) VALUES
(10, 'q', 'q', '5a43542e8853035f34f77bc831c59ba97721f33d', 'Student', 'Active', '2017-06-05 10:06:45', '2017-06-05 10:06:45'),
(8, 'abc', 'abc', '16f28d03d71246d20165f5daa0393b20ef9d2dd5', 'Student', 'Active', '2017-06-05 10:06:21', '2017-06-05 10:06:21'),
(9, 'abc', 'abc', '16f28d03d71246d20165f5daa0393b20ef9d2dd5', 'Student', 'Active', '2017-06-05 10:06:34', '2017-06-05 10:06:34'),
(11, 'p', 'p', '5608db379935e0425055aaf4f368fe04c4ae9851', 'Student', 'Active', '2017-06-05 11:06:01', '2017-06-05 11:06:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_section_1_mappings`
--
ALTER TABLE `exam_section_1_mappings`
  ADD PRIMARY KEY (`section_1_mapping_id`);

--
-- Indexes for table `exam_user_mgmts`
--
ALTER TABLE `exam_user_mgmts`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `information_ordering_questions`
--
ALTER TABLE `information_ordering_questions`
  ADD PRIMARY KEY (`info_question_id`);

--
-- Indexes for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  ADD PRIMARY KEY (`i_question_id`);

--
-- Indexes for table `personality_test_questions`
--
ALTER TABLE `personality_test_questions`
  ADD PRIMARY KEY (`p_question_id`);

--
-- Indexes for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  ADD PRIMARY KEY (`se_question_id`);

--
-- Indexes for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  ADD PRIMARY KEY (`sp_question_id`);

--
-- Indexes for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  ADD PRIMARY KEY (`mapping_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `exam_section_1_mappings`
--
ALTER TABLE `exam_section_1_mappings`
  MODIFY `section_1_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `exam_user_mgmts`
--
ALTER TABLE `exam_user_mgmts`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `information_ordering_questions`
--
ALTER TABLE `information_ordering_questions`
  MODIFY `info_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  MODIFY `i_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `personality_test_questions`
--
ALTER TABLE `personality_test_questions`
  MODIFY `p_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  MODIFY `se_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  MODIFY `sp_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  MODIFY `mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
