<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class QuizzesController extends AppController {
//    var $name = 'Actions';
	var $uses = array("exam","intelligent_question");
	public function beforeFilter() {
            parent::beforeFilter();
            $this->Auth->allow("register","intelligence_test");
	}
    
    public function index() {
    
        
    }
    public function intelligence_test(){
        $exams = $this->exam->query("SELECT *FROM intelligent_questions ORDER BY RAND() LIMIT 10");
        $intelligent_questions = parent::getDataAll('IntelligentQuestions', $exams);
        $count_questions = count($intelligent_questions);
        $this->set("intelligent_questions",$intelligent_questions);
        if(!empty($this->data)){
            debug($this->data);
            
            if(isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])){
                foreach($this->data['quiz']['answer'] as $key=>$correct_answers){
                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
                        
//                    debug($given_answer);
                    
                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $question_id = $key;
                    
                    $intelligence_exam_select = $this->exam->query("select * from exam_section_1_mappings where table_id = '".$table_id."' and exam_web_id='".$exam_web_id."' and user_id='".$user_id."'and i_question_id='".$question_id."'");
                    $intelligence_exam_select = parent::getData('IntelligenceTest', $intelligence_exam_select);
                    
                    if(empty($intelligence_exam_select)){
                        if($given_answer != ''){
                            if($correct_answer == $given_answer){
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_1_mappings set table_id = '".$table_id."',exam_web_id='".$exam_web_id."',user_id='".$user_id."',i_question_id='".$question_id."',correct_answer='".$correct_answer."',given_answer='".$given_answer."',correct='".$correct."'");
                        }
                    } else {
                        if($given_answer != ''){
                            if($correct_answer == $given_answer){
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_1_mappings set correct_answer='".$correct_answer."',given_answer='".$given_answer."',correct='".$correct."' where table_id = '".$table_id."' and exam_web_id='".$exam_web_id."' and user_id='".$user_id."' and i_question_id='".$question_id."'");
                        } else {
                           $intelligence_exam_select = $this->exam->query("delete from exam_section_1_mappings where table_id = '".$table_id."' and exam_web_id='".$exam_web_id."' and user_id='".$user_id."' and i_question_id='".$question_id."'"); 
                        }
                    }
//                }
                }
            }
            
            if(isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0){
                
                //Save button code
            } elseif($this->data['quiz']['form_type'] == 1){
                //submit button code
            }
        }
        //$this->set("count_questions",$count_questions);
                                   
        
    }
    
    public function randomQuestionKey($count_questions){
        return rand(0,$count_questions);
    }
    
    public function timeover_intelligence_test_main(){
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quiz", "action" => "selective_instructions"));
        }
    }
    public function exam_instruction(){}
    
    public function exam_instruction_next(){}
    
    public function test1_instruction(){}
    
    public function selective_instructions(){
        
    }
    
    public function third(){
        
    }
    
}

?>
