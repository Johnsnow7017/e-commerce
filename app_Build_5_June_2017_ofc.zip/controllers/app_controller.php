<?php

/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright 2005-2012, Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
App::import('Sanitize');

class AppController extends Controller {
    var $components = array('Session', 'Auth');
//    var $components = array('Session', 'Auth', 'RequestHandler', 'Email', "Cookie");
    var $helpers = array('Form');
   


    //var $helpers = array('Cache', 'Session', 'Form', 'Html', 'Paginator', 'Js', 'Ajax', 'Javascript', "DateFormat", "DatePicker", "Dberror", "LocalTime", "ExPaginator", "FileExtension", "Currency", "Pdf", "Type", "Permission", "Nocsrf");

    function __construct() {
        parent::__construct();
        App::import('model', 'connection_manager');
        $db = ConnectionManager::getInstance();
        @$connected = $db->getDataSource('default');
        if (!isset($_GET["errortype"])) {
            if (!$connected->isConnected()) {
//               echo "DB Connection Failed.";
                $this->cakeError('error404',array(array('url'=>'/'))); 
                die();
            } else {
                
            }
        }
    }

//    function beforeFilter() {
//        
// //      debug($this->Auth);
////        if(isset($_POST) && count($_POST) > 0){
////            $_POST = $this->getRequestData($_POST);            
////        }
////        if(isset($_GET) && count($_GET) > 0){
////            $_GET = $this->getRequestData($_GET);            
////        }        
////        if(isset($this->params['named']) && count($this->params['named']) > 0){
////            $this->params['named'] = $this->getRequestData($this->params['named']);            
////        }
////        if(isset($this->params['pass']) && count($this->params['pass']) > 0){
////            $this->params['pass'] = $this->getRequestData($this->params['pass']);            
////        }
////        if(isset($this->params['data']) && count($this->params['data']) > 0){
////            $this->params['data'] = $this->getRequestData($this->params['data']);            
////        }        
//         
//        if (Configure::read('buyerHost') != Configure::read('supplierHost')) {
//            if (isset($this->params['prefix']) && $this->params['prefix'] == 'admin' && $_SERVER["HTTP_HOST"] == Configure::read('supplierHost')) {
//                $this->Session->write("activeDashboard", "");
//                $this->Session->write("logged_admin_id", "");
//                $this->Session->write("logged_admin_company_id", "");
//                $this->Session->write("verify_bid", "");
//                $this->Session->write("UserCompany", "");
//                $this->Session->write("vendorAsBuyer", "");
//                $this->Session->write("SupplierId", "");
//                $this->Session->write("SupplierCompanyId", "");
//                
//                $this->_flash("Sorry! You are not allowed to access the URL", "error");
//                $this->redirect($this->Auth->logout());
//                die();
//            }
//
//            if ($this->Auth->user()) {
//                $companyDetails = $this->Session->read('UserCompany');
//                if ($_SERVER["HTTP_HOST"] == Configure::read('supplierHost') && $companyDetails["Company"]['buyer'] == "Yes") {
//                    $this->Session->write("activeDashboard", "");
//                    $this->Session->write("logged_admin_id", "");
//                    $this->Session->write("logged_admin_company_id", "");
//                    $this->Session->write("verify_bid", "");
//                    $this->Session->write("UserCompany", "");
//                    $this->Session->write("vendorAsBuyer", "");
//                    $this->Session->write("SupplierId", "");
//                    
//                    $this->_flash("Sorry! You are not allowed to access the URL", "error");
//                    $this->redirect($this->Auth->logout());
//                    die();
//                }
//            }
//        }
//
//        $this->set('ssoButtonCheck', false);
//        $checkIP = false;
//        if (isset($this->params['prefix']) && $this->params['prefix'] == 'admin') {
//            $checkIP = true;
//        } else if ($this->Auth->user()) {
//            $companyDetails = $this->Session->read('UserCompany');
//            if ($companyDetails["Company"]['buyer'] == "Yes") {
//                $checkIP = true;
//            }
//        }
//
//        if (Configure::read('IPCHECK') === true) {
//            $allowedIP = Configure::read('IPCHECKRANGE');
//            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
//                $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_FORWARDED_FOR'];
//            }
//            $flag = false;
//            foreach ($allowedIP as $ip) {
//                $ip1 = str_replace("*", "0", $ip);
//                $ip2 = str_replace("*", "255", $ip);
//                $ip1 = ip2long($ip1);
//                $ip2 = ip2long($ip2);
//                $givenip = $_SERVER['REMOTE_ADDR'];
//                $givenip = ip2long($givenip);
//                if ($givenip >= $ip1 && $givenip <= $ip2) {
//                    $flag = true;
//                    break;
//                } else {
//                    
//                }
//            }
//
//            if ($flag == true) {
//                $this->set('ssoButtonCheck', true);
//            } else {
//
//                if ($checkIP == true) {
//                    $this->_flash("Sorry! You are not allowed to access the URL", "error");
//                    $this->redirect($this->Auth->logout());
//                    die();
//                }
//            }
//        }
//
//        if ($this->Auth->user()) {
//            if (isset($this->params['prefix']) && $this->params['prefix'] == 'admin') {
//                $companyDetails = $this->Session->read('UserCompany');
//                if ($companyDetails["Company"]['buyer'] == "No") {
//                    $this->_flash("Sorry! You are not allowed to access the URL", "error");
//                    $this->redirect($this->Auth->logout());
//                }
//            }
//        }
//        
//
//        /*
//          $postData = array();
//          $postDataChanged = false;
//          $loggedUserCompanyDetails = $this->Session->read('UserCompany');
//          if($this->Auth->user()) {
//          if(isset($loggedUserCompanyDetails["Company"]["buyer"]) && $loggedUserCompanyDetails["Company"]["buyer"] == "Yes") {
//          if(isset($this->data) && count($this->data) > 0) {
//          $postData = $this->cleanPostData($this->data, $postDataChanged);
//          $this->data = $postData;
//          }
//          if(isset($_POST) && count($_POST) > 0) {
//          $postData = $this->cleanPostData($_POST, $postDataChanged);
//          $_POST = $postData;
//          }
//          if($postDataChanged == true) {
//          $this->AuditTrailLog($this->Auth->user("user_id"), Router::url( $this->here, true).": Input data modified due to invalid characters", $this->Auth->user("user_id"));
//          $this->_flash("Input data modified due to invalid characters. Kindly verify the changes. ", "notice");
//          }
//          }
//          }
//         */
//
//        /*** Authentication settings */
//        $this->Auth->loginRedirect = array('controller' => 'dashboard', 'action' => 'index');
//        $this->Auth->authError = "Please login to continue...";
//        $this->Auth->allow("curlRequest");
//        $this->Auth->autoRedirect = false;
//        //debug($this->Auth->user());
//        if (isset($_GET["buyerSwitch"]) && $_GET["buyerSwitch"] != '') {
//            //debug($this->Auth->user());
//            // debug($this->Session->read("SupplierId"));
//            $this->Session->write("activeDashboard", $_GET["buyerSwitch"]);
//            if ($_GET["buyerSwitch"] == 'Supplier') {
//
//                $currentuser = $this->User->query("EXEC spUserEditSelect @user_id='" . $this->spParams($this->Session->read("SupplierId")) . "'");
//                $currentuser = $this->getData('User', $currentuser);
//                //$currentuser = $this->User->find('first', array('conditions' => array('User.user_id' => $userId)));
//                $this->Auth->logout();
//                $this->Auth->login($currentuser);
//                $this->Session->write("AuthUser", $this->Auth->user());
//                App::import("model", "Company");
//                $this->Company = new Company();
//                $UserCompany = $this->Company->query("EXEC spUserSsoCompanySelect @company_id='" . $this->spParams($currentuser['User']['company_id']) . "'");
//                $UserCompany = $this->getData('Company', $UserCompany);
////                    $UserCompany = $this->Company->find("first", array("conditions" => array("company_id" => $this->Auth->user("company_id"))));
//                $this->Session->write("UserCompany", $UserCompany);
//
//                $this->redirect(array("controller" => "dashboard", "action" => "index"));
//            } else if ($_GET["buyerSwitch"] == 'Buyer') {
//                if($this->Session->read("SupplierId")==''){
//                $this->Session->write("SupplierId", $this->Auth->user('user_id'));
//                $this->Session->write("SupplierCompanyId", $this->Auth->user('company_id'));
//                }
//                App::import("model", "SupplierBuyerMapping");
//                $this->SupplierBuyerMapping = new SupplierBuyerMapping();
//                //debug($this->Auth->user());
//                //$buyer = $this->SupplierBuyerMapping->find('first', array('conditions' => array('SupplierBuyerMapping.supplier_id' => $this->Auth->user('company_id'),'SupplierBuyerMapping.switch_buyer'=>'Yes')));
//                $buyer = $this->SupplierBuyerMapping->query("EXEC spSupplierBuyerMappingSelectMappingNew @supplier_user_id='" .$this->spParams($this->Session->read("SupplierId")) . "',@supplier_company_id='" .$this->spParams($this->Session->read("SupplierCompanyId")) . "'");
//                $buyer = $this->GetData('SupplierBuyerMapping', $buyer);
//                $currentuser = $this->User->query("EXEC spUserEditSelect @user_id='" . $this->spParams($buyer['SupplierBuyerMapping']['buyer_user_id']) . "'");
//                $currentuser = $this->getData('User', $currentuser);
//                $this->Auth->logout();
//                $this->Auth->login($currentuser);
//                $this->Session->write("AuthUser", $this->Auth->user());
//                App::import("model", "Company");
//                $this->Company = new Company();
//                $UserCompany = $this->Company->query("EXEC spUserSsoCompanySelect @company_id='" . $this->spParams($currentuser['User']['company_id']) . "'");
//                $UserCompany = $this->getData('Company', $UserCompany);
////                    $UserCompany = $this->Company->find("first", array("conditions" => array("company_id" => $this->Auth->user("company_id"))));
//                $this->Session->write("UserCompany", $UserCompany);
//                // debug($currentuser);
//            }
//        }
//        /*         * * BOF changes to switch between RFX and auction by Nitin Sharma 14-November-2013 */
//        if ((isset($_GET['dashboardSwitch']) && $_GET['dashboardSwitch'] != '')) {
//            $this->Session->write('dashboardType', $_GET['dashboardSwitch']);
//        } else if ($this->Session->read("dashboardType") == 'Auction') {
//            $this->Session->write('dashboardType', 'Auction');
//        } else {
//            $this->Session->write('dashboardType', 'RFX');
//        }
//        if ($this->Session->read("dashboardType") == 'Auction') {
//            
//        }
//
//        /*         * * EOF changes to switch between RFX and auction by Nitin Sharma 14-November-2013 */
//        if (isset($this->params['named']["swicthto"]) && $this->params['named']["swicthto"] == 'admin') {
//            if ($this->Session->read("logged_admin_id") != "") {
//                /*                 * * SPCHANGE by Abhinav on 5-Dec-2014 ** */
//                $user_exists = $this->User->query("EXEC spUserEditSelect @user_id='" . $this->spParams($this->Session->read("logged_admin_id")) . "'");
//                $user_exists = $this->getData('User', $user_exists);
////                $user_exists = $this->User->find('first', array('conditions' => array('User.user_id' => $this->Session->read("logged_admin_id"))));
//                if (!empty($user_exists)) {
//                    $this->AuditTrailLog($this->Auth->user("user_id"), Configure::read('AccountLoggedOut'), $this->Session->read('logged_admin_id'));
//                    $this->Auth->logout();
//                    $this->Auth->login($user_exists);
//                    $this->Session->write("AuthUser", $this->Auth->user());
//
//                    App::import("model", "Company");
//                    $this->Company = new Company();
//                    /*                     * * SPCHANGE by Abhinav on 5-Dec-2014 ** */
//                    $UserCompany = $this->Company->query("EXEC spUserSsoCompanySelect @company_id='" . $this->spParams($this->Auth->user("company_id")) . "'");
//                    $UserCompany = $this->getData('Company', $UserCompany);
////                    $UserCompany = $this->Company->find("first", array("conditions" => array("company_id" => $this->Auth->user("company_id"))));
//                    $this->Session->write("UserCompany", $UserCompany);
//
//                    $this->redirect(array("controller" => "admin", "action" => "users"));
//                }
//            }
//        }
//        
//        /*
//         * To check if Supplier is marked as buyer  or not - S Anand 17 Feb 2016
//         */
//        if($this->Auth->user()){
//        if ($this->Session->read("activeDashboard") == "Buyer") {
//            $this->Session->write("vendorAsBuyer", "");
//        } else {
//            App::import("model", "Company");
//            $this->Company = new Company();
//            $buyer = $this->Company->query("EXEC spSupplierBuyerMappingSelectMappingNew @supplier_user_id='" .$this->spParams($this->Auth->user('user_id')) . "',@supplier_company_id='".$this->spParams($this->Auth->user('company_id'))."'");
//            $buyer = $this->GetData('SupplierBuyerMapping',$buyer);
//            if(!empty($buyer)){
//            $this->Session->write("vendorAsBuyer", 1);
//            }else{
//            $this->Session->write("vendorAsBuyer", '');    
//            }
//        }
//        }
//        $this->Cookie->path = '/';
//        $this->Cookie->name = 'SAPP';
//        /*
//          $inputtagValue = '';
//          if(isset($this->data) && isset($this->data["Tag"]["Name"]) && $this->data["Tag"]["Name"] != "") {
//          Configure::write("inputvalue", addslashes($this->data["Tag"]["Name"]));
//          } else {
//          Configure::write("inputvalue", '');
//          }
//         * 
//         */
//    }
    
        function cleanPostData($dataArray, &$flag) {
        $finalArray = array();
        if (count($dataArray) > 0) {
            foreach ($dataArray as $key => $value) {
                if (is_array($value)) {
                    $finalArray[$key] = $this->cleanPostData($dataArray[$key], $flag);
                } else {
                    $cleanString = Sanitize::paranoid(Sanitize::stripImages(Sanitize::stripScripts(html_entity_decode($value))), Configure::read('AllowSpecialChar'));
                    $finalArray[$key] = str_replace(chr(0), '', $cleanString);
                    if (html_entity_decode($value) != $cleanString) {
                        $flag = true;
                    }
                }
            }
        }
        return $finalArray;
    }

//    function cleanPostData($dataArray, &$flag) {
//        $finalArray = array();
//        if (count($dataArray) > 0) {
//            foreach ($dataArray as $key => $value) {
//                if (is_array($value)) {
//                    $finalArray[$key] = $this->cleanPostData($dataArray[$key], $flag);
//                } else {
//                    if(json_decode($value)){
//                        $value = json_decode($value);
//                    }
//                    
////                    if (is_string ($value)){
//                        
//                    $cleanString = Sanitize::paranoid(Sanitize::stripImages(Sanitize::stripScripts(@html_entity_decode($value))), Configure::read('AllowSpecialChar'));
//                    
//                    $finalArray[$key] = str_replace(chr(0), '', $cleanString);
//                    if (html_entity_decode($value) != $cleanString) {
//                        $flag = true;
//                    }
////                    }
//                }
//            }
//        }
//        return $finalArray;
//    }

    function cleanPostDataImageAllowed($dataArray, &$flag) {
        $finalArray = array();
        if (count($dataArray) > 0) {
            foreach ($dataArray as $key => $value) {
                if (is_array($value)) {
                    $finalArray[$key] = $this->cleanPostDataImageAllowed($dataArray[$key], $flag);
                } else {
                    $cleanString = $this->stripJavaScripts($value);
                    $finalArray[$key] = str_replace(chr(0), '', $cleanString);
                    if ($value != $cleanString) {
                        $flag = true;
                    }
                }
            }
        }
        return $finalArray;
    }

    function stripJavaScripts($str) {
        return preg_replace('/<script[^>]*>.*?<\/script>/is', '', $str);
    }

    function cleanString($string) {
        $string = str_replace(chr(0), '', $string);
        return Sanitize::paranoid(Sanitize::stripImages(Sanitize::stripScripts($string)), Configure::read('AllowSpecialChar'));
    }

    function specialCharAllowedMessage() {
        $this->_flash("You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed", "error");
    }

    function specialCharAllowedAjaxMessage() {
        return "You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed";
    }

    function beforeRender() {
//        $this->set('loggedUser', $this->Auth->user());
//        $this->set('loggedUserCompnay', $this->Session->read('UserCompany'));
//        $this->set('activeDashboard', $this->Session->read("activeDashboard"));
//        $this->set('adminLoginId', $this->Session->read("logged_admin_id"));
//        /*         * * Changes to switch between RFX and auction by Nitin Sharma 14-November-2013 */
//        $this->set('dashboardType', $this->Session->read("dashboardType"));
//        $this->set('superadmin', $this->Permission->isSuperAdmin());
//        $this->set('vendorAsBuyer', $this->Session->read("vendorAsBuyer"));
    }

    function checkAdmin() {
        $this->layout = "admin";
        if (!$this->Permission->isAdmin()) {
            $this->render("/errors/admin");
        }
    }
    function checkNormal() {
		if($this->Permission->isTeamLead()){
			//$this->redirect(array("controller" => "dashboard", 'action' => "index"));
			//$this->redirect("../dashboard/index");
		}
		else if($this->Permission->isOnlyTeamLead()){
           $this->redirect("../admin/users/users_report");
           // $this->redirect(array("controller" => "users", 'action' => "admin_users_report",'admin'=>false));
            //$this->redirect("../dashboard/teamlead_reports");
        }
        else if ($this->Permission->isAdmin()) {
            
        } else if (!$this->Permission->isUser()) {
            $this->redirect($this->Auth->logout());
        } else if ($this->Permission->isOnlySupplierApprover()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
//        /*** Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
        } else if ($this->Permission->isOnlyRequestor()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        } else {
            if (!$this->Permission->isDraftSupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    /*                     * * Added Message by Ashish Jain on 03-Dec-2013 for showing not Approved error message */
                    //   $this->_flash("Your profile is not complete. Kinldy complete your profile & submit the data to access other pages.", "error");
                    $this->_flash("Complete your profile below to get quick buyer attention. It will take only 2 minutes.", "error");

                    $this->redirect(array("controller" => "suppliers", 'action' => "profile"));
                }
            } else if (!$this->Permission->isApporvedsupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    /*                     * * Added Message by Ashish Jain on 03-Dec-2013 for showing not Approved error message */
                    $this->_flash($this->Error->getError("127"), "error");
                    $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
                }
            }
        }
        /*         * * EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
    }

    function checkOnlyNormal() {
        if ($this->Permission->isAdmin()) {
            
        } else if (!$this->Permission->isUser()) {
            $this->redirect($this->Auth->logout());
            /*             * * Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
        } else {
            if (!$this->Permission->isApporvedsupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    /*                     * * Added Message by Ashish Jain on 03-Dec-2013 for showing not Approved error message */
                    $this->_flash($this->Error->getError("127"), "error");
                    $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
                }
            }
        }
        /*         * * EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
    }
    /*      * *Added condition by lokesh garg for new role buyer support on 9-nov-2015  */
        function checkBuyerSupport() {
        if ($this->Permission->isAdmin()) {
            
        } else if (!$this->Permission->isUser()) {
            $this->redirect($this->Auth->logout());
        } else if ($this->Permission->isOnlySupplierApprover()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        } else if ($this->Permission->isOnlyRequestor()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        } else {
            if (!$this->Permission->isDraftSupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    //   $this->_flash("Your profile is not complete. Kinldy complete your profile & submit the data to access other pages.", "error");
                    $this->_flash("Complete your profile below to get quick buyer attention. It will take only 2 minutes.", "error");

                    $this->redirect(array("controller" => "suppliers", 'action' => "profile"));
                }
            } else if (!$this->Permission->isApporvedsupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    /*                     * * Added Message by Ashish Jain on 03-Dec-2013 for showing not Approved error message */
                    $this->_flash($this->Error->getError("127"), "error");
                    $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
                }
            }
        }
    }
    /*      ##EOF   */
      /*      * *Added condition by lokesh garg for new role buyer support on 9-nov-2015  */
    function checkOnlyBuyerSupport() {
        if ($this->Permission->isAdmin()) {
            
        } else if (!$this->Permission->isUser()) {
            $this->redirect($this->Auth->logout());
        } else {
            if (!$this->Permission->isApporvedsupplier()) {
                if ($this->params['controller'] != "suppliers") {
                    $this->_flash($this->Error->getError("127"), "error");
                    $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
                }
            }
        }
    }
      /*      ##EOF   */
    function checkOnlyRequestor() {
        if ($this->Permission->isOnlyRequestor()) {
            $this->redirect(array("controller" => "dashboard", 'action' => "pr_index"));
        }
        /*         * * EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
    }
    function checkActivityOwner() {
        if ($this->Permission->isOnlyActivityOwner()) {
            $this->redirect(array("controller" => "dashboard", 'action' => "activity_dashboard"));
        } else {
            return true;
        }
        /*         * * EOF Check if user is activity owner or only approver. By lokesh garg on 07-Aug-2016 */
    }
    function checkOnlyTechEvaluator() {
        if ($this->Permission->isOnlyTechEvaluator()) {
            $this->redirect(array("controller" => "dashboard", 'action' => "activity_dashboard"));
        }
        /*         * * EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
    }

    function checkOnlyAuditor() {
        if ($this->Permission->isOnlyAuditor()) {
            $this->redirect(array("controller" => "dashboard", 'action' => "activity_dashboard"));
        }
        /*         * * EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
    }

//    function checkOnlyApprover() {
//        if($this->Permission->isRfxAuctionApprover()) {
//                $this->redirect(array("controller" => "dashboard", 'action' => "activity_dashboard"));
//        } 
//        /*** EOF Check if user is approved OR not. By Ashish Jain on 26-Nov-2013 */
//    }
    function checkCommerceEvaluator() {
        if ($this->Permission->isCommerceEvaluator()) {
            
        } else {
            $this->_flash($this->Error->getError("151"), "error");
            $this->redirect($this->referer());
        }
    }

    function checkBuyer() {
        $UserCompany = $this->Session->read('UserCompany');
        if ($UserCompany["Company"]["buyer"] == "Yes") {
            return true;
        } else {
            return false;
        }
    }

    function checkAdminSession() {
        
    }

    /**
     *
     * @param int $receiver_id
     * @param int $rfx_id
     * @param string $notification
     * @param string $notification_type
     * @param int $sender_id
     */
    function notification($receiver_id, $rfx_id = null, $notification = "", $sender_id, $notification_type = null, $description, $rfx_web_id, $buyer_company = null, $supplier_company = null, $message = null, $supplier_company_list = null, $link = null, $rfxDetails = null, $is_auction = null, $receiver_user_id = null, $msgattachments = null) {		
   
	  if (!empty($description)) {
            $personalizations = $this->search_personalizations($description);
            $description = $this->replacePlaceHolder($description, $personalizations, $rfx_web_id, $buyer_company, $supplier_company, $message, $supplier_company_list, $rfxDetails, $msgattachments);
	  }
        if (!empty($link["notification_link"]) && $link["notification_link"] != null) {
            $description .= '<br /><a style="text-decoration: underline;" target="_blank" href="' . $link["notification_link"] . '">here</a>';
        }
        if (!empty($link["attachment_link"]) && $link["attachment_link"] != null) {
            $attachments = $link["attachment_link"];
        }
        if (!empty($notification)) {
            $personalizations = $this->search_personalizations($notification);
            $notification = $this->replacePlaceHolder($notification, $personalizations, $rfx_web_id, $buyer_company, $supplier_company);
        }
        App::import("model", "Notification");
        $this->Notification = new Notification();
        $this->Notification->create();
        $notificationdata["Notification"]["rfx_id"] = $rfx_id;
        $notificationdata["Notification"]["notification_text"] = $notification;
        $notificationdata['Notification']['notification_description'] = nl2br($description);
        if (!empty($notification_type)) {
            $notificationdata["Notification"]["notification_type"] = $notification_type;
        } else {
            $notificationdata["Notification"]["notification_type"] = 'System';
        }
        if ($is_auction != null && $is_auction != "") {
            $notificationdata['Notification']['is_auction'] = $is_auction;
        }
        else
            $notificationdata['Notification']['is_auction'] = 0;
        $notificationdata['Notification']['notification_attachment'] = @$attachments;
        $notificationdata["Notification"]["created_date"] = date("Y-m-d H:i:s");
        $notificationdata = $this->getSaveData('Notification', $notificationdata);		

		
        $save = $this->Notification->query("EXEC spNotificationInsert
            @rfx_id='" . $this->spParams($notificationdata["Notification"]["rfx_id"]) . "',
            @notification_text='" . $this->spParams($notificationdata["Notification"]["notification_text"]) . "', 
            @notification_description='" . $this->spParams($notificationdata["Notification"]["notification_description"]) . "',
            @notification_type='" . $this->spParams($notificationdata["Notification"]["notification_type"]) . "',   
            @is_auction='" . $this->spParams($notificationdata["Notification"]["is_auction"]) . "',
            @notification_attachment='" . $this->spParams($notificationdata["Notification"]["notification_attachment"]) . "', 
            @created_date='" . $this->spParams($notificationdata["Notification"]["created_date"]) . "'
            ");
        if ($save) {
            // if ($this->Notification->save($notificationdata)) {
            //    $inserted_notification_id = $this->Notification->getInsertId();
            $inserted_notification_id = $save[0][0]['InsertedId'];
            if ($receiver_user_id == null || $receiver_user_id == '') {
                $receiver_user_id = '';
            }			
            $this->notificationMapping($inserted_notification_id, $sender_id, $receiver_id, $receiver_user_id);
            return $inserted_notification_id;
        } else {
            return null;
        }
    }

    function search_personalizations($body) {
        $personalizations = array();
        $matches = array();
        $pattern = '/\[\[[^\]]+\]\]/';
        if (preg_match_all($pattern, $body, $matches) < 1) {
            return $personalizations;
        }
        foreach ($matches[0] as $str) {
            $p = array();
            $p['search'] = $str;
            $a = explode('|', trim($str, '[]'));
            $p['field'] = $a[0];
            $p['default'] = (isset($a[1])) ? $a[1] : false;
            array_push($personalizations, $p);
        }
        return $personalizations;
    }

    function replacePlaceHolder($body, $personalizations, $rfx_web_id, $buyer_company_name = null, $supplier_company_name = null, $message = null, $supplier_company_list = null, $rfxDetails = null, $msgattachments = null) {
        foreach ($personalizations as $p) {
            switch (strtolower($p['field'])) {
                case 'rfxid':
                    $replace = $rfx_web_id;
                    break;
                case 'auctionid':
                    $replace = $rfx_web_id;
                    break;
                case 'requestid':
                    $replace = $rfx_web_id;
                    break;
                case 'suppliername':
                    $replace = $supplier_company_name;
                    break;
                case 'buyername':
                    $replace = $buyer_company_name;
                    break;
                case 'message':
                    $replace = $message;
                    break;
                case 'listofsupplier':
                    $replace = "";
                    foreach ($supplier_company_list as $supplier_company) {
                        $replace .= "<br/>";
                        $replace .= $supplier_company;
                    }
                    break;
                case 'deadline':
                    $replace = $rfxDetails['deadline'];
                    break;
                case 'attachmentlist':
                    $replace = "";
                    foreach ($msgattachments as $attachment_id => $attachment_name) {

                        $replace .= "<a href='" . Router::url(array('controller' => "rfx_responses", 'action' => "download_msg_attachment/attachmentid:" . $attachment_id), true) . "'>" . $attachment_name . "</a>";
                        $replace .= "<br/>";
                    }
                    break;
            }
            $body = str_replace($p['search'], $replace, $body);
        }
        return $body;
    }

    /**
     *
     * @param int $notification_id
     * @param int $sender_id
     * @param int $receiver_id
     */
    function notificationMapping($notification_id, $sender_id, $receiver_id, $receiver_user_id = null) {
        App::import("model", "NotificationUser");
        $this->NotificationUser = new NotificationUser();
        $this->NotificationUser->create();
        $notificationdata["NotificationUser"]["notification_id"] = $notification_id;
        $notificationdata["NotificationUser"]["sender_id"] = $sender_id;
        $notificationdata["NotificationUser"]["receiver_id"] = $receiver_id;
        if ($receiver_user_id != null && $receiver_user_id != "") {
            $notificationdata["NotificationUser"]["receiver_user_id"] = $receiver_user_id;
        }
        $save = $this->NotificationUser->query("EXEC spNotificationMappingInsert
            @notification_id='".$this->spParams($notification_id)."',
            @sender_id='".$this->spParams($sender_id)."',
            @receiver_id='".$this->spParams($receiver_id)."',
            @receiver_user_id='".$this->spParams($receiver_user_id)."'");

        // $this->NotificationUser->save($notificationdata);
    }

    function AuditTrailLog($user_id, $description, $created_by, $rfx_web_id = null, $notification_id = null, $adminFlag = false, $loggedIn_user = null, $is_auction = null,$is_admin_change = null) {
        App::import("model", "AuditTrail");
         App::import("model", "Rfx");
         App::import("model", "User");
          App::import("model", "Company");
         $this->Rfx = new Rfx();
        $this->User = new User();
        $this->AuditTrail = new AuditTrail();
        $this->Company = new Company();
        $this->AuditTrail->create();
        $audittraildata["AuditTrail"]["user_id"] = $user_id;
        $audittraildata["AuditTrail"]["description"] = $description;
        $audittraildata["AuditTrail"]["rfx_web_id"] = $rfx_web_id;
        $audittraildata["AuditTrail"]["notification_id"] = $notification_id;
        $audittraildata["AuditTrail"]["log_ip"] = $_SERVER["REMOTE_ADDR"];
        $log_ip = $_SERVER["REMOTE_ADDR"];
        $audittraildata["AuditTrail"]["created_date"] = date("Y-m-d H:i:s");
        $created_date = date("Y-m-d H:i:s");
        if ($is_auction != null && $is_auction != '') {
            $audittraildata["AuditTrail"]["is_auction"] = $is_auction;
        } else {
            $is_auction = 0;
        }
        /*
        * Audit trail changes for adding company id  By S Anand on 19 May 2015
        */
        if($rfx_web_id==null){
            if($is_admin_change == true){
             $company_id = $this->Auth->user("company_id");   
            }else{
            $company_id = 0;
            }
        }else{
            $company_id='';
            //For rfx
            if($is_auction==0){
               $event_details = $this->Rfx->query("EXEC spRfxCompanyIdSelectById @rfx_id='".$this->spParams($rfx_web_id)."'");
               $event_details = $this->getData('RFX', $event_details);
               if(!empty($event_details)){
                   $company_id= $event_details['RFX']['company_id'];
               }
               //For PO  
            }elseif ($is_auction==3) {
                        $po_details = $this->Rfx->query("EXEC spPoDetailSelectByPoWebId @po_web_id='" . $this->spParams($rfx_web_id) . "'");
                        $po_details = $this->getData('Rfx', $po_details);

               if(!empty($po_details)){
                   $company_id= $po_details['Rfx']['po_creator_company_id'];
               
               }
            }else{
                //For auction
                $event_details = $this->Rfx->query("EXEC spAuctionCompanyIdSelectById @auction_id='".$this->spParams($rfx_web_id)."'");
                $event_details = $this->getData('RFX', $event_details);
               if(!empty($event_details)){
                   $company_id= $event_details['RFX']['company_id'];
               }
            }
        }
        
        /*
        * Audit trail changes for adding is_buyer By S Anand on 19 May 2015
        */
         $companyid = $this->User->query("EXEC spUsersSelectCompanyId @user_id='".$this->spParams($user_id)."'");
         $companyid = $this->getData('User', $companyid);
         $is_buyer='';
         if(!empty($companyid)){
             $company_data = $this->Company->query('EXEC spUserEditCompanySelect @company_id="' . $this->spParams($companyid['User']['company_id']) . '"');
             $user_company_result = $this->getData('Company', $company_data);
             
             if(!empty($user_company_result)){
                 if($user_company_result['Company']['buyer']=='Yes'){
                     $is_buyer='Yes';
                 }else{
                     $is_buyer='No';
                 }
             }
         }
         
          if($is_admin_change == true){
              /*
               * In case when admin edits supplier profile $is_admin_change id passed as true
               */
             $is_buyer = 'Yes';   
            }else if($is_admin_change == false && $is_buyer=='Yes'){
                /*
                 * In case of login/logout $is_admin_change id passed as false
                 */
             $company_id = $this->Auth->user("company_id");   
            }
        if ($this->Session->read("logged_admin_id") != "") {
            if ($adminFlag == true) {
                $audittraildata["AuditTrail"]["created_by"] = $created_by;
            } else {
                $audittraildata["AuditTrail"]["created_by"] = $this->Session->read("logged_admin_id");
            }
        } else if ($loggedIn_user == "admin") {
            $audittraildata["AuditTrail"]["created_by"] = 1;
        } else {
            $audittraildata["AuditTrail"]["created_by"] = $created_by;
        }
        $createdby = $audittraildata["AuditTrail"]["created_by"];
        //  $this->AuditTrail->save($audittraildata);
        //$description = preg_replace("/'/", "''", $description);
        $save = $this->AuditTrail->query("EXEC spAuditInsert '".$this->spParams($user_id)."','".$this->spParams($description)."','".$this->spParams($rfx_web_id)."','".$this->spParams($notification_id)."','".$this->spParams($log_ip)."','".$this->spParams($created_date)."','".$this->spParams($createdby)."','".$this->spParams($is_auction)."','".$this->spParams($is_buyer)."','".$this->spParams($company_id)."'");
 
        }

    function _flash($message, $type = 'message') {
        $messages = (array) $this->Session->read('Message.multiFlash');
        if ($type == "error") {
            $type = "errorbox";
        } else if ($type == "success") {
            $type = "succesbox";
        } else if ($type == "information") {
            $type = "informationbox";
        } else if ($type == "notice") {
            $type = "warningbox";
        }
        $messages[] = array(
            'message' => '<div class="simple-tips albox  ' . $type . '">' . $message . '<a original-title="Close" href="#" class="close tips">close</a></div>',
            'layout' => 'default',
            'element' => 'default',
            'params' => array('class' => 'msg'),
        );
        $this->Session->write('Message.multiFlash', $messages);
    }

    function sendMail($to, $subject, $data, $template, $type = "html", $attachments = array(), $cc = array(), $company_id = null) {
//        $this->Email->smtpOptions = array(
//            'port' => Configure::read('SMTP_PORT'),
//            'timeout' => Configure::read('SMTP_TIMEOUT'),
//            'host' => Configure::read('SMTP_HOST'),
//            'username' => Configure::read('SMTP_USERNAME'),
//            'password' => Configure::read('SMTP_PASSWORD')
//        );
        if (isset($data['company_company_id']) && $data['company_company_id'] != '') {
            $this->Email->smtpOptions = array();
            $email_config_data = $this->Company->query("EXEC spCompanySelectEmailConfig @company_id='" . $this->spParams($data['company_company_id']) . "'");
            if (isset($email_config_data[0][0]['smtp_port']) && @trim($email_config_data[0][0]['smtp_port']) != '') {
                $this->Email->smtpOptions['port'] = trim($email_config_data[0][0]['smtp_port']);
            } else {
                $this->Email->smtpOptions['port'] = Configure::read('SMTP_PORT');
            }
            if (isset($email_config_data[0][0]['smtp_host']) && @trim($email_config_data[0][0]['smtp_host']) != '') {
                $this->Email->smtpOptions['host'] = trim($email_config_data[0][0]['smtp_host']);
            } else {
                $this->Email->smtpOptions['host'] = Configure::read('SMTP_HOST');
            }
            if (isset($email_config_data[0][0]['smtp_username']) && @trim($email_config_data[0][0]['smtp_username']) != '') {
                $this->Email->smtpOptions['username'] = trim($email_config_data[0][0]['smtp_username']);
            } else {
                $this->Email->smtpOptions['username'] = Configure::read('SMTP_USERNAME');
            }
            if (isset($email_config_data[0][0]['smtp_password']) && @trim($email_config_data[0][0]['smtp_password']) != '') {
                $this->Email->smtpOptions['password'] = trim($email_config_data[0][0]['smtp_password']);
            } else {
                $this->Email->smtpOptions['password'] = Configure::read('SMTP_PASSWORD');
            }
            if (isset($email_config_data[0][0]['email_footer']) && @$email_config_data[0][0]['email_footer'] != '') {
                $data['email_footer'] = nl2br($email_config_data[0][0]['email_footer']);
            } else {
                $data['email_footer'] = 'This is an automated message from Samsung. Please do not reply to this message.<br /><br />
                                        Thanks & regards<br />
                                        Team Samsung';
            }
            $this->Email->smtpOptions['timeout'] = Configure::read('SMTP_TIMEOUT');
        } else {
            $this->Email->smtpOptions = array(
                'port' => Configure::read('SMTP_PORT'),
                'timeout' => Configure::read('SMTP_TIMEOUT'),
                'host' => Configure::read('SMTP_HOST'),
                'username' => Configure::read('SMTP_USERNAME'),
                'password' => Configure::read('SMTP_PASSWORD'),
            );
        }

        if (!isset($data['email_footer']) && @$data['email_footer'] == '') {
            $data['email_footer'] = 'This is an automated message from Samsung. Please do not reply to this message.<br /><br />
                                Thanks & regards<br/>
                                Team Samsung';
        }

        $this->Email->delivery = Configure::read('MAIL_SYSTEM');
        $this->Email->to = $to;

        $this->Email->subject = $subject;
        if (isset($email_config_data[0][0]['from_email']) && isset($email_config_data[0][0]['from_name']) && $email_config_data[0][0]['from_name'] != '' && $email_config_data[0][0]['from_email'] != '') {
            $this->Email->from = $email_config_data[0][0]['from_name'] . '<' . $email_config_data[0][0]['from_email'] . '>';
        } else {
            $this->Email->from = Configure::read('FROM_EMAIL');
        }
        $this->Email->from = $this->Email->from;
        $this->Email->cc = $cc;
        if (count($attachments) > 0) {
            $this->Email->attachments = $attachments;
        } else {
            unset($this->Email->attachments);
        }
        $this->set('EMAILDATA', $data);

        $this->Email->template = $template; // note no '.ctp'
        $this->Email->sendAs = $type; // because we like to send pretty mail
        
        App::import("model", "EmailQueue");
		$this->EmailQueue = new EmailQueue();
		$this->EmailQueue->create();
		$emailQueueData = array();
		$emailQueueData["EmailQueue"]['subject'] = $subject;
                //$data=$this->getSerializeSaveData($data);
		$emailQueueData["EmailQueue"]['email_data'] = serialize($data);
		$emailQueueData["EmailQueue"]['template'] = $template;
		$emailQueueData["EmailQueue"]['type'] = $type;
		$emailQueueData["EmailQueue"]['email_to'] = $to;
		$emailQueueData["EmailQueue"]['email_from'] = Configure::read('FROM_EMAIL');
		$emailQueueData["EmailQueue"]['status'] = 0;
		$emailQueueData["EmailQueue"]['attachments'] = serialize($attachments);
		$emailQueueData["EmailQueue"]['added_date'] = date("Y-m-d H:i:s");
                $emailQueueData["EmailQueue"]['cc'] = serialize($cc);
		//$this->EmailQueue->save($emailQueueData);
                $emailQueueData = $this->getSaveData('EmailQueue', $emailQueueData);
                $this->EmailQueue->query("EXEC spEmailQueueInsert
                    @subject='".$this->spParams($emailQueueData["EmailQueue"]['subject'])."',
                    @email_data='".$this->spParams($emailQueueData["EmailQueue"]['email_data'])."',
                    @template='".$this->spParams($emailQueueData["EmailQueue"]['template'])."',
                    @type='".$this->spParams($emailQueueData["EmailQueue"]['type'])."',
                    @email_to='".$this->spParams($emailQueueData["EmailQueue"]['email_to'])."',
                    @email_from='".$this->spParams($emailQueueData["EmailQueue"]['email_from'])."',
                    @status='".$this->spParams($emailQueueData["EmailQueue"]['status'])."',
                    @attachments='".$this->spParams($emailQueueData["EmailQueue"]['attachments'])."',
                    @added_date='".$this->spParams($emailQueueData["EmailQueue"]['added_date'])."',
                    @cc='".$this->spParams($emailQueueData["EmailQueue"]['cc'])."'");
		return "True";
                /** Removed Direct Processing of Email. Email Added in Queue
                $this->Email->send();
                $this->set('smtp_errors', $this->Email->smtpError);
                if ($this->Email->smtpError != "") {
                    $this->set('sendemail', "false");
                    return $this->Email->smtpError;
                } else {
                    $this->set('sendemail', "true");
                    return "True";
                }*/
    }

    function webroot() {
        if ($this->Session->read("activeDashboard") == "Buyer") {
            $this->redirect(Configure::read("buyerURL"));
        } else {
            $this->redirect(Configure::read("supplierURL"));
        }
    }

    function getLocalTime($event, $eventTimeZone, $localTimeZone = '') {
        /*         * * Convert event time to GMT */
        $etz = new DateTime(date('Y-m-d'), new DateTimeZone($eventTimeZone));
        $etzo = $etz->getOffset();
        $gmt = strtotime($event) - $etzo;

        /*         * * Convert GMT time to users local time */
        if ($localTimeZone == "") {
            $localTimeZone = Configure::read('Default_Timezone');
        }
        $utz = new DateTime(date('Y-m-d'), new DateTimeZone($localTimeZone));
        $utzo = $utz->getOffset();
        $lt = $gmt + $utzo;
        return date('Y-m-d H:i:s', $lt);
    }

    function getCompanyName($comanyId) {
        App::import("model", "Company");
        $this->Company = new Company();
        //$company = $this->Company->find("first", array("conditions" => array("company_id" => $comanyId)));
        /*         * * SPCHANGE by S Anand on 14-Nov-2014 */
        $company_data = $this->Company->query("EXEC spCompanyNameSelect @company_id='".$this->spParams($comanyId)."'");
        $company = $this->getData("Company", $company_data);
        if ($company) {
            return $company["Company"]["company_name"];
        } else {
            return false;
        }
    }

    /**
     *
     * @param int $actions_type
     * @param string $actions_url
     * @param string $actions_description
     * @param int $actons_receiver_id
     * @param int $actions_rfx_id
     * @param int $action_sender_is
     * return int
     */
    function actions($actions_type, $actions_url, $actions_description, $actions_receiver_id, $actions_rfx_id, $actions_sender_id, $is_auction = null, $receiver_user_id = null, $sender_user_id = null) {
        App::import("model", "Action");
        $this->Action = new Action();

        //$action_exists = $this->Action->find("first", array("conditions" => array("sender_user_id" => $sender_user_id, "receiver_user_id" => $receiver_user_id, "actions_receiver_id" => $actions_receiver_id, "actions_sender_id" => $actions_sender_id, 'actions_rfx_id' => $actions_rfx_id, 'actions_type' => $actions_type, 'actions_status' => 0)));
        $action_exists = $this->Action->query("EXEC spActionCount @sender_user_id='".$this->spParams($sender_user_id)."',@receiver_user_id='".$this->spParams($receiver_user_id)."',@actions_receiver_id='".$this->spParams($actions_receiver_id)."',@actions_sender_id='".$this->spParams($actions_sender_id)."',@actions_rfx_id='".$this->spParams($actions_rfx_id)."',@actions_type='".$this->spParams($actions_type)."',@actions_status='0'");
        if ($action_exists === true) {
            if ($is_auction != null && $is_auction != "") {
                $data['Action']['is_auction'] = $is_auction;
            } else {
                $data['Action']['is_auction'] = 0;
            }
            if ($receiver_user_id != null && $receiver_user_id != "") {
                $data['Action']['receiver_user_id'] = $receiver_user_id;
            }
            if ($sender_user_id != null && $sender_user_id != "") {
                $data['Action']['sender_user_id'] = $sender_user_id;
            } else {
                $data['Action']['sender_user_id'] = NULL;
            }
            $data['Action']['actions_type'] = $actions_type;
            $data['Action']['actions_url'] = $actions_url;
            $data['Action']['actions_description'] = $actions_description;
            $data['Action']['actions_receiver_id'] = $actions_receiver_id;
            $data['Action']['actions_rfx_id'] = $actions_rfx_id;
            $data['Action']['actions_sender_id'] = $actions_sender_id;
            $data['Action']['actions_status'] = 0;
            $data['Action']['actions_created_date'] = date("Y-m-d H:i:s");
            //$this->Action->save($data);
            $data = $this->getSaveData('Action', $data);
            $save = $this->Action->query("EXEC spActionInsert
                  @is_auction='" . $this->spParams($data['Action']['is_auction']) . "',
                  @receiver_user_id='" . $this->spParams($data['Action']['receiver_user_id']) . "',
                  @sender_user_id='" . $this->spParams($data['Action']['sender_user_id']) . "',
                  @actions_type='" . $this->spParams($data['Action']['actions_type']) . "',
                  @actions_url='" . $this->spParams($data['Action']['actions_url']) . "',
                  @actions_description='" . $this->spParams($data['Action']['actions_description']) . "',
                  @actions_receiver_id='" . $this->spParams($data['Action']['actions_receiver_id']) . "',
                  @actions_rfx_id='" . $this->spParams($data['Action']['actions_rfx_id']) . "',
                  @actions_sender_id='" . $this->spParams($data['Action']['actions_sender_id']) . "',
                  @actions_status='" . $this->spParams($data['Action']['actions_status']) . "', 
                  @actions_created_date='" . $this->spParams($data['Action']['actions_created_date']) . "'
                  
                    ");
            // $actions_id = $this->Action->getInsertID();
            $actions_id = $save[0][0]['InsertedId'];
            return $actions_id;
        } else if (count($action_exists) > 0) {
            return null;
        } else {
            if ($is_auction != null && $is_auction != "") {
                $data['Action']['is_auction'] = $is_auction;
            } else {
                $data['Action']['is_auction'] = 0;
            }
            if ($receiver_user_id != null && $receiver_user_id != "") {
                $data['Action']['receiver_user_id'] = $receiver_user_id;
            }
            if ($sender_user_id != null && $sender_user_id != "") {
                $data['Action']['sender_user_id'] = $sender_user_id;
            } else {
                $data['Action']['sender_user_id'] = NULL;
            }
            $data['Action']['actions_type'] = $actions_type;
            $data['Action']['actions_url'] = $actions_url;
            $data['Action']['actions_description'] = $actions_description;
            $data['Action']['actions_receiver_id'] = $actions_receiver_id;
            $data['Action']['actions_rfx_id'] = $actions_rfx_id;
            $data['Action']['actions_sender_id'] = $actions_sender_id;
            $data['Action']['actions_status'] = 0;
            $data['Action']['actions_created_date'] = date("Y-m-d H:i:s");
            //$this->Action->save($data);
            $data = $this->getSaveData('Action', $data);
            $save = $this->Action->query("EXEC spActionInsert
                  @is_auction='" . $this->spParams($data['Action']['is_auction']) . "',
                  @receiver_user_id='" . $this->spParams($data['Action']['receiver_user_id']) . "',
                  @sender_user_id='" . $this->spParams($data['Action']['sender_user_id']) . "',
                  @actions_type='" . $this->spParams($data['Action']['actions_type']) . "',
                  @actions_url='" . $this->spParams($data['Action']['actions_url']) . "',
                  @actions_description='" . $this->spParams($data['Action']['actions_description']) . "',
                  @actions_receiver_id='" . $this->spParams($data['Action']['actions_receiver_id']) . "',
                  @actions_rfx_id='" . $this->spParams($data['Action']['actions_rfx_id']) . "',
                  @actions_sender_id='" . $this->spParams($data['Action']['actions_sender_id']) . "',
                  @actions_status='" . $this->spParams($data['Action']['actions_status']) . "', 
                  @actions_created_date='" . $this->spParams($data['Action']['actions_created_date']) . "'
                  
                    ");
            // $actions_id = $this->Action->getInsertID();
            $actions_id = $save[0][0]['InsertedId'];
            return $actions_id;
        }
    }

    function getSuppliersList($rfx_id) {
        $supplier_array = array();
        App::import('model', 'RfxResponseDashboard');
        $this->RfxResponseDashboard = new RfxResponseDashboard();
        // $response_lists = $this->RfxResponseDashboard->find('all', array('conditions' => array('RfxResponseDashboard.rfx_id' => $rfx_id, 'RfxResponseDashboard.registered' => 'Yes', 'RfxResponseDashboard.invited !=' => 'Deleted')));
        $response_lists = $this->RfxResponseDashboard->query("EXEC spRfxResponseDashboardSuppliersList @rfx_id='".$this->spParams($rfx_id)."'");
        $response = array('response_id', 'rfx_id', 'supplier_company_id','supplier_user_id', 'company_name');
        $invited = array('invited_supplier_id');
        #######sequence of model name should be in corrensponding to data array#######
        $model = array('RfxResponseDashboard', 'RfxInvitedSupplier');
        $data = array($response, $invited);
        $response_lists = $this->getJoinData($response_lists, $data, $model);
        $company_id=array();
        foreach ($response_lists as $response) {
            if(!in_array($response['RfxResponseDashboard']['supplier_user_id'],$company_id)){                
                $user_id = $response['RfxResponseDashboard']['supplier_user_id'];            
                $user_details = $this->RfxResponseDashboard->query("EXEC spUsersSelectByUserId @user_id='".$this->spParams($user_id)."'");
                
                $user_details = $this->getData('User', $user_details);
                if(count($user_details) > 0){
                    $supplier_array[] = array('company_id' => $response['RfxResponseDashboard']['supplier_company_id'], 'company_name' => $response['RfxResponseDashboard']['company_name'], 'invited_supplier_id' => $response['RfxInvitedSupplier']['invited_supplier_id'], 'supplier_user_name' => $user_details['User']['name']);                
                    $company_id[]=$response['RfxResponseDashboard']['supplier_user_id'];
                }
            }
        }
        return $supplier_array;
    }
function getSuppliersList1($rfx_id) {
        $supplier_array = array();
        App::import('model', 'RfxResponseDashboard');
        $this->RfxResponseDashboard = new RfxResponseDashboard();
        // $response_lists = $this->RfxResponseDashboard->find('all', array('conditions' => array('RfxResponseDashboard.rfx_id' => $rfx_id, 'RfxResponseDashboard.registered' => 'Yes', 'RfxResponseDashboard.invited !=' => 'Deleted')));
        $response_lists = $this->RfxResponseDashboard->query("EXEC spRfxResponseDashboardSuppliersList @rfx_id='".$this->spParams($rfx_id)."'");
        $response = array('response_id', 'rfx_id', 'supplier_company_id','supplier_user_id', 'company_name');
        $invited = array('invited_supplier_id');
        #######sequence of model name should be in corrensponding to data array#######
        $model = array('RfxResponseDashboard', 'RfxInvitedSupplier');
        $data = array($response, $invited);
        $response_lists = $this->getJoinData($response_lists, $data, $model);
        //$company_id=array();
        foreach ($response_lists as $response) {            
            $user_id = $response['RfxResponseDashboard']['supplier_user_id'];            
            $user_details = $this->RfxResponseDashboard->query("EXEC spUsersSelectByUserId @user_id='".$this->spParams($user_id)."'");
            
            $user_details = $this->getData('User', $user_details);
            if(count($user_details) > 0){
                //if(!in_array($response['RfxResponseDashboard']['supplier_company_id'],$company_id)){
                $supplier_array[] = array('company_id' => $response['RfxResponseDashboard']['supplier_company_id'], 'company_name' => $response['RfxResponseDashboard']['company_name'], 'invited_supplier_id' => $response['RfxInvitedSupplier']['invited_supplier_id'], 'supplier_user_name' => $user_details['User']['name']);
            }
        
            //$company_id[]=$response['RfxResponseDashboard']['supplier_company_id'];
            //}
            
        }
        return $supplier_array;
    }
    /*     * * Function Created By Ashish Jain for getting the invited suppliers on 05-Dec-2013 */

    function getAuctionSuppliersList($auction_id) {
        $supplier_array = array();
        App::import('model', 'AuctionInvitedSupplier');
        $this->AuctionInvitedSupplier = new AuctionInvitedSupplier();
        //$response_lists = $this->AuctionInvitedSupplier->find("all", array("conditions" => array("auction_id" => $auction_id, "status !=" => "Deleted")));
        $response_lists = $this->AuctionInvitedSupplier->query("EXEC spAuctionInvitedSupplierSelectByAuctionIdAndStatus @auction_id = '".$this->spParams($auction_id)."', @status='Deleted'");
        $response_lists = $this->getDataAll('AuctionInvitedSupplier', $response_lists);        
        //$company_id=array();
        foreach ($response_lists as $response) {
            
            $user_id = $response['AuctionInvitedSupplier']['supplier_user_id'];            
            $user_details = $this->AuctionInvitedSupplier->query("EXEC spUsersSelectByUserId @user_id='".$this->spParams($user_id)."'");
            
            $user_details = $this->getData('User', $user_details);
            //if(!in_array($response['AuctionInvitedSupplier']['company_id'],$company_id)){
            if(count($user_details) > 0){
                $supplier_array[] = array('company_id' => $response['AuctionInvitedSupplier']['company_id'], 'company_name' => $response['AuctionInvitedSupplier']['company_name'], 'invited_supplier_id' => $response['AuctionInvitedSupplier']['invited_supplier_id'], 'supplier_user_name' => $user_details['User']['name']);
            }
        
            //$company_id[]=$response['AuctionInvitedSupplier']['company_id'];
            //}
            }
        return $supplier_array;
    }
    
    function getAuctionSuppliersList1($auction_id) {
        $supplier_array = array();
        App::import('model', 'AuctionInvitedSupplier');
        $this->AuctionInvitedSupplier = new AuctionInvitedSupplier();
        //$response_lists = $this->AuctionInvitedSupplier->find("all", array("conditions" => array("auction_id" => $auction_id, "status !=" => "Deleted")));
        $response_lists = $this->AuctionInvitedSupplier->query("EXEC spAuctionInvitedSupplierSelectByAuctionIdAndStatus @auction_id = '".$this->spParams($auction_id)."', @status='Deleted'");
        $response_lists = $this->getDataAll('AuctionInvitedSupplier', $response_lists);
        $company_id=array();
        foreach ($response_lists as $response) {
            $user_detail = $this->AuctionInvitedSupplier->query("EXEC spUsersSelectId @user_id='".$this->spParams($response['AuctionInvitedSupplier']['supplier_user_id'])."'");
            $user_detail = $this->getData('User',$user_detail);
            $supplier_array[] = array('user_id'=>$response['AuctionInvitedSupplier']['supplier_user_id'],'name'=>$user_detail['User']['name'],'company_id' => $response['AuctionInvitedSupplier']['company_id'], 'company_name' => $response['AuctionInvitedSupplier']['company_name']);

            }
        return $supplier_array;
    }

    /*     * * EOF Function Created By Ashish Jain for getting the invited suppliers on 05-Dec-2013 */

    function getFileExtension($filename) {
        $fileTypes = array("accdb", "avi", "bmp", "css", "doc", "docx", "eml", "eps", "fla", "gif", "html", "ind", "ini", "jpeg", "jsf", "midi", "mov", "mp3", "mpeg", "pdf", "png", "ppt", "pptx", "proj", "psd", "pst", "pub", "rar", "readme", "settings", "text", "tiff", "url", "vsd", "wav", "wma", "wmv", "xls", "xlsx", "zip");
        $img_size = 24;
        if ($filename == "") {
            return array("default.png", "document", $img_size);
        } else {
            $filenameArray = explode(".", $filename);
            $index = count($filenameArray) - 1;
            $ext = $filenameArray[$index];
            if (in_array($ext, $fileTypes) === true) {
                return array($ext . ".png", strtoupper($ext), $img_size);
            } else {
                return array("default.png", "document", $img_size);
            }
        }
    }

    function curlRequest($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $userDataJson = curl_exec($ch);
        $error = curl_error($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
    }

    /*     * * BOF function to check the min 5 hours for draft auction before republishing it */

    function checkRepublish($auction_id = null) {
        if (!empty($auction_id)) {
            App::import('model', 'Auction');
            $this->Auction = new Auction();
            // $auctions = $this->Auction->find('first', array('conditions' => array('auction_web_id' => $auction_id), 'fields' => array('parent_id', 'auction_id')));
            $auctions = $this->Auction->query("EXEC spAuctionSelectIdByAuctionWebId @auction_web_id = '".$this->spParams($auction_id)."'");
            $auctions = $this->getData('Auction', $auctions);
            if ($auctions) {
                if ($auctions['Auction']['parent_id'] != 0) {
                    //$parent_auction = $this->Auction->find('first', array('conditions' => array('auction_id' => $auctions['Auction']['parent_id'])));
                    $auctiondetails = $this->Auction->query("EXEC spAuctionSelectByAuctionId @auction_id='" . $this->spParams($auctions['Auction']['parent_id']) . "'");
                    $parent_auction = $this->getData('Auction', $auctiondetails);
                    $start_date = $parent_auction['Auction']['auction_start_date'];
                    $time_zone_id = $parent_auction['Auction']['time_zone_id'];

                    $newdate = $this->LocalTime->getTime($time_zone_id, $start_date);
                    $localDate = date("Y-m-d H:i:s");

                    $fivehourdate = strtotime('+5 hours', strtotime($localDate));
                    $fivehourdate = date('Y-m-d H:i:s', $fivehourdate);

                    if (strtotime($fivehourdate) >= strtotime($newdate)) {
                        $this->_flash($this->Error->getError("3239"), "error");
                        $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
                    }
                }
            }
        }
    }

    function currencyConverter($from_currency, $to_currency, $price) {
        if (!empty($price)) {
            if ($from_currency != $to_currency) {
                $this->Currency = new Currency();
                // $currencies = $this->Currency->find("all");
                $currency_data = $this->Currency->query("EXEC spCurrencySelectAll");
                $currencies = $this->getDataAll('Currency', $currency_data);
                foreach ($currencies as $currency) {
                    $currencyList[$currency["Currency"]["currency_id"]] = $currency["Currency"]["value"];
                }
                //$this->set("currencies", $currencyList);
                //$fromCurrencyVal = $currencyList[$from_currency];
                $reported_val = $currencyList[$to_currency] / $currencyList[$from_currency] * $price;

                return $reported_val;
            } else {
                return $price;
            }
        }
    }

    // function to check the user type viewer
    function notAllowViewer() {
        if ($this->Permission->isViewer() && !$this->Permission->isNormalOrAdmin()) {
            $this->_flash($this->Error->getError("134"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        }
    }

    function isOnlyApprover() {
        if ($this->Permission->isOnlyApprover() && !$this->Permission->isNormalOrAdmin()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        }
    }

    function notAllowTechnicalEvaluator() {
        if ($this->Permission->isOnlyTechEvaluator()) {
            $this->_flash($this->Error->getError("161"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "supplier_error"));
        }
    }

    function get_child_auction($auction_id, &$auction_array) {
        //$auction = $this->Auction->find("first",array('conditions' => array('auction_id' => $auction_id)));
        $auction_array[] = $auction_id;
        /*         * * SPCHANGE by Abhinav on 24-Nov-2014 */
        $auction = $this->Auction->query("EXEC spAuctionSelectByChildId @child_id='".$this->spParams($auction_id)."'");
        $auction = $this->getData('Auction', $auction);
//        $auction = $this->Auction->find("first", array('conditions' => array('child_id' => $auction_id)));
        if (!empty($auction)) {
            if ($auction['Auction']['auction_id'] != null && $auction['Auction']['auction_id'] != 0) {
                return $this->get_child_auction($auction['Auction']['auction_id'], $auction_array);
            }
        }
        return $auction_array;
    }

    function get_child_rfx($rfx_id, &$auction_array) {
        $auction_array[] = $rfx_id;
        // $rfx = $this->Rfx->find("first", array('conditions' => array('child_id' => $rfx_id)));
        $rfx = $this->Rfx->query("EXEC spRfxIdSelectByChildId @child_id='".$this->spParams($rfx_id)."'");
        $rfx = $this->getData('Rfx', $rfx);
        if ($rfx['Rfx']['rfx_id'] != null && $rfx['Rfx']['rfx_id'] != 0) {
            return $this->get_child_rfx($rfx['Rfx']['rfx_id'], $auction_array);
        }
        return $auction_array;
    }

    function get_parent_auction($auction_id, &$auction_array) {
        // $auction = $this->Auction->find("first", array('conditions' => array('auction_id' => $auction_id)));
        $auctiondetails = $this->Auction->query("EXEC spAuctionSelectByAuctionId @auction_id='".$this->spParams($auction_id)."'");
        $auction = $this->getData('Auction', $auctiondetails);
        $auction_array[] = $auction['Auction']['auction_id'];
        if ($auction['Auction']['child_id'] != null && $auction['Auction']['child_id'] != 0) {
            return $this->get_parent_auction($auction['Auction']['child_id'], $auction_array);
        }
        return $auction_array;
    }

    function get_parent_rfx($rfx_id, &$auction_array) {
        $auction_array[] = $rfx_id;
        // $rfx = $this->Rfx->find("first", array('conditions' => array('rfx_id' => $rfx_id)));
        $rfx_details = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='".$this->spParams($rfx_id)."'");
        $rfx = $this->getData('Rfx', $rfx_details);
        //$buyerDetails = $this->User->read(null, $rfxdetails
        if ($rfx['Rfx']['child_id'] != null && $rfx['Rfx']['child_id'] != 0) {
            return $this->get_parent_rfx($rfx['Rfx']['child_id'], $auction_array);
        }
        return $auction_array;
    }

//    function get_parent_auction($auction_id ,&$auction_array) {
//        $auction = $this->Auction->find("first",array('conditions' => array('auction_id' => $auction_id)));
//        $auction_array[] = $auction_id;
//        $auction = $this->Auction->find("first",array('conditions' => array('auction_id' => $auction['Auction']['child_id'])));
//        if($auction['Auction']['auction_id'] != null && $auction['Auction']['auction_id'] != 0) {
//            return $this->get_child_auction($auction['Auction']['auction_id'] , $auction_array);
//        }
//        return $auction_array;
//    }

    function get_first_parent_rfx($rfx_id) {
        // $rfx = $this->Rfx->find("first", array('conditions' => array('rfx_id' => $rfx_id)));
        $rfx_details = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='".$this->spParams($rfx_id)."'");
        $rfx = $this->getData('Rfx', $rfx_details);
        if ($rfx['Rfx']['parent_id'] != null && $rfx['Rfx']['parent_id'] != 0) {
            return $this->get_first_parent_rfx($rfx['Rfx']['parent_id']);
        }
        return $rfx_id;
    }

    function getMsgAttachmentFile($rfx_id, $is_auction) {
        $this->layout = false;
        $this->autoRender = false;
        App::import("model", "MsgAttachment");
        $this->MsgAttachment = new MsgAttachment();
        App::import("model", "Attachment");
        $this->Attachment = new Attachment();
        $attach_files = array();
        // $attahements = $this->MsgAttachment->find("all", array("conditions" => array("rfx_auction_id" => $rfx_id, "is_sent" => "0", "is_auction" => $is_auction, 'uploaded_by' => $this->Auth->user("user_id")), "order" => "MsgAttachment.document_name"));
        $attahements = $this->MsgAttachment->query("EXEC spMsgAttachmentSelect
                                                        @rfx_auction_id = '".$this->spParams($rfx_id)."',
                                                        @is_sent='0',
                                                        @uploaded_by='" . $this->spParams($this->Auth->user("user_id")) . "',
                                                        @is_auction='".$this->spParams($is_auction)."'");
        $attahements = $this->getDataAll('MsgAttachment', $attahements);
        if ($attahements) {
            foreach ($attahements as $attachment) {
                $attach_files["name"][$attachment["MsgAttachment"]["attachment_id"]] = $attachment["MsgAttachment"]["document_file_name"];
                if ($attachment["MsgAttachment"]["destination_source"] == 0) {
                    $fileprefix = Configure::read('Document_Path') . "attachements/" . $this->Auth->user("company_id") . "_" . time() . "_" . rand(1, 10000) . "_" . $attachment["MsgAttachment"]["document_file_name"];
                    // $file_data = $this->Attachment->find('first', array('conditions' => array('reference_id' => $attachment["MsgAttachment"]["attachment_id"], 'attachment_type' => '8')));
                    $data_attch = $this->Attachment->query("EXEC spAttachmentReferenceIdSelect @reference_id='" . $this->spParams($attachment["MsgAttachment"]["attachment_id"]) . "',@attachment_type='8'");
                    $file_data = $this->GetData('Attachment', $data_attch);
                    $fp = fopen($fileprefix, 'w+');
                    fwrite($fp, $file_data["Attachment"]["attachement_file_content"]);
                    fclose($fp);
                    $attach_files["link"][] = $fileprefix;
                } else if ($attachment["MsgAttachment"]["destination_source"] == 2) {
                    $filenamearray[] = $attachment["MsgAttachment"]["document_file_name"];
                    $serverFile = "ftp://" . Configure::read('FTP_USER') . ":" . Configure::read('FTP_PASS') . "@" . Configure::read('FTP_HOST') . Configure::read('FTP_PATH') . $attachment["MsgAttachment"]["document_system_file_name"];
                    $content = file_get_contents($serverFile);
                    $fileprefix = Configure::read('Document_Path') . "attachements/" . $this->Auth->user("company_id") . "_" . time() . "_" . rand(1, 10000) . "_" . $attachment["MsgAttachment"]["document_file_name"];
                    $fp = fopen($fileprefix, 'w+');
                    fwrite($fp, $content);
                    fclose($fp);
                    $attach_files["link"][] = $fileprefix;
                } else {
                    $filenamearray[] = $attachment["MsgAttachment"]["document_file_name"];
                    $serverFile = Configure::read('Document_Path') . "attachements/" . $attachment["MsgAttachment"]["document_system_file_name"];
                    $attach_files["link"][] = $serverFile;
                }
                //$this->MsgAttachment->updateAll(array("is_sent" => 1), array('attachment_id' => $attachment["MsgAttachment"]["attachment_id"]));
                $update = $this->MsgAttachment->query("EXEC spMsgAttachmentUpdateIsSent @attachment_id='" . $this->spParams($attachment["MsgAttachment"]["attachment_id"]) . "'");
            }
        }
        if (count($attach_files)) {
            return $attach_files;
        } else {
            return false;
        }
    }

    function getCurrencyList() {
        App::import("model", "Currency");
        $this->Currency = new Currency();
        //$currencies = $this->Currency->find("all");
        $currency_data = $this->Currency->query("EXEC spCurrencySelectAll");
        $currencies = $this->getDataAll('Currency', $currency_data);
        foreach ($currencies as $currency) {
            $currencyList[$currency["Currency"]["currency_id"]] = $currency["Currency"]["code"];
        }
        return $currencyList;
    }

    //Add 
    function getSupplierContacts($company_id) {
        $emails = array();
        App::import("model", "Company");
        $this->Company = new Company();
        // $UserCompany = $this->Company->find("first", array("conditions" => array("company_id" => $company_id)));
        $company_data = $this->Company->Query("EXEC spCompanySecEmailSelect @company_id='".$this->spParams($company_id)."'");
        $fields_array = array(
            'sec_contact_email_short' => 'secondary_contact_person_email'
        );
        $UserCompany = $this->getData('Company', $company_data, $fields_array);
        if ($UserCompany) {
            if (trim($UserCompany["Company"]["contact_person_email"]) != "") {
                $emails[] = $UserCompany["Company"]["contact_person_email"];
            }
            if (trim($UserCompany["Company"]["secondary_contact_person_email"]) != "") {
                $emails[] = $UserCompany["Company"]["secondary_contact_person_email"];
            }
        }
        return $emails;
    }

    function sendSupplierMail($user_id, $subject, $emaildata, $template, $type = "html", $attachments = array()) {
        App::import("model", "User");
        $this->User = new User();
        // $user_data = $this->User->find("first", array("conditions" => array("user_id" => $user_id)));
        $user = $this->User->query("EXEC spUserEditSelect @user_id='".$this->spParams($user_id)."'");
        $user_data = $this->getData('User', $user);
        if ($user_data) {
            App::import("model", "Company");
            $this->Company = new Company();
            //$UserCompany = $this->Company->find("first", array("conditions" => array("company_id" => $user_data["User"]["company_id"])));
            $company_id = $user_data["User"]["company_id"];
            $company_data = $this->Company->Query("EXEC spCompanySecEmailSelect @company_id='".$this->spParams($company_id)."'");
            $fields_array = array(
                'sec_contact_email_short' => 'secondary_contact_person_email'
            );
            $UserCompany = $this->getData('Company', $company_data, $fields_array);
            if ($UserCompany) {

                //$emaildata["supplier_name"] = $UserCompany["Company"]["company_name"]; 
                //$emaildata["name"] = $UserCompany["Company"]["company_name"]; 
                $emaildata["supplier_company_name"] = $UserCompany["Company"]["company_name"];

                $primary_email = $user_data["User"]["email"];
                $emaildata["supplier_contact"] = "";
                $cc = array();

/**
 * BOC CC mail removed by S Anand on 22 July for Multi user for Supplier changes
 */
                /*if (trim($UserCompany["Company"]["contact_person_email"]) != "" && trim($UserCompany["Company"]["contact_person_email"]) != $primary_email) {
                    $cc[] = $UserCompany["Company"]["contact_person_email"];
                    //$contact1 = $UserCompany["Company"]["contact_person_email"];
                    //$emaildata["supplier_contact"] = "This is information Mail. There is no need perform action";
                    //$this->sendMail($contact1,$subject,$emaildata,$template,$type,$attachments);
                }
                if (trim($UserCompany["Company"]["secondary_contact_person_email"]) != "" && trim($UserCompany["Company"]["secondary_contact_person_email"]) != $primary_email && trim($UserCompany["Company"]["secondary_contact_person_email"]) != trim($UserCompany["Company"]["contact_person_email"])) {
                    $cc[] = $UserCompany["Company"]["secondary_contact_person_email"];
                    //$emaildata["supplier_contact"] = "This is information Mail. There is no need perform action";
                    //$contact2 = $UserCompany["Company"]["secondary_contact_person_email"];
                    //$this->sendMail($contact2,$subject,$emaildata,$template,$type,$attachments);
                }*/
                /*
                 * EOC by S Anand
                 */
                $this->sendMail($primary_email, $subject, $emaildata, $template, $type, $attachments, $cc);
            }
        }
    }

    function sendTeamMail($rfx_auction_id, $subject, $emaildata, $template, $type = "html", $attachments = array(), $is_auction) {
        if ($is_auction == 0) {
            App::import("model", "RfxProjectTeam");
            // $rfxdetails = $this->Rfx->find("first", array("conditions" => array("rfx_id" => $rfx_auction_id)));
            $rfx_details = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='".$this->spParams($rfx_auction_id)."'");
            $rfxdetails = $this->getData('Rfx', $rfx_details);
            //$buyerDetails = $this->User->read(null, $rfxdetails["Rfx"]["created_by"]);
            $user_id = $rfxdetails["Rfx"]["created_by"];
            $user = $this->User->query("EXEC spUserEditSelect @user_id='".$this->spParams($user_id)."'");
            $buyerDetails = $this->getData('User', $user);
            $primary_email = @$buyerDetails["User"]["email"];
            $emaildata['buyer_name'] = @$buyerDetails["User"]["name"];
            $emaildata["receiver_name"] = @$buyerDetails["User"]["name"];
            $emaildata["receiver"] = @$buyerDetails["User"]["name"];
            $emaildata['name'] = @$buyerDetails["User"]["name"];
            $emaildata["buyer_user_name"] = @$buyerDetails["User"]["name"];
            $emaildata['buyer_contact_name'] = @$buyerDetails["User"]["name"];
            $cc = array();
            $this->RfxProjectTeam = new RfxProjectTeam();

            //$teammembers = $this->RfxProjectTeam->find("all", array("conditions" => array("rfx_id" => $rfx_auction_id, "status !=" => "Deleted")));
            $team_members = $this->RfxProjectTeam->query("EXEC spRfxProjectTeamNotDeletedSelect @rfx_id='".$this->spParams($rfx_auction_id)."'");
            $teammembers = $this->getDataAll('RfxProjectTeam', $team_members);
            if (count($teammembers) > 0) {
                foreach ($teammembers as $teammember) {
                    $cc[] = $teammember["RfxProjectTeam"]["email"];
                    /* $primary_email = $teammember["RfxProjectTeam"]["email"];
                      $emaildata['buyer_name'] = $teammember["RfxProjectTeam"]["name"];
                      $emaildata["receiver_name"] = $teammember["RfxProjectTeam"]["name"];
                      $emaildata["receiver"] = $teammember["RfxProjectTeam"]["name"];
                      $emaildata['name'] = $teammember["RfxProjectTeam"]["name"];
                      $emaildata["buyer_user_name"] = $teammember["RfxProjectTeam"]["name"];
                      $emaildata['buyer_contact_name'] = $teammember["RfxProjectTeam"]["name"]; */
                }
            }
            $this->sendMail($primary_email, $subject, $emaildata, $template, $type, $attachments, $cc);
        } else {
            App::import("model", "AuctionProjectTeam");
            //$auctiondetails = $this->Auction->find("first", array("conditions" => array("auction_id" => $rfx_auction_id)));
            $auc_details = $this->Auction->query("EXEC spAuctionSelectByAuctionId @auction_id='".$this->spParams($rfx_auction_id)."'");
            $auctiondetails = $this->getData('Auction', $auc_details);
// $buyerDetails = $this->User->read(null, $auctiondetails["Auction"]["created_by"]);
            $user_id = $auctiondetails["Auction"]["created_by"];
            $user = $this->User->query("EXEC spUserEditSelect @user_id='".$this->spParams($user_id)."'");
            $buyerDetails = $this->getData('User', $user);
            $primary_email = $buyerDetails["User"]["email"];
            $emaildata['buyer_name'] = $buyerDetails["User"]["name"];
            $emaildata["receiver_name"] = $buyerDetails["User"]["name"];
            $emaildata["receiver"] = $buyerDetails["User"]["name"];
            $emaildata['name'] = $buyerDetails["User"]["name"];
            $emaildata["buyer_user_name"] = $buyerDetails["User"]["name"];
            $emaildata['buyer_contact_name'] = $buyerDetails["User"]["name"];
            $cc = array();
            $this->AuctionProjectTeam = new AuctionProjectTeam();
            // $teammembers = $this->AuctionProjectTeam->find("all", array("conditions" => array("auction_id" => $rfx_auction_id, "status !=" => "Deleted")));
            $team_mem = $this->AuctionProjectTeam->query("EXEC spAuctionProjectTeamSelectByAuctionIdAndStatus @auction_id='".$this->spParams($rfx_auction_id)."', @status='Deleted'");
            $teammembers = $this->getDataAll('AuctionProjectTeam', $team_mem);
            if (count($teammembers) > 0) {
                foreach ($teammembers as $teammember) {
                    $cc[] = $teammember["AuctionProjectTeam"]["email"];
                    /* $primary_email = $teammember["AuctionProjectTeam"]["email"];
                      $emaildata['buyer_name'] = $teammember["AuctionProjectTeam"]["name"];
                      $emaildata["receiver_name"] = $teammember["AuctionProjectTeam"]["name"];
                      $emaildata["receiver"] = $teammember["AuctionProjectTeam"]["name"];
                      $emaildata['name'] = $teammember["AuctionProjectTeam"]["name"];
                      $emaildata["buyer_user_name"] = $teammember["AuctionProjectTeam"]["name"];
                      $emaildata['buyer_contact_name'] = $teammember["AuctionProjectTeam"]["name"]; */
                }
            }
            $this->sendMail($primary_email, $subject, $emaildata, $template, $type, $attachments, $cc);
        }
    }

    function getDataAll($model, $datadetails, $fields_array = array()) {

        $dataDetailsnew = array();
        $dataDetailsArray = array();
        if ($datadetails === true) {
            return $dataDetailsArray;
        }


        for ($i = 0; $i < count($datadetails); $i++) {
            foreach ($datadetails[$i] as $data) {
                $dataDetailsnew[$model] = $data;
                $dataDetailsArray[] = $dataDetailsnew;
            }
        }

        if (!empty($fields_array)) {
            $dataArray = Array();
            $dataArrayNew = Array();
            if (!empty($dataDetailsArray)) {

                foreach ($dataDetailsArray as $data) {
                    foreach ($data[$model] as $key => $value) {

                        if (array_key_exists($key, $fields_array)) {
                            $dataArray[$model][$fields_array[$key]] = $value;
                        } else {
                            $dataArray[$model][$key] = $value;
                        }
                    }
                    $dataArrayNew[] = $dataArray;
                }
            }
            return $dataArrayNew;
        } else {
            return $dataDetailsArray;
        }
    }
    function checkTeamlead() {
        if ($this->Permission->isOrxCheilTeamLead()) {
            return true;
        } else {
            $this->_flash($this->Error->getError("3030"), "error");
            $this->redirect(array("controller" => "dashboard", 'action' => "Index"));
        }
    }

    function getData($model, $datadetails, $fields_array = array()) {
        $dataDetailsnew = array();
        $dataDetailsArray[] = array();
        $dataDetailsArray1[$model] = array();
        $datanew = array();
//        if($datadetails == 1){
//            return $dataDetailsnew;
//        }
        if($datadetails === true) {
         //return $dataDetailsnew;
           
        } else{
        for ($i = 0; $i < count($datadetails); $i++) {
            foreach ($datadetails[$i] as $data) {
                $dataDetailsnew[$model] = $data;
                $dataDetailsArray[] = $dataDetailsnew;
            }
        }
        for ($i = 0; $i < count($dataDetailsArray); $i++) {
            foreach ($dataDetailsArray[$i] as $timezone) {
                $datanew[$model] = $timezone;
            }
        }
        if (!empty($fields_array)) {
            $dataArray = Array();
            if (!empty($datanew)) {
                foreach ($datanew[$model] as $key => $value) {
                    if (array_key_exists($key, $fields_array)) {
                        $dataArray[$model][$fields_array[$key]] = $value;
                    } else {
                        $dataArray[$model][$key] = $value;
                    }
                }
                return $dataArray;
            }
        } else {
            if (!empty($datanew)) {
                return $datanew;
            }
        }
        }
    }

//    function getCompleteFieldNames($model,$datadetails,$fields_array){
//             $dataArray=Array();
//             foreach($datadetails[$model] as $key=>$value){
//               if(array_key_exists($key,$fields_array)){
//                  $dataArray[$model][$fields_array[$key]]=$value;
//               }else{
//                  $dataArray[$model][$key]=$value;
//               }
//           }
//           return $dataArray;
//    }
    function getSaveData($model, $datadetails) {
        $dataDetailsArray = array();
        foreach ($datadetails[$model] as $key => $data) {            
            $dataDetailsArray[$model][$key] = $data;            
        }
        return $dataDetailsArray;
//         $dataDetailsArray = array();
//        foreach ($datadetails[$model] as $key => $data) {
//            if (is_string($data)) {
//                $newdata = preg_replace("/'/", "''", $data);
//                $dataDetailsArray[$model][$key] = $newdata;
//            } else {
//                $dataDetailsArray[$model][$key] = $data;
//            }
//        }
//        return $dataDetailsArray;
    }

    function getOriginalSaveData($model, $datadetails) {
        $dataDetailsArray = array();
        foreach ($datadetails[$model] as $key => $data) {
            if (is_string($data)) {
                $newdata = preg_replace("/''/", "'", $data);
                $dataDetailsArray[$model][$key] = $newdata;
            } else {
                $dataDetailsArray[$model][$key] = $data;
            }
        }
        return $dataDetailsArray;
    }

//    function getError($code){
//        App::import("model", "Error");
//        $this->Error = new Error();
//        $error=$this->Error->query("Exec spGetError '$code'");
//        $error_des=$this->getData("Error",$error);
//        return $error_des;
//    }

    function getPagingData($count_data, $sort, $order) { 
        $count = $count_data[0][0]['count'];
        $page_limit = Configure::read('PageLimit');
        $no_of_pages = ceil($count / $page_limit);
        if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] != 1) {
            $page_num = $this->params["named"]["page"];

            $start = ($page_num - 1) * $page_limit;
        } else {
            $page_num = 0;
            $start = $page_num * $page_limit;
        }
        $total = $count;
        if (isset($this->params["named"]["sort_by"])) {
            $sortby = $this->params["named"]["sort_by"];
        } else {
            $sortby = $sort;
        }
        if (isset($this->params["named"]["sort_order"])) {
            $sortorder = $this->params["named"]["sort_order"];
        } else {
            $sortorder = $order;
        }
        $sort = $sortby . ' ' . $sortorder;
        $this->set('no_of_pages', $no_of_pages);
        if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] > 1) {
            $this->set('start', ($page_num - 1) * $page_limit + 1);
        } else {
            $this->set('start', 1);
        }
        if ($total < $page_limit) {
            $this->set('end', $total);
        } else if ($page_num == $no_of_pages) {
            $this->set('end', $total);
        } else if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] > 1) {
            $this->set('end', ($page_num - 1) * $page_limit + Configure::read('PageLimit'));
        } else {
            $this->set('end', $page_limit);
        }
        $this->set('total', $total);

        $info = array($start, $page_limit, $sort, $total);
        return $info;
    }

    function getPagingDataNew($count_data, $page_limit) {
        $count = $count_data;
        $no_of_pages = ceil($count / $page_limit);
        if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] != 1) {
            $page_num = $this->params["named"]["page"];

            $start = ($page_num - 1) * $page_limit;
        } else {
            $page_num = 0;
            $start = $page_num * $page_limit;
        }
        $total = $count;
        $this->set('no_of_pages', $no_of_pages);
        if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] > 1) {
            $this->set('start', ($page_num - 1) * $page_limit + 1);
        } else {
            $this->set('start', 1);
        }
        if ($total < $page_limit) {
            $this->set('end', $total);
        } else if ($page_num == $no_of_pages) {
            $this->set('end', $total);
        } else if (isset($this->params["named"]["page"]) && $this->params["named"]["page"] > 1) {
            $this->set('end', ($page_num - 1) * $page_limit + $page_limit);
        } else {
            $this->set('end', $page_limit);
        }
        $this->set('total', $total);
        $info = array($start, $page_limit, $total);
        return $info;
    }
    
    function getJoinData($details, $data, $model) {
        $dataDetailsnew = array();
        $dataDetailsArray = array();
        if ($details === true) {
            return $dataDetailsArray;
        }
        for ($i = 0; $i < count($details); $i++) {
            foreach ($details[$i][0] as $key => $value) {
                for ($j = 0; $j < count($data); $j++) {
                    if (in_array($key, $data[$j])) {

                        $dataDetailsnew[$model[$j]][$key] = $value;
                    }
                }
            }
            $dataDetailsArray[] = $dataDetailsnew;
        }
        return $dataDetailsArray;
    }

    function getJoinDataOne($details, $data, $model) {
        $dataDetailsnew = array();
        $dataDetailsArray = array();
        if ($details === true) {
            return $dataDetailsArray;
        }
        for ($i = 0; $i < count($details); $i++) {
            foreach ($details[$i][0] as $key => $value) {
                for ($j = 0; $j < count($data); $j++) {
                    if (in_array($key, $data[$j])) {

                        $dataDetailsnew[$model[$j]][$key] = $value;
                    }
                }
            }
        }
        return $dataDetailsnew;
    }

    function getListDataAll($datadetails, $index, $value) {
        $dataDetailsnew = array();
        foreach ($datadetails as $datadetail) {
            $dataDetailsnew[$datadetail[0][$index]] = $datadetail[0][$value];
        }
        return $dataDetailsnew;
    }
	
	function noCsrf() {
           App::import("Vendor", "nocsrf");
       // include('nocsrf.php');
       // if(isset($_POST) && sizeof($_POST) > 0){
        if (isset($_POST['csrf_token'])) {
            try {
                NoCSRF::check('csrf_token', $_POST, true, null, true);
                // form parsing, DB inserts, etc.
                // ...
                $result = 'CSRF check passed. Form parsed.';
            } catch (Exception $e) {
                // CSRF attack detected
                $result = $e->getMessage() . ' Form ignored.';
                $messageArray = array("type" => "csrf", "Message" => "Sorry! CSRF attack detected.");
                echo json_encode($messageArray);
                if (!isset($_POST['csrf_error'])) {
                    $this->redirect(array("controller" => "pages", "action" => "error"));
                } else {
					//echo json_encode($messageArray);
				}
                die;
            }
        } else if (isset($_GET['csrf_token'])) {
            try {
                NoCSRF::check('csrf_token', $_GET, true, null, true);

                $result = 'CSRF check passed. Form parsed.';
            } catch (Exception $e) {
                // CSRF attack detected
                $result = $e->getMessage() . ' Form ignored.';
                echo 'csrf_error';
                $this->redirect(array("controller" => "pages", "action" => "error"));
                die();
            }
        } else {
             $result = 'No post data yet.';
//            $result = 'CSRF attack detected. Form ignored.';
//                
//                if (!isset($_POST['csrf_error'])) {
//                    $this->redirect(array("controller" => "pages", "action" => "error"));
//                } else {
//                    $messageArray = array("type" => "csrf", "Message" => "Sorry! CSRF attack detected.");
//                    echo json_encode($messageArray);
//                }
//                die; 
        }
//        }else{
//            $result = 'No post data yet.';
//            //die;
//        }
    }
       
    
    
    function noCsrfOutside() {
		App::import("Vendor", "nocsrf1");
		if (isset($_POST['csrf_token1'])) {
			try {
				NoCSRF1::check1('csrf_token1', $_POST, true, null, true);
				$result = 'CSRF check passed. Form parsed.';
			} catch (Exception $e) {
				// CSRF attack detected
				$result = $e->getMessage() . ' Form ignored.';
				$messageArray = array("type" => "csrf", "Message" => "csrf");
				//echo json_encode($messageArray);
				//$this->redirect(array("controller" => "pages", "action" => "error"));
 				$this->Session->setFlash('Access denied.');
				$this->redirect($this->Auth->logout());
				die;
			}
		} else if (isset($_GET['csrf_token1'])) {
			try {
				NoCSRF1::check1('csrf_token1', $_GET, true, null, true);
				$result = 'CSRF check passed. Form parsed.';
			} catch (Exception $e) {
				// CSRF attack detected
				$result = $e->getMessage() . ' Form ignored.';
				//echo 'csrf_error';
				//$this->redirect(array("controller" => "pages", "action" => "error"));
				 $this->Session->setFlash('Access denied.');
				$this->redirect($this->Auth->logout());
				die();
			}
		} else {
			$result = 'No post data yet.';
		}
		$token1 = NoCSRF1::generate( 'csrf_token1' );
		$this->set('token1',$token1);
	}
	
	function spParams($value){
		$value=preg_replace("/'/", "''", $value);
        return $value;
	}
        
        
//        function getSerializeSaveData($data){
//            $datanew = array();
//            foreach($data as $key=>$value){
//                $datanew[$key]=preg_replace("/'/", "''", $value);
//            }
//            return $datanew;
//        }
       
    function uploadCheck() {
        if(isset($_FILES['uploadfile']["tmp_name"])){
           
            $result= new finfo();
            if(is_object($result)=== true){
                $res=$result->file($_FILES['uploadfile']["tmp_name"],FILEINFO_MIME_TYPE);
            }else{
                $res = '';
            }
            if($res != ''){
            if(in_array($res,configure::read('AllowedMIMEType'))){
                //allowed
            }else{
                return false;
            }
            }
        }
        $current_session_id = session_id();
        if (isset($_POST['session_id'])) {
            $this->Session->id($_POST['session_id']);
            $this->Session->start();
            if (isset($_SESSION['Auth'])) {
                if ($_POST['user_id'] == $_SESSION['Auth']['User']['user_id']) {
                    $this->Session->id($current_session_id);
                    $this->Session->start();
                    return true;
                } else {
                    $this->Session->id($current_session_id);
                    $this->Session->start();
                    return false;
                    //  echo "Sorry, You are not authorized to upload the attachment.";
                }
            } else {
                App::import("model", "Session");
                $session = new Session;
                $session_data = $session->query("EXEC spSessionSelectByid @id = '" . $this->spParams($_POST['session_id']) . "'");
                $session_data = $this->getData("Session", $session_data);
                if (!empty($session_data)) {
                    $user_data = $session_data['Session']['data'];
                    session_decode($user_data);
                    if ($_POST['user_id'] == $_SESSION['Auth']['User']['user_id']) {
                        $this->Session->id($current_session_id);
                        $this->Session->start();
                        return true;
                    } else {
                        $this->Session->id($current_session_id);
                        $this->Session->start();
                        return false;
                    }
                } else {
                    $this->Session->id($current_session_id);
                    $this->Session->start();
                    return false;
                }
            }
        } else {
            return false;
        }
    }
    
    function noCsrfNew() {
		
        if(isset($_POST) && sizeof($_POST) > 0){
            if (isset($_POST['csrf_token1']) && isset($_POST['key'])) { 
                if(isset($_SESSION[$_POST['key']]) && $_SESSION[$_POST['key']] == $_POST['csrf_token1']){ 
                    $result = 'CSRF check passed. Form parsed.';
                    $this->Session->delete($_POST['key']);
                }

                else{
                   
                    // CSRF attack detected
                    $this->Session->delete($_POST['key']);
                    $result = 'CSRF attack detected. Form ignored.';
                    if (!isset($_POST['csrf_error'])) {
                        $this->redirect(array("controller" => "pages", "action" => "error"));
                    } else {
                        $messageArray = array("type" => "csrf", "Message" => "Sorry! CSRF attack detected.");
                        echo json_encode($messageArray);
                    }                    
                    die;
                }            
            } else if (isset($_GET['csrf_token1']) && isset($_GET['key'])) {
                if(isset($_SESSION[$_GET['key']]) && $_SESSION[$_GET['key']] == $_GET['csrf_token1']){
                    $result = 'CSRF check passed. Form parsed.';
                    $this->Session->delete($_GET['key']);
                }

                else{
                    // CSRF attack detected
                    $this->Session->delete($_GET['key']);
                    $result = 'CSRF attack detected. Form ignored.';
                    
                    if (!isset($_POST['csrf_error'])) {
                        $this->redirect(array("controller" => "pages", "action" => "error"));
                    } else {
                        $messageArray = array("type" => "csrf", "Message" => "Sorry! CSRF attack detected.");
                        echo json_encode($messageArray);
                    }
                    die;
                }
            } else {
                $result = 'CSRF attack detected. Form ignored.';
                
                if (!isset($_POST['csrf_error'])) {
//                    debug('1');die;
                    $this->redirect(array("controller" => "pages", "action" => "error"));
                } else {
                    $messageArray = array("type" => "csrf", "Message" => "Sorry! CSRF attack detected.");
                    echo json_encode($messageArray);
                }
                die;          
            }
        }
        else{
            $result = 'No post data yet.';     
        }
    }
    
    function getRequestData($data_array) {
        $dataDetailsArray = array();
        foreach ($data_array as $key => $data) {
            if(is_array($data)){
                $dataDetailsArray[$key] = $this->getRequestData($data);
            }
            else{
                if (is_string($data)) {
                    $newdata = preg_replace("/'/", "''", $data);
                    $dataDetailsArray[$key] = $newdata;
                } else {
                    $dataDetailsArray[$key] = $data;
                }
            }
        }
        return $dataDetailsArray;
    }
    /*
    * To Sanitize Sp parameters to prevent it from for sql injecttion
    */

    public function spParamsSanitize($value){
        $value=preg_replace("/'/", "''", $value);
        return $value;
   }  
   public function checkSubmitQuotation() {
        $cheil_orx_company_id = Configure::read('ORX_CHEIL_SUP_ID');
        $cheil_orx_com_id = explode(',', $cheil_orx_company_id);
        $rfx_we_id = $this->params["named"]["rfxid"];
        App::import("model", "Rfx");
        $this->Rfx = new Rfx();
        $rfx_detail = $this->Rfx->query("EXEC spRfxSelectByWebId @rfx_web_id='" . $this->spParams($rfx_we_id) . "'");
        $rfx_detail = $this->getData('Rfx', $rfx_detail);
        if (in_array($this->Auth->user("company_id"), $cheil_orx_com_id)) {
            if (!empty($rfx_detail)) {
                $quote_check = $this->RfxAttachement->query("EXEC spSuppDelegationSelectQuoteFlag @siel_rfx_id='" . $this->spParams($rfx_detail["Rfx"]["rfx_id"]) . "',@quote_flag='1',@company_id='" . $this->Auth->user("company_id") . "'");
               if(empty($quote_check))
                   $quote_check = array();
                $quote_check = $this->getData('SupplierDelegationMapping', $quote_check);
                if (!empty($quote_check)) {
                    if (isset($quote_check['SupplierDelegationMapping']['team_member_id'])) {
                        $supplier_delegated_user_id = $quote_check['SupplierDelegationMapping']['team_member_id'];
                        if ($supplier_delegated_user_id != $this->Auth->user("user_id")) {
                            //$this->_flash("You can not submit quote on Rfx", "error");
                            $this->_flash($this->Error->getError("5009"), "error");
                            $this->redirect(array("controller" => "rfx_responses", "action" => "index/rfx_id:" . $rfx_detail["Rfx"]["rfx_web_id"]));
                        }
                    }
                }
            }
            //Approver Check
            $appover_details = $this->Rfx->query("EXEC spOrxCheilApprovalSelectByRfxId @siel_rfx_id='" . $this->spParams($rfx_detail["Rfx"]["rfx_id"]) . "',@company_id='" . $this->spParams($this->Auth->user("company_id")) . "'");
            $appover_details = $this->getData('Rfx', $appover_details);
            if(!empty($appover_details) && isset($appover_details['Rfx']['status']) && $appover_details['Rfx']['status'] == "In Process"){
                $this->_flash($this->Error->getError("5009"), "error");
                $this->redirect(array("controller" => "rfx_responses", "action" => "index/rfx_id:" . $rfx_detail["Rfx"]["rfx_web_id"]));
            }
            
        }
    }
    //function added by lgarg to update mpr status of mpids on 22-aug-2016
    public function updateMPRStatus() {

       ini_set("soap.wsdl_cache_enabled", 0);
        $client = new SoapClient(Configure::read('SoapMPRStatus'), array('trace' => TRUE, "exceptions" => 0));
        try {
            $output = $client->__soapCall("GetRequestData", array());
//            debug($output);
        } catch (Exception $e) {
//            var_dump($e);
        }
        //debug(is_soap_fault($output));die;
        if (is_soap_fault($output) != '') {
            
//            echo "------------Fault---------------<br />";
//            echo "SOAP Fault: (faultcode: {$output->faultcode}, faultstring: {$output->faultstring})";
//            echo "<br />------------End Fault Message---------------<br />";
//            echo "hi";
//            die;
            return true;
        } else {
            //debug($output);
            //$output = '[{"RequestCode":"SENDTOPMG0001","RequestStatusName":"EO Pending"},{"RequestCode":"SENDTOPMG0002","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0003","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0004","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0005","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0006","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0007","RequestStatusName":"EO Pending"},{"RequestCode":"SENDTOPMG0008","RequestStatusName":"EO Pending Reopen"},{"RequestCode":"SENDTOPMG0009","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0010","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0011","RequestStatusName":"PP Approval Pending"},{"RequestCode":"SENDTOPMG0012","RequestStatusName":"Pending"},{"RequestCode":"SENDTOPMG0013","RequestStatusName":"EO Pending Reopen"},{"RequestCode":"SENDTOPMG0014","RequestStatusName":"PP Approval Pending"},{"RequestCode":"SENDTOPMG0015","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0016","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0017","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0018","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0019","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0020","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0021","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0022","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0023","RequestStatusName":"PP Approval Pending"},{"RequestCode":"SENDTOPMG0024","RequestStatusName":"PP Approval Pending"},{"RequestCode":"SENDTOPMG0025","RequestStatusName":"PP Pending"},{"RequestCode":"SENDTOPMG0026","RequestStatusName":"PP Approval Pending"}]';
            if(isset($output->GetRequestDataResult)){
                $response = json_decode($output->GetRequestDataResult, true);
                if (!empty($response)) {
                    foreach ($response as $responses) {
                        if (isset($responses['RequestCode'])) {
                            $update = $this->User->query("EXEC spMpidEventDetailsUpdateMprStatus @mpid='" . $this->spParams($responses['RequestCode']) . "',@mpr_status='" . $this->spParams($responses['RequestStatusName']) . "'");
                        }
                    }

                }
            }
            return true;
        }
        die;
    }
    function checkSubPoCreator() {
        if ($this->Permission->isSubPoCreator()) {
            //$this->redirect(array("controller" => "dashboard", 'action' => "sub_po_creator"));
            return true;
        } else {
            $this->_flash($this->Error->getError("1002"), "error");
            $this->redirect(array("controller" => "dashboard", "action" => "index"));
        }
        /*         * * EOF Check if user is activity owner or only approver. By lokesh garg on 07-Aug-2016 */
    }
    
    
    function submitApproval($final_array,$from_step7=NULL) {
        $this->layout = false;
        $client = new SoapClient(Configure::read('SubmitApprovalSoap'), array('trace' => TRUE, "exceptions" => 0));
        $ESBAuthVO = Configure::read('EmpSubmitAuth');
        $cid = $ESBAuthVO['cID'];
        $pwd = $ESBAuthVO['cPW'];
        $error_ep_id = "";
        $ESBAuthVO = new AppController();
        $startProcessWSVO = new AppController();
        $object = new AppController();

        $ESBAuthVO->cID = $cid;
        $ESBAuthVO->cPW = $pwd;

        if(isset($this->params["named"]["rfx_id"])){
            $rfx_id = $this->params["named"]["rfx_id"];
        } else {
            $rfx_id = $final_array['siel_rfx_id'];
        }
        $current_rfx_id = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='" . $this->spParamsSanitize($rfx_id) . "'");
        $current_rfx_id = $this->getData('Rfx', $current_rfx_id);
        $current_rfx_web_id = $current_rfx_id['Rfx']['rfx_web_id'];
        
        $ref_rfx_id = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='" . $this->spParamsSanitize($final_array['siel_rfx_id']) . "'");
        $ref_rfx_id = $this->getData('Rfx', $ref_rfx_id);
        $siel_rfx_web_id = $ref_rfx_id['Rfx']['rfx_web_id'];
        $pmg_id = $ref_rfx_id['Rfx']['rfx_reference_no'];
        
        $body = $final_array['Body'];
        
        $p =0;
        $error = array();
        $draft_user_array = array();
        if($error_ep_id == ""){
            $epid = $this->getEPID($final_array['Username']);
            if(empty($epid) && isset($error_ep_id)){
                $error_ep_id = "error";
                $error['status'] = "error";
                $error['message'] = 'Data not found for user:'.$final_array['Username'];
                return $error;
                die;
            }
            if($error_ep_id == ""){
                $draft_user_array[] = array(
                    "UserID" => $epid['epid'],
                    "Arbitrary" => -1,
                    "ActionType" => 0,
                    "Activity" => 0,
                    "RouteModify" => -1,
                    "Sequence" => $p,
                    "BodyModify" => -1,
                    "MailAddress" => $epid['email'],
                );
                $p++;
            }
        }
        $stroutevo_approver_array = array();
        if($error_ep_id == ""){
            if(!empty($final_array['Approver'])){
                foreach($final_array['Approver'] as $approvers){
                    $epid = $this->getEPID($approvers);
                    if(empty($epid) && isset($error_ep_id)){
                        $error_ep_id = "error";
                        $error['status'] = "error";
                        $error['message'] = 'Data not found for user:'.$approvers;
                        return $error;
                        die;
                        break;
                    }
                    if($error_ep_id == ""){
                        $stroutevo_approver_array[] = array(
                        "UserID" => $epid['epid'],
                        "Arbitrary" => -1,
                        "ActionType" => 0,
                        "Activity" => 1,
                        "RouteModify" => -1,
                        "Sequence" => $p,
                        "BodyModify" => -1,
                        "MailAddress" => $epid['email'],
                        );
                        $p++;
                    }
                }
            }
        } 
        
        $stroutevo_noti_array = array();
        //debug($final_array['Notification']);
        if(!empty($final_array['Notification'])){
            foreach($final_array['Notification'] as $noti){
                $epid = $this->getEPID($noti);
                if(empty($epid) && isset($error_ep_id)){
                    $error_ep_id = "error";
                    $error['status'] = "error";
                    $error['message'] = 'Data not found for user:'.$noti;
                    return $error;
                    die;
                    break;
                }
//                $epid['epid'] = 'pmt.rfx';
//                $epid['email'] = 'pmt.rfx@stage.samsung.com';
                if($error_ep_id == ""){
                    $stroutevo_noti_array[] = array(
                        "UserID" => $epid['epid'],
                        "Arbitrary" => -1,
                        "ActionType" => 0,
                        "Activity" => 9,
                        "RouteModify" => -1,
                        "Sequence" => $p,
                        "BodyModify" => -1,
                        "MailAddress" => $epid['email'],
                    );
                    $p++;
                }
            }
        }
       
        $Body = $body;
        $Title = 'Estimate Request Approval'.' : '.$siel_rfx_web_id;
        $BodyType = "1";
        $NotiMail = "1";
        $SendDMS = false;
        $TimeZone = 'GMT+5:30';
        $drm = "pc_count=-1|valid_days=365|use_count=-1|can_view=1|can_print=0|can_save=0|confirm_mail_4in=0|confirm_mail=1";
        $DrmOptionInfo = $drm;
        $LocaleInfo = "en_IN.UTF-8";
        $CreateDate = '20070514094415';
        $SystemID = $cid;

        if(empty($stroutevo_approver_array)){
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'No approvers found for the Rfx Id:'.$siel_rfx_web_id;
            return $error;
            die;
        }
        
        $RouteWSVO = array_merge($draft_user_array, $stroutevo_approver_array, $stroutevo_noti_array);
        
        
        $AttachmentWSVO = array();

        $startProcessWSVO->Title = $Title;
        $startProcessWSVO->BodyType = $BodyType;
        $startProcessWSVO->NotiMail = $NotiMail;
        $startProcessWSVO->SendDMS = $SendDMS;
        $startProcessWSVO->TimeZone = $TimeZone;
        $startProcessWSVO->DrmOptionInfo = $DrmOptionInfo;
        $startProcessWSVO->LocaleInfo = $LocaleInfo;
        $startProcessWSVO->CreateDate = $CreateDate;
        $startProcessWSVO->SystemID = $SystemID;
        $startProcessWSVO->MisID = $this->genearteMisKey();
        $startProcessWSVO->RouteVOs = $RouteWSVO;
        $startProcessWSVO->AttachmentWSVO = $AttachmentWSVO;
        $startProcessWSVO->Body = $Body;
        
        $object->esbAuthVO = $ESBAuthVO;
        $object->startProcessWSVO = $startProcessWSVO;
        if($error_ep_id == ""){
        try {
            $output_submit_approval = $client->__soapCall("submitApproval", array($object));
        } catch (Exception $e) {
            var_dump($e);
        }
        if (is_soap_fault($output_submit_approval)) {
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'Can not call soap client:'.$output_submit_approval->faultstring;
            return $error;
            die;
        } else {
            
            if ($output_submit_approval->result == "success") {
                //Insert MIS ID, and update status in process
                $rfxdetails["Rfx"]["rfx_id"] = $final_array['siel_rfx_id'];
                $status_sub = 'In Process';
                $company_id = $final_array['supplier_company_id'];
                $mis_key = $startProcessWSVO->MisID;
                $update_approval_data_for_orx = $this->User->query("EXEC spOrxCheilApprovalStatusUpdateNew
                                                @siel_rfx_id='" . $this->spParamsSanitize($rfxdetails["Rfx"]["rfx_id"]) . "',
                                                @status='" . $this->spParamsSanitize($status_sub) . "',                        
                                                @company_id='" . $this->spParamsSanitize($company_id) . "',
                                                @approval_mis_key='" . $this->spParamsSanitize($mis_key) . "'
                                                ");
                $error_ep_id = "success";
                $error['status'] = "success";
                $error['message'] = 'Successfully sent for approval';
                return $error;
                die;
            } else {
                $error_ep_id = "error";
                $error['status'] = "error";
                $error['message'] = 'Sorry! can not send data for approval';
                return $error;
                die;
            }
        }
        } else {
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'Sorry! can not send data for approval';
            return $error;
            die;
        }
        //debug($error_ep_id);die;
        //echo "------------End Output---------------<br />";
        //echo "REQUEST:\n" . $client->__getLastRequest() . "\n";
        if($error_ep_id != "" && $error_ep_id == "success"){
            $error['status'] = "error";
            $error['message'] = 'Sorry!can not send data for approval';
            return $error;
            die;
        } elseif($error_ep_id != "" && $error_ep_id == "error") {
            $error['status'] = "error";
            $error['message'] = 'Sorry!can not send data for approval';
            return $error;
            die;
        }
        $error['status'] = "error";
        $error['message'] = 'Sorry!can not send data for approval';
        return $error;
        die;
    }
   
    function getEPID($uid) {
        configure::write('debug', 2);
        //$client = new SoapClient('http://wsstage.samsung.net/sibws/wsdl/WSGWBus/EmpService', array('trace' => TRUE, "exceptions" => 0));
        $client = new SoapClient(Configure::read('EmpSearchSoap'), array('trace' => TRUE, "exceptions" => 0));
        $ESBAuthVO = Configure::read('EmpSearchAuth');
        $cid = $ESBAuthVO['cID'];
        $pwd = $ESBAuthVO['cPW'];

        try {
            $object = new AppController();
            $object->cid = $cid;
            $object->cpw = $pwd;
            $object->uid = $uid;
            //$object->uid = 'pmt.rfx';
            $output_emp_search = $client->__soapCall("findByUid", array($object));
        } catch (Exception $e) {

        }
        if (is_soap_fault($output_emp_search)) {
//            echo "------------Fault---------------<br />";
//            echo "SOAP Fault: (faultcode: {$output_emp_search->faultcode}, faultstring: {$output_emp_search->faultstring})";
//            echo "<br />------------End Fault Message---------------<br />";
//            die;
            return "";
            $error_ep_id['id']= $uid;
        } else {
            $epid_arr = array();
            if(!empty($output_emp_search) && isset($output_emp_search) && isset($output_emp_search->return->Employee->Epid) && isset($output_emp_search->return->Employee->Mail)){
                $epid_arr['epid'] = $output_emp_search->return->Employee->Epid;
                $epid_arr['email'] = $output_emp_search->return->Employee->Mail;
                //debug($epid_arr);
                return $epid_arr;
            } else {
                return "";
                $error_ep_id['id']= $uid;
            }
        }
        die;
    }
    public function genearteMisKey() {
        $timestamp = time();
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        $Miskey = '';
        for ($i = 0; $i < 17; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $Miskey = $randomString . 'eProc' . $timestamp;
        $approval_details = $this->Rfx->query("EXEC spOrxCheilApprovalSelectByMisKey @approval_mis_key='" . $this->spParams($Miskey) . "'");
        if (!empty($approval_details)) {
            $approval_details = $this->getdata('OrxCheilApprovalMapping', $approval_details);
        } else {
            $approval_details = array();
        }
        if (empty($approval_details)) {
            return $Miskey;
        } else {
            $this->genearteMisKey();
        }
    }
    
    
    //After approval ref attachements added and notification generated
    public function updateRefRfxData($siel_rfx_id,$company_id) {
        //send to aproval status check and insert status = "approved" by lgarg on 25-Aug-2016
        $ref_rfx_id["Rfx"]["reference_rfx_id"] = $siel_rfx_id;
        $supp_company_id = $company_id;
        $orx_cheil_approval_data = $this->Rfx->query("EXEC spOrxCheilApprovalSelectByRfxId @siel_rfx_id='" . $this->spParamsSanitize($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "',@company_id='" . $this->spParams($supp_company_id) . "'");
        $orx_cheil_approval_data = $this->getData('RfxResponseInvite', $orx_cheil_approval_data);
        if (!empty($orx_cheil_approval_data) && count($orx_cheil_approval_data) >= 0) {
            //Generate notification for send to approval for all delegated team members.
            $team_lead_id = $this->Rfx->query("EXEC spSuppDelegationSelectTeamLead @siel_rfx_id = '" . $this->spParams($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "', @company_id = '" . $this->spParams($supp_company_id) . "'");
            $team_lead_id = $this->getData('User', $team_lead_id);
            if (!empty($team_lead_id) && isset($team_lead_id['User']['team_lead_id'])) {
                $teamleadid = $team_lead_id['User']['team_lead_id'];

                $team_member_all = $this->Rfx->query("EXEC spSupplierDelegationSelectMemberByTeamlead @siel_rfx_id = '" . $this->spParams($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "', @teamlead_id = '" . $this->spParams($teamleadid) . "'");
                $team_member_all = $this->getDataAll('User', $team_member_all);
                if (!empty($team_member_all)) {
                    foreach ($team_member_all as $team_member_alls) {
                        if (isset($team_member_alls['User']['team_member_id'])) {
                            $receiver_team_member_id = $team_member_alls['User']['team_member_id'];
                            $userCompany = $this->Session->read('UserCompany');
                            $rfx_details = $this->Rfx->query("EXEC spRfxSelectByRfxId @rfx_id='" . $this->spParams($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "'");
                            $rfxdetails = $this->getData('Rfx', $rfx_details);
                            $supplier_notification_id = $this->notification($supp_company_id, $rfxdetails["Rfx"]["rfx_id"], Configure::read('RfxQuotationApprovalNotification'), $supp_company_id, "", Configure::read('RfxQuotationApprovalNotification'), $rfxdetails['Rfx']['rfx_web_id'], $rfxdetails['Rfx']['company_name'], $userCompany["Company"]["company_name"], '', '', '', '', '', $receiver_team_member_id);
                        }
                    }
                }
            }
        }

                
        $ref_rfx_data_select = $this->Rfx->query("EXEC spSendToRefRfxDatamappingSelectAllByReferenceRfxId1 @siel_rfx_id='" . $this->spParams($siel_rfx_id) . "'");
        $ref_rfx_data_select = $this->getdataAll('RefRfxDataMapping', $ref_rfx_data_select);
        $attach_ids = array();
        if(!empty($ref_rfx_data_select)){
            foreach($ref_rfx_data_select as $ref_rfx_data_select1){
                $rfx_id = $ref_rfx_data_select1['RefRfxDataMapping']['rfx_id'];
                $response_id = $ref_rfx_data_select1['RefRfxDataMapping']['response_id'];
                
                $pi_attachmets = $this->Rfx->query("EXEC spRfxQuotationPiAttachementSelectAllByRfxIdRespnseId @rfx_id='" . $this->spParams($rfx_id) . "',@response_id='" . $this->spParams($response_id) . "'");
                $pi_attachmets = $this->getdataAll('RfxQuotationPiAttachments', $pi_attachmets);
                if(!empty($pi_attachmets)){
                    foreach($pi_attachmets as $pi_attachmets1){
                        $pi_attachment_id = $pi_attachmets1['RfxQuotationPiAttachments']['rfx_quotation_pi_attachment_id'];
                        $attach_ids[] = $pi_attachment_id;
                    }
                }

            }
        }
        if(!empty($attach_ids)){
            $att_ids = array_unique($attach_ids);
        } else {
            $att_ids = array();
        }
              
        $delegated_members = $this->Rfx->query("EXEC spRfxInvitedSelectDelegatedSupp @rfx_id='" . $this->spParams($ref_rfx_id['Rfx']['reference_rfx_id']) . "', @company_id = '" . $this->spParams($supp_company_id) . "'");
        if ($delegated_members == '') {
            $delegated_members = array();
        }
        $delegated_members = $this->getDataAll('User', $delegated_members);
        if (!empty($delegated_members)) {
            foreach ($delegated_members as $delegated_member) {

                $responseExistCheck = $this->Rfx->query("EXEC spRfxResponseSelectByCompanyUserId @rfx_id='" . $this->spParamsSanitize($ref_rfx_id['Rfx']['reference_rfx_id']) . "',@supplier_company_id='" . $this->spParams($delegated_member['User']['company_id']) . "',@supplier_user_id='" . $this->spParams($delegated_member['User']['supplier_user_id']) . "'");
                $responseExistCheck = $this->getData('RfxResponseInvite', $responseExistCheck);
                if(!empty($responseExistCheck)){
                    $delete = $this->Rfx->query("EXEC spRfxResponseAttachementDeleteForRefRfx @rfx_id='" . $this->spParams($ref_rfx_id['Rfx']['reference_rfx_id']) . "',@response_id='" . $this->spParams($responseExistCheck["RfxResponseInvite"]["response_id"]) . "',@is_ref='1'");
                    if ($delete) {
                        $rfx_reference_attachments = $this->Rfx->query("EXEC spRfxReferenceAttachmentSelectAll @rfx_id='" . $this->spParams($rfx_id) . "',@reference_rfx_id='" . $this->spParams($ref_rfx_id['Rfx']['reference_rfx_id']) . "'");
                        $rfx_reference_attachments = $this->getDataAll('RfxReferenceAttachment', $rfx_reference_attachments);
                        if (count($att_ids) != 0 || !empty($rfx_reference_attachments)) {
                            if (count($att_ids) > 0) {
                                $ref_attachments = $this->Rfx->query("EXEC spRfxResponseRefAttachmentsSelect @response_id='" . $this->spParamsSanitize($responseExistCheck["RfxResponseInvite"]["response_id"]) . "'");
                                $ref_attachments = $this->getDataAll('Rfx', $ref_attachments);
                                if (count($ref_attachments) > 0) {
                                    foreach ($ref_attachments as $ref_attachment) {
                                        $delete = $this->Rfx->query("EXEC spRfxResponseAttachementDelete @attachment_id='" . $this->spParamsSanitize($ref_attachment['Rfx']['attachment_id']) . "'");
                                    }
                                }
                                foreach ($att_ids as $att_id) {
                                    $att_details = $this->Rfx->query("EXEC spRfxQuotationPiAttachmentSelectByIdNew @rfx_quotation_pi_attachment_id='" . $this->spParams($att_id) . "'");
                                    $att_details = $this->getData('Rfx', $att_details);
                                    $save = $this->Rfx->query("EXEC spRfxResponseAttachementInsertRef
                                                                    @rfx_id='" . $this->spParamsSanitize($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "',
                                                                    @response_id='" . $this->spParamsSanitize($responseExistCheck["RfxResponseInvite"]["response_id"]) . "',                        
                                                                    @document_name='" . $this->spParamsSanitize($att_details["Rfx"]["document_name"]) . "',
                                                                    @document_file_name='" . $this->spParamsSanitize($att_details["Rfx"]["document_file_name"]) . "',
                                                                    @document_system_file_name='" . $this->spParamsSanitize($att_details["Rfx"]["document_system_file_name"]) . "',
                                                                    @document_type='Others',
                                                                    @created_date='" . date("Y-m-d H:i:s") . "',
                                                                    @destination_source='" . $this->spParamsSanitize($att_details["Rfx"]["destination_source"]) . "',
                                                                    @is_ref='1'
                                                                    ");
                                    if ($save) {
                                        $last_id = $save[0][0]['InsertedId'];
                                        if ($att_details["Rfx"]["destination_source"] == '0') {
                                            $data_attch = $this->Rfx->query("EXEC spAttachmentReferenceIdSelect @reference_id='" . $this->spParams($att_details["Rfx"]["rfx_quotation_pi_attachment_id"]) . "',@attachment_type='16'");
                                            $file_data = $this->GetData('Attachment', $data_attch);
                                            $save1 = $this->Rfx->query("EXEC spAttachmentInsert 
                                                                                    @reference_id='" . $this->spParams($last_id) . "',
                                                                                    @attachment_type='2',
                                                                                    @attachment_file_name='" . $this->spParams($file_data["Attachment"]["attachment_file_name"]) . "',
                                                                                    @attachement_file_content='" . $this->spParams($file_data["Attachment"]["attachement_file_content"]) . "',
                                                                                    @attachment_file_type='" . $this->spParams($file_data["Attachment"]["attachment_file_type"]) . "',
                                                                                    @attachment_file_size='" . $this->spParams($file_data["Attachment"]["attachment_file_size"]) . "',
                                                                                    @created_date='" . date("Y-m-d H:i:s") . "'
                                                                                    ");
                                        }
                                    }
                                }
                            }


                            // debug("EXEC spRfxResponseAttachementDeleteForRefRfx @rfx_id='" . $this->spParams($ref_rfx_id['Rfx']['reference_rfx_id']) . "',@response_id='" . $this->spParams($responseExistCheck["RfxResponseInvite"]["response_id"]) . "',@is_ref='1'");die;
                            // added new reference attachments in the response attachment table for the supplier
                            if (!empty($rfx_reference_attachments)) {
                                foreach ($rfx_reference_attachments as $att_id) {
                                    $save = $this->Rfx->query("EXEC spRfxResponseAttachementInsertRef
                                                                    @rfx_id='" . $this->spParamsSanitize($ref_rfx_id["Rfx"]["reference_rfx_id"]) . "',
                                                                    @response_id='" . $this->spParamsSanitize($responseExistCheck["RfxResponseInvite"]["response_id"]) . "',                        
                                                                    @document_name='" . $this->spParamsSanitize($att_id["RfxReferenceAttachment"]["document_name"]) . "',
                                                                    @document_file_name='" . $this->spParamsSanitize($att_id["RfxReferenceAttachment"]["document_file_name"]) . "',
                                                                    @document_system_file_name='" . $this->spParamsSanitize($att_id["RfxReferenceAttachment"]["document_system_file_name"]) . "',
                                                                    @document_type='Others',
                                                                    @created_date='" . date("Y-m-d H:i:s") . "',
                                                                    @destination_source='" . $this->spParamsSanitize($att_id["RfxReferenceAttachment"]["destination_source"]) . "',
                                                                    @is_ref='1'
                                                                    ");
                                    if ($save) {
                                        $last_id = $save[0][0]['InsertedId'];
                                        if ($att_id["RfxReferenceAttachment"]["destination_source"] == '0') {
                                            $data_attch = $this->Attachment->query("EXEC spAttachmentReferenceIdSelect @reference_id='" . $this->spParams($att_id["RfxReferenceAttachment"]["rfx_reference_attachment_id"]) . "',@attachment_type='8'");
                                            $file_data = $this->GetData('Attachment', $data_attch);
                                            $save1 = $this->Attachment->query("EXEC spAttachmentInsert 
                                                                                    @reference_id='" . $this->spParams($last_id) . "',
                                                                                    @attachment_type='2',
                                                                                    @attachment_file_name='" . $this->spParams($file_data["Attachment"]["attachment_file_name"]) . "',
                                                                                    @attachement_file_content='" . $this->spParams($file_data["Attachment"]["attachement_file_content"]) . "',
                                                                                    @attachment_file_type='" . $this->spParams($file_data["Attachment"]["attachment_file_type"]) . "',
                                                                                    @attachment_file_size='" . $this->spParams($file_data["Attachment"]["attachment_file_size"]) . "',
                                                                                    @created_date='" . date("Y-m-d H:i:s") . "'
                                                                                    ");
                                        }
                                    }
                                }
                            }
                        } else {
                            $message = 'error1';
                            return $message;
                            die;
                        }
                    }
                } 
            }
        } else {
            $message = 'error3';
            return $message;
            die;
        }
        $message = 'success';
        return $message;
        die;

    }
    
     function submitPoApproval($final_array) {
        $this->layout = false;

        $client = new SoapClient(Configure::read('SubmitApprovalSoap'), array('trace' => TRUE, "exceptions" => 0));
        $ESBAuthVO = Configure::read('EmpSubmitAuth');
        $cid = $ESBAuthVO['cID'];
        $pwd = $ESBAuthVO['cPW'];
        $error_ep_id = "";
        $ESBAuthVO = new AppController();
        $startProcessWSVO = new AppController();
        $object = new AppController();

        $ESBAuthVO->cID = $cid;
        $ESBAuthVO->cPW = $pwd;

        
        $body = $final_array['Body'];
        
        $p =0;
        $error = array();
        $draft_user_array = array();
        if($error_ep_id == ""){
            $epid = $this->getEPID($final_array['Username']);
            if(empty($epid) && isset($error_ep_id)){
                $error_ep_id = "error";
                $error['status'] = "error";
                $error['message'] = 'Data not found for user:'.$final_array['Username'];
                return $error;
                die;
            }
            if($error_ep_id == ""){
                $draft_user_array[] = array(
                    "UserID" => $epid['epid'],
                    "Arbitrary" => -1,
                    "ActionType" => 0,
                    "Activity" => 0,
                    "RouteModify" => -1,
                    "Sequence" => $p,
                    "BodyModify" => -1,
                    "MailAddress" => $epid['email'],
                );
                $p++;
            }
        }
        $stroutevo_approver_array = array();
        if($error_ep_id == ""){
            if(!empty($final_array['Approver'])){
                foreach($final_array['Approver'] as $approvers){
                    $epid = $this->getEPID($approvers);
                    if(empty($epid) && isset($error_ep_id)){
                        $error_ep_id = "error";
                        $error['status'] = "error";
                        $error['message'] = 'Data not found for user:'.$approvers;
                        return $error;
                        die;
                        break;
                    }
                    if($error_ep_id == ""){
                        $stroutevo_approver_array[] = array(
                        "UserID" => $epid['epid'],
                        "Arbitrary" => -1,
                        "ActionType" => 0,
                        "Activity" => 1,
                        "RouteModify" => -1,
                        "Sequence" => $p,
                        "BodyModify" => -1,
                        "MailAddress" => $epid['email'],
                        );
                        $p++;
                    }
                }
            }
        } 
        
        $stroutevo_noti_array = array();
        //debug($final_array['Notification']);
        if(!empty($final_array['Notification'])){
            foreach($final_array['Notification'] as $noti){
                $epid = $this->getEPID($noti);
                if(empty($epid) && isset($error_ep_id)){
                    $error_ep_id = "error";
                    $error['status'] = "error";
                    $error['message'] = 'Data not found for user:'.$noti;
                    return $error;
                    die;
                    break;
                }
//                $epid['epid'] = 'pmt.rfx';
//                $epid['email'] = 'pmt.rfx@stage.samsung.com';
                if($error_ep_id == ""){
                    $stroutevo_noti_array[] = array(
                        "UserID" => $epid['epid'],
                        "Arbitrary" => -1,
                        "ActionType" => 0,
                        "Activity" => 9,
                        "RouteModify" => -1,
                        "Sequence" => $p,
                        "BodyModify" => -1,
                        "MailAddress" => $epid['email'],
                    );
                    $p++;
                }
            }
        }
       
        $Body = $body;
        $Title = 'Purchase Order Request Approval';
        $BodyType = "1";
        $NotiMail = "1";
        $SendDMS = false;
        $TimeZone = 'GMT+5:30';
        $drm = "pc_count=-1|valid_days=365|use_count=-1|can_view=1|can_print=0|can_save=0|confirm_mail_4in=0|confirm_mail=1";
        $DrmOptionInfo = $drm;
        $LocaleInfo = "en_IN.UTF-8";
        $CreateDate = '20070514094415';
        $SystemID = $cid;

        if(empty($stroutevo_approver_array)){
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'No approvers found for the PO';
            return $error;
            die;
        }
        
        $RouteWSVO = array_merge($draft_user_array, $stroutevo_approver_array, $stroutevo_noti_array);
        
        
        $AttachmentWSVO = array();

        $startProcessWSVO->Title = $Title;
        $startProcessWSVO->BodyType = $BodyType;
        $startProcessWSVO->NotiMail = $NotiMail;
        $startProcessWSVO->SendDMS = $SendDMS;
        $startProcessWSVO->TimeZone = $TimeZone;
        $startProcessWSVO->DrmOptionInfo = $DrmOptionInfo;
        $startProcessWSVO->LocaleInfo = $LocaleInfo;
        $startProcessWSVO->CreateDate = $CreateDate;
        $startProcessWSVO->SystemID = $SystemID;
        $startProcessWSVO->MisID = $this->genearteMisKey();
        $startProcessWSVO->RouteVOs = $RouteWSVO;
        $startProcessWSVO->AttachmentWSVO = $AttachmentWSVO;
        $startProcessWSVO->Body = $Body;
        
        $object->esbAuthVO = $ESBAuthVO;
        $object->startProcessWSVO = $startProcessWSVO;
        if($error_ep_id == ""){
        try {
            $output_submit_approval = $client->__soapCall("submitApproval", array($object));
        } catch (Exception $e) {
            var_dump($e);
        }
        if (is_soap_fault($output_submit_approval)) {
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'Can not call soap client:'.$output_submit_approval->faultstring;
            return $error;
            die;
        } else {
            
            if ($output_submit_approval->result == "success") {
                //Insert MIS ID, and update status in process
//                $rfxdetails["Rfx"]["rfx_id"] = $final_array['siel_rfx_id'];
//                $status_sub = 'In Process';
//                $company_id = $final_array['supplier_company_id'];
                $mis_key = $startProcessWSVO->MisID;
//                $update_approval_data_for_orx = $this->User->query("EXEC spOrxCheilApprovalStatusUpdateNew
//                                                @siel_rfx_id='" . $this->spParamsSanitize($rfxdetails["Rfx"]["rfx_id"]) . "',
//                                                @status='" . $this->spParamsSanitize($status_sub) . "',                        
//                                                @company_id='" . $this->spParamsSanitize($company_id) . "',
//                                                @approval_mis_key='" . $this->spParamsSanitize($mis_key) . "'
//                                                ");
                $error_ep_id = "success";
                $error['status'] = "success";
                $error['mis_key'] = $mis_key;
                $error['message'] = 'Successfully sent for approval';
                return $error;
                die;
            } else {
                $error_ep_id = "error";
                $error['status'] = "error";
                $error['message'] = 'Sorry! can not send data for approval';
                return $error;
                die;
            }
        }
        } else {
            $error_ep_id = "error";
            $error['status'] = "error";
            $error['message'] = 'Sorry! can not send data for approval';
            return $error;
            die;
        }
        //debug($error_ep_id);die;
        //echo "------------End Output---------------<br />";
        //echo "REQUEST:\n" . $client->__getLastRequest() . "\n";
        if($error_ep_id != "" && $error_ep_id == "success"){
            $error['status'] = "error";
            $error['message'] = 'Sorry!can not send data for approval';
            return $error;
            die;
        } elseif($error_ep_id != "" && $error_ep_id == "error") {
            $error['status'] = "error";
            $error['message'] = 'Sorry!can not send data for approval';
            return $error;
            die;
        }
        $error['status'] = "error";
        $error['message'] = 'Sorry!can not send data for approval';
        return $error;
        die;
    }
}