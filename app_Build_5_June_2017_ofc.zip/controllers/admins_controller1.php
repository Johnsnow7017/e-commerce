<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class AdminsController extends AppController {
//    var $name = 'Actions';
	
	public function beforeFilter() {
            parent::beforeFilter();
	}
    
    public function index() {
    
        
    }
    public function add_exam(){
        $this->layout = "admin";
        debug($this->data);
        if(!empty($this->data)){
            if(isset($this->data['admin']['exam_name']) && $this->data['admin']['exam_name'] != ''){
                
            }
        }
        
    }
    public function add_question(){
        $this->layout = "admin";
        
    }
    public function getQuestionType(){
        $this->layout = false;
        if (isset($_POST) && $_POST["question_type"] != "") {
            $question_type = $_POST["question_type"];
            $this->set("question_type",$question_type);
            
        }
    }
    

    public function timeover(){
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            debug($this->params['named']['step']);
            debug("d");die;
        }
    }
    public function exam_instruction(){}
    
    public function exam_instruction_next(){}
    
    public function test1_instruction(){}
}

?>
