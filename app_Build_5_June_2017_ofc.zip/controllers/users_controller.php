<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class UsersController extends AppController {
    public $name = 'Users';
	//var $name = 'Suppliers';
    var $components = array('Auth'); 
     

    var $uses = array("exam","intelligent_question","User");
	
    
    public function index() {
    
        
    }
//    public function register(){
////        $this->layout = "admin";
////        $exams = $this->exam->query("select * from exams");
////        $exams = parent::getDataAll('Exam', $exams);
////        $this->set("exams",$exams);
//        if(!empty($this->data)){
//            
//            debug($this->data);die;
//        }
//    }
    function register() {
        if (!empty($this->data)){
           // debug($this->data);die;
            $this->data['user']['password'] = security::hash($this->data['user']['password'], "", true);
            $this->data['user']['type'] = 'Student';
            $this->data['user']['status'] = 'Active';
            $this->data['user']['created_date'] = date('Y-m-d H:m:s');
            $this->data['user']['modified_date'] = date('Y-m-d H:m:s');
            $this->User->create();
            if ($this->User->save($this->data['user'])) {
                
            }
        }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow("register","intelligence_test");
    }
    
    function login(){
        if (!empty($this->data)){
            if ($this->Auth->user()) {
                debug("a");die;
            } else {
                debug("not login");die;
            }
        }
    }
    
//    public function third(){
//        
//    }
}

?>
