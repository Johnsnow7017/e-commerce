-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2017 at 11:33 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`exam_id`, `name`, `description`, `group_id`) VALUES
(1, 'test', 'dfghjgk', 1),
(2, 'Another Test', 'srtdyftuy', 4),
(3, 'ttytyt', 'hjhghjghhuhyui', 3);

-- --------------------------------------------------------

--
-- Table structure for table `intelligent_questions`
--

CREATE TABLE `intelligent_questions` (
  `i_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intelligent_questions`
--

INSERT INTO `intelligent_questions` (`i_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`) VALUES
(11, 'YYYYYYYYYYYYYYYYYYYYYYYYY', 'intelligence_test', '2', '11_1496392090_5838_HD_Wallpaper_(2542).jpg', ''),
(12, 'YYYYYYYYYYYYYYYYYYYYYYYYY', 'intelligence_test', '4', '12_1496392234_7062_HD_Wallpaper_(2542).jpg', NULL),
(13, 'dfrtghjkl', 'intelligence_test', '1', '13_1496392541_45_HD_Wallpaper_(2542).jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `quiz_id` int(11) NOT NULL,
  `quiz_name` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `selective_attension_questions`
--

CREATE TABLE `selective_attension_questions` (
  `se_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selective_attension_questions`
--

INSERT INTO `selective_attension_questions` (`se_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`) VALUES
(1, '', 'selective_attension_test', '4', '1_1496392890_4292_HD_Wallpaper_(2542).jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `spatial_scanning_questions`
--

CREATE TABLE `spatial_scanning_questions` (
  `sp_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spatial_scanning_questions`
--

INSERT INTO `spatial_scanning_questions` (`sp_question_id`, `question_desc`, `question_type`, `question_img_path`, `status`) VALUES
(1, 'dfghjk', 'spatial_scanning_test', NULL, NULL),
(2, 'dfghjk', 'spatial_scanning_test', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sp_question_option_mappings`
--

CREATE TABLE `sp_question_option_mappings` (
  `mapping_id` int(11) NOT NULL,
  `sp_question_id` int(11) NOT NULL,
  `shortest_route_from` varchar(100) NOT NULL,
  `option_a` varchar(20) NOT NULL,
  `option_b` varchar(20) NOT NULL,
  `option_c` varchar(20) NOT NULL,
  `option_d` varchar(20) NOT NULL,
  `option_e` varchar(20) NOT NULL,
  `correct_answer` varchar(10) NOT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_question_option_mappings`
--

INSERT INTO `sp_question_option_mappings` (`mapping_id`, `sp_question_id`, `shortest_route_from`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_answer`, `status`) VALUES
(1, 2, 'P To Q', '2', '3', '4', '5', '6', '1', NULL),
(2, 2, 'A To R', '3', '2', '6', '7', '1', '2', NULL),
(3, 2, 'B To S', '4', '5', '3', '2', '9', '3', NULL),
(4, 2, 'C To T', '5', '6', '7', '9', '1', '5', NULL),
(5, 2, 'D To U', '6', '3', '2', '1', '4', '4', NULL),
(6, 2, 'E To V', '7', '2', '3', '4', '9', '1', NULL),
(7, 2, 'F To W', '8', '1', '2', '3', '4', '1', NULL),
(8, 2, 'G To X', '9', '1', '2', '3', '8', '5', NULL),
(9, 2, 'H To Y', '10', '9', '2', '5', '7', '1', NULL),
(10, 2, 'I To Z', '3', '2', '6', '7', '1', '3', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  ADD PRIMARY KEY (`i_question_id`);

--
-- Indexes for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  ADD PRIMARY KEY (`se_question_id`);

--
-- Indexes for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  ADD PRIMARY KEY (`sp_question_id`);

--
-- Indexes for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  ADD PRIMARY KEY (`mapping_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  MODIFY `i_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  MODIFY `se_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  MODIFY `sp_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  MODIFY `mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
