<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class AdminController extends AppController {
//    var $name = 'Actions';
	
	public function beforeFilter() {
            parent::beforeFilter();
	}
    
    public function index() {
		$this->layout = 'admin';
        
    }
    public function login(){
        $this->layout = 'admin';
    }
    public function logout(){
        $this->layout = 'admin';
    }
    public function add_exam(){
        $this->layout = 'admin';
    }
}

?>
