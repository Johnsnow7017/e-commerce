<?php
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Network\Exception\ForbiddenException;

/**
 * Application Controller
 *
 */
class AppController extends Controller
{
    /**
    * User Id
    */
    public $user_id;
    
    /**
     * Initialization hook method.
     */
    public function initialize() {
        
        parent::initialize();
        $this->template = 'ajax';
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Auth', [
                    'loginAction'=>['controller'=>'Pages', 'action'=>'unauthorized', '_ext'=>'json'],
                    'authorize'=>['Controller'],
                    'authError'=>"Error"
                         
            ]); 
    }
    
    
    /**
    * Before filter logic
    *
    */
    public function beforeFilter(Event $event)
    {
        
        $this->user_id = $this->Auth->user('id');
        
        // validate user token for logged user
         if($this->user_id) {
            if(!$this->checkUserToken()) { 
            $this->Auth->logout(); // logout user
            throw new ForbiddenException("Invalid Token!");    // throw an 403 error
            }
        }        
    }
 

    /**
     * Check User Token
     */
    public function checkUserToken() 
    {
            $request_token = $this->getRequestToken();
            
            if (!$request_token) {
               return false;
            }
            
            if ($request_token != $this->userToken()) {               
                return false;
            }
        return true;
    }
    
    /**
     * Get Request token
     */
    public function getRequestToken() 
    {
        
        $headers = $this->getHeaders();
        if (!isset($headers['Authorization'])) return false;
        $token = explode(" ", $headers['Authorization']);       
        return $token[1];
    }
    
    /**
     * Get Request headers
     */
    private function getHeaders() 
    {
        $headers = getallheaders();        
        return $headers;
    }
    
    /**
    * Get User token
    *
    */
    public function userToken()
    {
        return $this->Auth->user('token');
    }
    
    /**
    * Authorization default true
    */
    public function isAuthorized($user)
    {
        return false;
    }
    
}