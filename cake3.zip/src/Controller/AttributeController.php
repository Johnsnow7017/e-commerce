<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure\Engine\PhpConfig;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use App\Core\Setting;
use Cake\Core\App;
use Cake\Validation\Validator;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;


class AttributeController extends AppController {
    //var $helpers = array('DateFormat');
//public $helpers = array('DateFormat');
    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
        
    }
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('index','addAttribute');
    }
   
    public function index(){
        $this->viewBuilder()->layout('admin');
        $attribute_reg = TableRegistry::get('attribute_masters');
        $query = $attribute_reg->find('all');
        $attributes = $this->getResultArray('Attribute',$query);
        $this->set("attributes",$attributes);
    }
    function addAttribute(){
        $this->viewBuilder()->layout('admin');
        if(!empty($this->request->data)){
            if(trim($this->request->data['attribute_name']) == ''){
                $this->Flash->error(__('Attribute name can not be blank'));
                $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
            } else if(trim($this->request->data['public_name']) == ''){
                $this->Flash->error(__('Public name can not be blank'));
                $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
            } else if(trim($this->request->data['attribute_type']) == '' || $this->request->data['attribute_type'] == '0'){
                $this->Flash->error(__('Please select attribute type'));
                $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
            } else {
                $attribute_name = trim($this->request->data['attribute_name']);
                $public_name = trim($this->request->data['public_name']);
                $attribute_type = trim($this->request->data['attribute_type']);
                $created_by = $this->Auth->user('user_id');
                $modified_by = $this->Auth->user('user_id');
                $status = 'Active';
                $created_date = date('Y-m-d H:m:s');
                $modified_date = date('Y-m-d H:m:s');
                $attribute_reg = TableRegistry::get('attribute_masters');
                $query = $attribute_reg->find('all')->where(['attribute_name' => $attribute_name]);
                $attribute_exists = $this->getResultArray('Attribute',$query);
                if(empty($attribute_exists)){
                    $query = $attribute_reg->query();
                    $insert = $query->insert(['attribute_name','public_name','attribute_type','status','created_by','created_date','modified_by','modified_date'])
                        ->values([
                            'attribute_name' => $attribute_name,
                            'public_name' => $public_name,
                            'attribute_type' => $attribute_type,
                            'status' => $status,
                            'created_by' => $created_by,
                            'created_date' => $created_date,
                            'modified_by' => $modified_by,
                            'modified_date' => $modified_date
                        ])
                        ->execute();
                    if($insert){
                        $this->Flash->success(__('Attribute added successfully'));
                        $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                    }
                } else {
                    $this->Flash->error(__('This attribute name already exists'));
                    $this->redirect(array('controller'=>'Attribute','action' => 'addAttribute'));
                }
            }
        }
    }
    
    function deactivateAttribute(){
        if($this->request->params['pass'][0] != ''){
            $attribute_id = $this->request->params['pass'][0];
            $attribute_reg = TableRegistry::get('attribute_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $update_attribute_status = $attribute_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['attribute_id' => $attribute_id]);
            if($update_attribute_status){
                $this->Flash->success(__($this->Error->getError("Attribute deactivated successfully")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Attribute can not be deactivated")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Attribute can not be deactivated")));
            $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
        }
    }
    function activateAttribute(){
        if($this->request->params['pass'][0] != ''){
            $attribute_id = $this->request->params['pass'][0];
            $attribute_reg = TableRegistry::get('attribute_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $update_attribute_status = $attribute_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['attribute_id' => $attribute_id]);
            if($update_attribute_status){
                $this->Flash->success(__($this->Error->getError("Attribute activated successfully")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Attribute can not be activated")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Attribute can not be activated")));
            $this->redirect(array('controller' => 'Attribute', 'action' => 'index'));
        }
    }
    function activateAttributeAll(){
        if(isset($this->request->data['attribute_id']) && !empty($this->request->data['attribute_id'])){
                $attribute_reg = TableRegistry::get('attribute_masters');
                $modifed_date = date('Y-m-d H:m:s');
                $update_attribute_status = $attribute_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['attribute_id IN' =>  $this->request->data['attribute_id']]);
                if($update_attribute_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function deactivateAttributeAll(){
        if(isset($this->request->data['attribute_id']) && !empty($this->request->data['attribute_id'])){
                $attribute_reg = TableRegistry::get('attribute_masters');
                $modifed_date = date('Y-m-d H:m:s');
                $update_attribute_status = $attribute_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['attribute_id IN' =>  $this->request->data['attribute_id']]);
                if($update_attribute_status){
                    $msg = 'success';
                } else {
                    echo "fail";
                    die;
                }
            if($msg != '' && $msg == 'success'){
                echo 'success';
                die;
            } else {
                echo 'fail';
                die;
            }
        }
    }
    function editAttribute(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $attribute_id = $this->request->params['pass'][0];
            if(trim($attribute_id) == ''){
                $this->Flash->error(__('Sorry! attribute id not exists.'));
                $this->redirect(array('controller'=>'Attribute','action' => 'index'));
            } else {
                $attribute_id = $this->request->params['pass'][0];
                $attribute_reg = TableRegistry::get('attribute_masters');
                $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                $attribute = $this->getResultArray('Attribute',$query);
                if(empty($attribute)){
                    $this->Flash->error(__('Sorry! No such attribute id exists'));
                    $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                } else {
                    $this->set("attribute",$attribute);
                    if(!empty($this->request->data)){
                        $postDataChanged = false;
                        if (isset($this->request->data) && count($this->request->data) > 0) {
                            $postData = parent::cleanPostData($this->request->data, $postDataChanged);
                        }
                        if ($postDataChanged == true) {
                            $this->Flash->error(__('You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed'));
                            $this->redirect(array('controller'=>'Brand','action' => 'editBrand/'.$brand_id));
                        } else {
                            if(trim($this->request->data['attribute_name']) == ''){
                                $this->Flash->error(__('Attribute name can not be blank'));
                                $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id));
                            } else if(trim($this->request->data['public_name']) == ''){
                                $this->Flash->error(__('Public name can not be blank'));
                                $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id));
                            } else if(trim($this->request->data['attribute_type']) == '' || $this->request->data['attribute_type'] == '0'){
                                $this->Flash->error(__('Please select attribute type'));
                                $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id));
                            } else {
                                $attribute_name = trim($this->request->data['attribute_name']);
                                $public_name = trim($this->request->data['public_name']);
                                $attribute_type = trim($this->request->data['attribute_type']);
                                $modified_by = $this->Auth->user('user_id');
                                $status = 'Active';
                                $modified_date = date('Y-m-d H:m:s');
                                $attribute_reg = TableRegistry::get('attribute_masters');
                                $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                                $attribute_details = $this->getResultArray('Attribute',$query);
                                if(!empty($attribute_details)){
                                    $at_name = $attribute_details['Attribute']['attribute_name'];
                                    if($at_name == $attribute_name){
                                        $attribute_reg = TableRegistry::get('attribute_masters');
                                        $update_attribute = $attribute_reg->updateAll(['attribute_name' =>$attribute_name,'public_name' =>$public_name,'attribute_type' =>$attribute_type , 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modified_date], ['attribute_id' => $attribute_id]);
                                        if($update_attribute){
                                            $this->Flash->success(__('Attribute edited successfully'));
                                            $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                                        } else {
                                            $this->Flash->error(__('Sorry! Attribute can not be edited.'));
                                            $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id)); 
                                        }   
                                    } else {
                                        $attribute_reg = TableRegistry::get('attribute_masters');
                                        $query = $attribute_reg->find('all')->where(['attribute_name' => $attribute_name]);
                                        $attribute_name_exists = $this->getResultArray('Attribute',$query);
                                        if(empty($attribute_name_exists)){
                                            $attribute_reg = TableRegistry::get('attribute_masters');
                                            $update_attribute = $attribute_reg->updateAll(['attribute_name' =>$attribute_name,'public_name' =>$public_name,'attribute_type' =>$attribute_type , 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modified_date], ['attribute_id' => $attribute_id]);
                                            if($update_attribute){
                                                $this->Flash->success(__('Attribute edited successfully'));
                                                $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                                            } else {
                                                $this->Flash->error(__('Sorry! Attribute can not be edited.'));
                                                $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id)); 
                                            }   
                                        } else {
                                            $this->Flash->error(__('Attribute name already exists.'));
                                            $this->redirect(array('controller'=>'Attribute','action' => 'editAttribute/'.$attribute_id));
                                        }
                                    }
                                } else {
                                    $this->Flash->error(__('Sorry! No details found for this attribute id .'));
                                    $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                                }
                            }
                        } 
                    }
                }
            }
        }
    }
    public function check(){
        if(isset($this->request->data['attribute_name']) && !empty($this->request->data['attribute_name'])){
            $attribute_reg = TableRegistry::get('attribute_masters');
            $query = $attribute_reg->find('all')->where(['attribute_name' => $this->request->data['attribute_name']]);
            $attribute_exists = $this->getResultArray('Attribute',$query);
            if(empty($attribute_exists)){
                echo "success";
                die;
            } else {
                echo "fail";
                die;
            }
        }
    }
    public function editCheck(){
        if(isset($this->request->data['attribute_id']) && $this->request->data['attribute_id']  != '' && isset($this->request->data['attribute_name']) && !empty($this->request->data['attribute_name'])){
            $attribute_reg = TableRegistry::get('attribute_masters');
            $attribute_name = $this->request->data['attribute_name'];
            $attribute_id = $this->request->data['attribute_id'];
            $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
            $attribute_details = $this->getResultArray('Attribute',$query);
            if(!empty($attribute_details)){
                $at_name = $attribute_details['Attribute']['attribute_name'];
                if($at_name == $attribute_name){
                    echo "success";
                    die;
                } else {
                    $attribute_reg = TableRegistry::get('attribute_masters');
                    $query = $attribute_reg->find('all')->where(['attribute_name' => $attribute_name]);
                    $attribute_name_exists = $this->getResultArray('Attribute',$query);
                    if(empty($attribute_name_exists)){
                        echo "success";
                        die;
                    } else {
                        echo "fail";
                        die;
                    }
                }
            } else {
                echo "fail";
                die;
            }
        }
    }
    function viewFeature(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $attribute_id = $this->request->params['pass'][0];
            if(trim($attribute_id) == ''){
                $this->Flash->error(__('Sorry! attribute id not exists.'));
                $this->redirect(array('controller'=>'Attribute','action' => 'index'));
            } else {
                $attribute_id = $this->request->params['pass'][0];
                $attribute_reg = TableRegistry::get('attribute_masters');
                $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                $attribute = $this->getResultArray('Attribute',$query);
                if(empty($attribute)){
                    $this->Flash->error(__('Sorry! No such attribute id exists'));
                    $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                } else {
                    $this->set("attributes",$attribute);
                    $feature_reg = TableRegistry::get('feature_masters');
                    $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
                    $feature = $this->getResultArray('Feature',$query);
                    $this->set("features",$feature);

                }
            }
        }
    }
    function deactivateFeature(){
        if(isset($this->request->params['pass'][0]) && isset($this->request->params['pass'][1]) && $this->request->params['pass'][0] != '' && $this->request->params['pass'][1] != ''){
            $feature_id = $this->request->params['pass'][0];
            $attribute_id = $this->request->params['pass'][1];
            $feature_reg = TableRegistry::get('feature_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $feature_reg = TableRegistry::get('feature_masters');
            $query = $feature_reg->find('all')->where(['feature_id' => $feature_id]);
            $feature = $this->getResultArray('Feature',$query);
            if(!empty($feature)){
                $at_id = $feature['Feature']['attribute_id'];
                if($attribute_id == $at_id){
                    $feature_reg = TableRegistry::get('feature_masters');
                    $update_feature_status = $feature_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['feature_id' => $feature_id]);
                    if($update_feature_status){
                        $this->Flash->success(__($this->Error->getError("Feature deactivated successfully")));
                        $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                    } else {
                        $this->Flash->error(__($this->Error->getError("Sorry! Feature can not be deactivated")));
                        $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                    }
                } else {
                    $this->Flash->error(__($this->Error->getError("Sorry! This feature is not under that attribute.")));
                    $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                }
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Feature id does not exists.")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Feature can not be deactivated")));
            $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
        }
    }
    function activateFeature(){
        if(isset($this->request->params['pass'][0]) && isset($this->request->params['pass'][1]) && $this->request->params['pass'][0] != '' && $this->request->params['pass'][1] != ''){
            $feature_id = $this->request->params['pass'][0];
            $attribute_id = $this->request->params['pass'][1];
            $feature_reg = TableRegistry::get('feature_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $feature_reg = TableRegistry::get('feature_masters');
            $query = $feature_reg->find('all')->where(['feature_id' => $feature_id]);
            $feature = $this->getResultArray('Feature',$query);
            if(!empty($feature)){
                $at_id = $feature['Feature']['attribute_id'];
                if($attribute_id == $at_id){
                    $feature_reg = TableRegistry::get('feature_masters');
                    $update_feature_status = $feature_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['feature_id' => $feature_id]);
                    if($update_feature_status){
                        $this->Flash->success(__($this->Error->getError("Feature activated successfully")));
                        $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                    } else {
                        $this->Flash->error(__($this->Error->getError("Sorry! Feature can not be activated")));
                        $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                    }
                } else {
                    $this->Flash->error(__($this->Error->getError("Sorry! This feature is not under that attribute.")));
                    $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
                }
            } else {
                $this->Flash->error(__($this->Error->getError("Sorry! Feature id does not exists.")));
                $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
            }
        } else {
            $this->Flash->error(__($this->Error->getError("Sorry! Feature can not be activated")));
            $this->redirect(array('controller' => 'Attribute', 'action' => 'viewFeature/'.$attribute_id));
        }
    }
    function deactivateFeatureAll(){
        if(isset($this->request->data['attribute_id']) && !empty($this->request->data['attribute_id']) && isset($this->request->data['feature_id']) && $this->request->data['feature_id'] != ''){
            $feature_id = $this->request->data['feature_id'];
            $attribute_id = $this->request->data['attribute_id'];
            $feature_reg = TableRegistry::get('feature_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $feature_reg = TableRegistry::get('feature_masters');
            $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
            $feature = $this->getResultArray('Feature',$query);
            if(!empty($feature)){
                $fe_id = array();
                foreach($feature as $fe){
                    $fe_id[] = $fe['Feature']['feature_id'];
                }
                $diff = array_diff_assoc($feature_id, $fe_id);
                if(empty($diff)){
                    $feature_reg = TableRegistry::get('feature_masters');
                    $update_feature_status = $feature_reg->updateAll(['status' => 'Inactive', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['feature_id IN' => $this->request->data['feature_id']]);
                    if($update_feature_status){
                        echo 'success';die;
                    } else {
                        echo 'fail';die;
                    }
                } else {
                    echo 'fail';die;
                }
            } else {
                echo 'fail';die;
            }
        } else {
            echo 'fail';die;
        }
    }
    function activateFeatureAll(){
        if(isset($this->request->data['attribute_id']) && !empty($this->request->data['attribute_id']) && isset($this->request->data['feature_id']) && $this->request->data['feature_id'] != ''){
            $feature_id = $this->request->data['feature_id'];
            $attribute_id = $this->request->data['attribute_id'];
            $feature_reg = TableRegistry::get('feature_masters');
            $modifed_date = date('Y-m-d H:m:s');
            $feature_reg = TableRegistry::get('feature_masters');
            $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
            $feature = $this->getResultArray('Feature',$query);
            if(!empty($feature)){
                $fe_id = array();
                foreach($feature as $fe){
                    $fe_id[] = $fe['Feature']['feature_id'];
                }
                $diff = array_diff_assoc($feature_id, $fe_id);
                if(empty($diff)){
                    $feature_reg = TableRegistry::get('feature_masters');
                    $update_feature_status = $feature_reg->updateAll(['status' => 'Active', 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modifed_date], ['feature_id IN' => $this->request->data['feature_id']]);
                    if($update_feature_status){
                        echo 'success';die;
                    } else {
                        echo 'fail';die;
                    }
                } else {
                    echo 'fail';die;
                }
            } else {
                echo 'fail';die;
            }
        } else {
            echo 'fail';die;
        }
    }
    function addFeature(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $attribute_id = $this->request->params['pass'][0];
            if(trim($attribute_id) == ''){
                $this->Flash->error(__('Sorry! attribute id not exists.'));
                $this->redirect(array('controller'=>'Attribute','action' => 'index'));
            } else {
                $attribute_id = $this->request->params['pass'][0];
                $attribute_reg = TableRegistry::get('attribute_masters');
                $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                $attribute = $this->getResultArray('Attribute',$query);
                if(empty($attribute)){
                    $this->Flash->error(__('Sorry! No such attribute id exists'));
                    $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                } else {
                    $this->set("attribute_id",$attribute_id);
                    $this->set('attributes',$attribute);
                    if(!empty($this->request->data)){
                        $at_id = $this->request->data['attribute_id'];
                        $postDataChanged = false;
                        if (isset($this->request->data) && count($this->request->data) > 0) {
                            $postData = parent::cleanPostData($this->request->data, $postDataChanged);
                        }
                        if ($postDataChanged == true) {
                            $this->Flash->error(__('You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed'));
                            $this->redirect(array('controller'=>'Attribute','action' => 'addFeature/'.$at_id));
                        } else {
                            $feature_name = trim($this->request->data['feature_name']);
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['attribute_id' => $at_id,'feature_name'=>$feature_name]);
                            $feature = $this->getResultArray('Feature',$query);
                            if(empty($feature)){
                                $created_by = $this->Auth->user('user_id');
                                $modified_by = $this->Auth->user('user_id');
                                $status = 'Active';
                                $created_date = date('Y-m-d H:m:s');
                                $modified_date = date('Y-m-d H:m:s');
                                $feature_reg = TableRegistry::get('feature_masters');
                                $query = $feature_reg->query();
                                $insert = $query->insert(['attribute_id','feature_name','status','created_by','created_date','modified_by','modified_date'])
                                    ->values([
                                        'attribute_id' => $at_id,
                                        'feature_name' => $feature_name,
                                        'status' => $status,
                                        'created_by' => $created_by,
                                        'created_date' => $created_date,
                                        'modified_by' => $modified_by,
                                        'modified_date' => $modified_date
                                    ])
                                    ->execute();
                                if($insert){
                                    $this->Flash->success(__('Feature added successfully'));
                                    $this->redirect(array('controller'=>'Attribute','action' => 'viewFeature/'.$at_id));
                                } else {
                                    $this->Flash->error(__('Soory Feature can not be saved.'));
                                    $this->redirect(array('controller'=>'Attribute','action' => 'addFeature/'.$at_id));
                                }
                            } else {
                                $this->Flash->error(__('This feature name already exists for this attribute'));
                                $this->redirect(array('controller'=>'Attribute','action' => 'addFeature/'.$at_id));
                            }
                        }
                    }
                }
            }
        }
    }
    function editFeature(){
        $this->viewBuilder()->layout('admin');
        if($this->request->params['pass'][0] != ''){
            $feature_id = $this->request->params['pass'][0];
            if(trim($feature_id) == ''){
                $this->Flash->error(__('Sorry! feature id not exists.'));
                $this->redirect(array('controller'=>'Attribute','action' => 'index'));
            } else {
                $feature_id = $this->request->params['pass'][0];
                $feature_reg = TableRegistry::get('feature_masters');
                $query = $feature_reg->find('all')->where(['feature_id' => $feature_id]);
                $feature = $this->getResultArray('Feature',$query);
                if(empty($feature)){
                    $this->Flash->error(__('Sorry! No such feature id exists'));
                    $this->redirect(array('controller'=>'Attribute','action' => 'index'));
                } else {
                    $this->set("features",$feature);
                    $at_id = $feature['Feature']['attribute_id'];
                    $attribute_reg = TableRegistry::get('attribute_masters');
                    $query = $attribute_reg->find('all')->where(['attribute_id' => $at_id]);
                    $attribute = $this->getResultArray('Attribute',$query);
                    $this->set('attributes',$attribute);
                    if(!empty($this->request->data)){
                        $at_id = $this->request->data['attribute_id'];
                        $postDataChanged = false;
                        if (isset($this->request->data) && count($this->request->data) > 0) {
                            $postData = parent::cleanPostData($this->request->data, $postDataChanged);
                        }
                        if ($postDataChanged == true) {
                            $this->Flash->error(__('You have either entered a script tag or copied text that contains special characters which cannot be entered through keyboard. Please rectify and proceed'));
                            $this->redirect(array('controller'=>'Attribute','action' => 'addFeature/'.$at_id));
                        } else {
                            $feature_id = trim($this->request->data['feature_id']);
                            $feature_name = trim($this->request->data['feature_name']);
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['attribute_id' => $at_id,'feature_name'=>$feature_name]);
                            $feature = $this->getResultArray('Feature',$query);
                            if(empty($feature)){
                                $modified_by = $this->Auth->user('user_id');
                                $modified_date = date('Y-m-d H:m:s');
                                $feature_reg = TableRegistry::get('feature_masters');
                                $update_feature = $feature_reg->updateAll(['feature_name' =>$feature_name, 'modified_by' => $this->Auth->user('user_id'),'modified_date' => $modified_date], ['feature_id' => $feature_id]);
                                if($update_feature){
                                    $this->Flash->success(__('Feature details updated successfully'));
                                    $this->redirect(array('controller'=>'Attribute','action' => 'viewFeature/'.$at_id));
                                } else {
                                    $this->Flash->error(__('Soory Feature can not be updated.'));
                                    $this->redirect(array('controller'=>'Attribute','action' => 'editFeature/'.$feature_id));
                                }
                            } else {
                                $this->Flash->error(__('This feature name already exists for this attribute'));
                                $this->redirect(array('controller'=>'Attribute','action' => 'editFeature/'.$feature_id));
                            }
                        }
                    }
                }
            }
        }
    }
    
    
}
