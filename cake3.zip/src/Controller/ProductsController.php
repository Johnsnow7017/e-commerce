<?php

// src/Controller/PostsController.php

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure\Engine\PhpConfig;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use App\Core\Setting;
use Cake\Core\App;
use Cake\Validation\Validator;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;

//require_once(ROOT.DS.'vendor'.DS.'Spreadsheet'.DS.'PHPExcel.php');

class ProductsController extends AppController {

    var $styleArray = array('font' => array('bold' => true));
    var $styleThinBlackBorderOutline = array(
        'borders' => array(
            //'outline' => array(
            'allborders' => array(
                'style' => 'thin',
                'color' => array('argb' => 'FF000000'),
            ),
        ),
    );
    var $styleBorderNone = array(
        'borders' => array(
            //'outline' => array(
            'allborders' => array(
                'style' => 'none'
            ),
        ),
    );

    public function initialize() {
        parent::initialize();
        $this->loadModel('Categories');
    }

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow('index');
    }

    public function index() {
        $this->viewBuilder()->layout('admin');
        $products_reg = TableRegistry::get('product_details');
        $query = $products_reg->find("all")->where(['created_by' => $this->Auth->user('user_id')]);
        $products = $this->getResultArray('Products',$query);
        if(!empty($products)){
            foreach($products as $key=>$products1){
                $mapped_cat_ids = $products1['Products']['mapped_category_ids'];
                $categories = str_replace('#', '', $products1['Products']['mapped_category_ids']);
                $categories = explode(',', $categories);
                $cat_arr = array();
                foreach($categories as $category){
                    $categories_reg = TableRegistry::get('Categories');
                    $query = $categories_reg->find('all')->where(['category_id' => $category]);
                    $categories = $this->getResultArray('Categories',$query);
                    $cat_arr[] = $categories['Categories']['category_name'];
                }
                $products[$key]['Products']['mapped_categories_name'] = implode(",", $cat_arr);
            }
        }
//        debug($products);die;
        $this->set("products",$products);
    }

    function getFeatures() {
        $this->viewBuilder()->layout('blank');
        $attribute_id = $this->request->data('attribute_id');
        if ($attribute_id != '') {
            if ($attribute_id == 0) {
                $this->set("disabed_features", '');
            } else {
                $feature_reg = TableRegistry::get('feature_masters');
                $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
                $features = $this->getResultArray('Feature', $query);
                $feature_array = array("0" => "Select Feature");
                if (!empty($features)) {
                    foreach ($features as $feature1) {
                        $feature_array[$feature1['Feature']['feature_id']] = $feature1['Feature']['feature_name'];
                    }
                }
                $this->set("features", $feature_array);
            }
        }
    }

    function getCategoryTree() {
        $categories_reg = TableRegistry::get('categories');
        $query = $categories_reg->find('threaded', [
                    'keyField' => $categories_reg->primaryKey(),
                    'parentField' => 'parent_category_id'
                ])->where(['categories.status' => 'Active']);
        $categories = $this->getResultArray('Category', $query);
//        debug($categories);die;
        $this->set("categories", $categories);
    }

    
    
    function addProduct() {
        $this->viewBuilder()->layout('admin');
        $attribute_reg = TableRegistry::get('attribute_masters');
        $query = $attribute_reg->find('all');
        $attributes = $this->getResultArray('Attribute', $query);
        $atttr_array = array("0" => "Select Attribute");
        if (!empty($attributes)) {
            foreach ($attributes as $attribute1) {
                $atttr_array[$attribute1['Attribute']['attribute_id']] = $attribute1['Attribute']['attribute_name'];
            }
        }
        $this->set("attributes", $atttr_array);
        $categories_reg = TableRegistry::get('categories');
        $query = $categories_reg->find('threaded', [
                    'keyField' => $categories_reg->primaryKey(),
                    'parentField' => 'parent_category_id'
                ])->where(['categories.status' => 'Active','categories.created_by' => $this->Auth->user('user_id')]);
        $categories = $this->getResultArray('Category', $query);
//        debug($categories);die;
        $this->set("categories", $categories);

        $brands_reg = TableRegistry::get('brands');
        $query = $brands_reg->find('all')->where(['status' => 'Active']);
        $brands = $this->getResultArray('Brand', $query);
        $brand_arr = array("0" => "Select Brand");
        if (!empty($brands)) {
            foreach ($brands as $brands1) {
                $brand_arr[$brands1['Brand']['brand_id']] = $brands1['Brand']['brand_name'];
            }
        }

        $this->set("brands", $brand_arr);

//        $this->viewBuilder()->layout('admin');
        $article = $this->Products->newEntity();

        if (!empty($this->request->data)) {
            $article = $this->Products->patchEntity($article, $this->request->data);

            $this->set('_serialize', ['Product']);
            $article->user_id = $this->Auth->user('user_id');
            if (isset($this->request->data['product_name']) && trim($this->request->data['product_name']) != '') {
                
                $product_name = @trim($this->request->data['product_name']);
                
                $products_reg = TableRegistry::get('Products');
                $query = $products_reg->find('all')->where(['product_name' => $product_name]);
                $product_detail = $this->getResultArray('Products', $query);
                if(empty($product_detail)){
//                debug($this->request->data);die;
                    $main_category_id = '';
                    
                    $description = $this->request->data['product_desc'];
                    $quantity = $this->request->data['quantity'];
                    $price_without_tax = $this->request->data['price_without_tax'];
                    $cgst = $this->request->data['cgst'];
                    $sgst = $this->request->data['sgst'];
                    $igst = $this->request->data['igst'];
                    $misc_charge = $this->request->data['misc_charges'];
                    //$status = 'Active';
                    
                    $created_by = $this->Auth->user('user_id');
                    $modified_by = $this->Auth->user('user_id');
                    $status = 'Active';
                    $created_date = date('Y-m-d H:m:s');
                    $modified_date = date('Y-m-d H:m:s');

                    $mapped_cat_ids = $this->request->data['selected_cat_ids'];
                    $mapped_cat_id_array = explode(",", $mapped_cat_ids);

                    $mapped_category_ids = array();
                    foreach ($mapped_cat_id_array as $mapped_cat_id_array1) {
                        $mapped_category_ids[] = '#' . $mapped_cat_id_array1 . '#';
                    }
                    $categoery_ids_mapped_final = implode(',', $mapped_category_ids);
                    $product_exists = array();
                    if(empty($product_exists)) {
                        $products_reg = TableRegistry::get('product_details');
                        $query = $products_reg->query();
                        $insert = $query->insert(['product_name', 'description', 'quantity', 'price_without_tax', 'cgst', 'sgst', 'igst','misc_charges','mapped_category_ids' ,'status', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                ->values([
                                    'product_name' => $product_name,
                                    'description' => $description,
                                    'quantity' => $quantity,
                                    'price_without_tax' => $price_without_tax,
                                    'cgst' => $cgst,
                                    'sgst' => $sgst,
                                    'igst' => $igst,
                                    'misc_charges' => $misc_charge,
                                    'mapped_category_ids' => $categoery_ids_mapped_final,
                                    'status' => $status,
                                    'created_by' => $created_by,
                                    'created_date' => $created_date,
                                    'modified_by' => $modified_by,
                                    'modified_date' => $modified_date
                                ])
                                ->execute();
                        if ($insert) {
                            $this->Flash->success(__('Product added successfully'));
                            $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                        }
                    }
                } else {
                    $this->Flash->error(__($this->Error->getError("Same Product name already exists,Please fill another product name.")));
                    $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                }
            } else {
                $this->Flash->error(__($this->Error->getError("Please fill product name.")));
                $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
            }
        }




//            if(trim($this->request->data['brand_name']) == ''){
//                $this->Flash->error(__('Category name can not be blank'));
//                $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
//            } else {
//                $brand_name = trim($this->request->data['brand_name']);
//                $created_by = '1';
//                $modified_by = '1';
//                $status = 'Active';
//                $created_date = date('Y-m-d H:m:s');
//                $modified_date = date('Y-m-d H:m:s');
//                $brands_reg = TableRegistry::get('brands');
//                $query = $brands_reg->find('all')->where(['brand_name' => $brand_name]);
//                $brand_exists = $this->getResultArray('Brand',$query);
//                if(empty($brand_exists)){
//                    $query = $brands_reg->query();
//                    $insert = $query->insert(['brand_name','status','created_by','created_date','modified_by','modified_date'])
//                        ->values([
//                            'brand_name' => $brand_name,
//                            'status' => $status,
//                            'created_by' => $created_by,
//                            'created_date' => $created_date,
//                            'modified_by' => $modified_by,
//                            'modified_date' => $modified_date
//                        ])
//                        ->execute();
//                    if($insert){
//                        $this->Flash->success(__('Brand added successfully'));
//                        $this->redirect(array('controller'=>'Brand','action' => 'index'));
//                    }
//                } else {
//                    $this->Flash->error(__('This brand name already exists'));
//                    $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
//                }
//            }
//        }
    }
    
    
    function addProductOld() {
        $this->viewBuilder()->layout('admin');
        $attribute_reg = TableRegistry::get('attribute_masters');
        $query = $attribute_reg->find('all');
        $attributes = $this->getResultArray('Attribute', $query);
        $atttr_array = array("0" => "Select Attribute");
        if (!empty($attributes)) {
            foreach ($attributes as $attribute1) {
                $atttr_array[$attribute1['Attribute']['attribute_id']] = $attribute1['Attribute']['attribute_name'];
            }
        }
        $this->set("attributes", $atttr_array);
        $categories_reg = TableRegistry::get('categories');
        $query = $categories_reg->find('threaded', [
                    'keyField' => $categories_reg->primaryKey(),
                    'parentField' => 'parent_category_id'
                ])->where(['categories.status' => 'Active']);
        $categories = $this->getResultArray('Category', $query);
//        debug($categories);die;
        $this->set("categories", $categories);

        $brands_reg = TableRegistry::get('brands');
        $query = $brands_reg->find('all')->where(['status' => 'Active']);
        $brands = $this->getResultArray('Brand', $query);
        $brand_arr = array("0" => "Select Brand");
        if (!empty($brands)) {
            foreach ($brands as $brands1) {
                $brand_arr[$brands1['Brand']['brand_id']] = $brands1['Brand']['brand_name'];
            }
        }

        $this->set("brands", $brand_arr);

//        $this->viewBuilder()->layout('admin');
        $article = $this->Products->newEntity();

        if (!empty($this->request->data)) {
            $article = $this->Products->patchEntity($article, $this->request->data);

            $this->set('_serialize', ['Product']);
            $article->user_id = $this->Auth->user('user_id');
            if (isset($this->request->data['product_name']) && trim($this->request->data['product_name']) != '') {
                
                $product_name = @trim($this->request->data['product_name']);
                
                $products_reg = TableRegistry::get('Products');
                $query = $products_reg->find('all')->where(['product_name' => $product_name]);
                $product_detail = $this->getResultArray('Products', $query);
                if(empty($product_detail)){
                
                    $brand_id = $this->request->data['brand_value'];
                    $main_category_id = '';
                    $meta_tag_title = $this->request->data['meta_tag_title'];
                    $product_desc = $this->request->data['product_desc'];
                    $meta_tag_desc = $this->request->data['meta_tag_desc'];
                    $meta_tag_keyword = $this->request->data['meta_tag_keyword'];
                    $product_tags = $this->request->data['product_tags'];
                    $condition = 'New';

                    $created_by = $this->Auth->user('user_id');
                    $modified_by = $this->Auth->user('user_id');
                    $status = 'Active';
                    $created_date = date('Y-m-d H:m:s');
                    $modified_date = date('Y-m-d H:m:s');



                    $mapped_cat_ids = $this->request->data['selected_cat_ids'];
                    $mapped_cat_id_array = explode(",", $mapped_cat_ids);

                    $mapped_category_ids = array();
                    foreach ($mapped_cat_id_array as $mapped_cat_id_array1) {
                        $mapped_category_ids[] = '#' . $mapped_cat_id_array1 . '#';
                    }
                    $categoery_ids_mapped_final = implode(',', $mapped_category_ids);


                    $product_exists = array();
                    if (empty($product_exists)) {



                        $products_reg = TableRegistry::get('products');
                        $query = $products_reg->query();
                        $insert = $query->insert(['product_name', 'brand_id', 'mapped_category_id', 'main_category_id', 'meta_tag_title', 'product_description', 'meta_tag_description', 'meta_tag_keyword', 'product_tags', 'jan_barcode', 'upc_barcode', 'status', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                ->values([
                                    'product_name' => $product_name,
                                    'brand_id' => $brand_id,
                                    'mapped_category_id' => $categoery_ids_mapped_final,
                                    'main_category_id' => $main_category_id,
                                    'meta_tag_title' => $meta_tag_title,
                                    'product_description' => $product_desc,
                                    'meta_tag_description' => $meta_tag_desc,
                                    'meta_tag_keyword' => $meta_tag_keyword,
                                    'product_tags' => $product_tags,
                                    'jan_barcode' => '',
                                    'upc_barcode' => '',
                                    'status' => $status,
                                    'created_by' => $created_by,
                                    'created_date' => $created_date,
                                    'modified_by' => $modified_by,
                                    'modified_date' => $modified_date
                                ])
                                ->execute();
                        if ($insert) {
                            $product_id = $insert->lastInsertId('products');

                            $available_quantity = $this->request->data['quantity'];
                            $minimum_qyuntity_for_sale = $this->request->data['minimum_quantity_for_sale'];
                            $behaviour_out_stock = $this->request->data['behaviour_when_out_of_stock'];
                            $label_in_stock = $this->request->data['label_when_in_stock'];
                            $label_out_stock = $this->request->data['label_when_out_of_stock'];
                            //$availability_date = $this->request->data['availability_date'];
                            $availability_date = date('Y-m-d H:i:s', strtotime($this->request->data['availability_date']));
                            $created_by = $this->Auth->user('user_id');
                            $modified_by = $this->Auth->user('user_id');
                            $created_date = date('Y-m-d H:m:s');
                            $modified_date = date('Y-m-d H:m:s');


                            $product_quantity_mapping_reg = TableRegistry::get('product_quantity_mappings');
                            $query = $product_quantity_mapping_reg->query();
                            $insert_product_quantity_mapping = $query->insert(['product_id', 'available_quantity', 'minimum_qyuntity_for_sale', 'label_in_stock', 'label_out_stock', 'availability_date', 'behaviour_out_stock', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                    ->values([
                                        'product_id' => $product_id,
                                        'available_quantity' => $available_quantity,
                                        'minimum_qyuntity_for_sale' => $minimum_qyuntity_for_sale,
                                        'label_in_stock' => $label_in_stock,
                                        'label_out_stock' => $label_out_stock,
                                        'availability_date' => $availability_date,
                                        'behaviour_out_stock' => $behaviour_out_stock,
                                        'created_by' => $created_by,
                                        'created_date' => $created_date,
                                        'modified_by' => $modified_by,
                                        'modified_date' => $modified_date
                                    ])
                                    ->execute();
                            if ($insert_product_quantity_mapping) {
                                $price_per_unit = $this->request->data['price_without_tax'];
                                $tax = '';
                                $total_price = $this->request->data['price_with_tax'];
                                $discount = '';
                                $discount_percent = '';
                                $old_total_price = '';
                                $new_total_price = $this->request->data['price_with_tax'];

                                $created_by = $this->Auth->user('user_id');
                                $modified_by = $this->Auth->user('user_id');
                                $created_date = date('Y-m-d H:m:s');
                                $modified_date = date('Y-m-d H:m:s');

                                $product_price_mapping_reg = TableRegistry::get('product_price_mappings');
                                $query = $product_price_mapping_reg->query();
                                $insert_product_price_mapping = $query->insert(['product_id', 'price_per_unit', 'tax', 'total_price', 'discount', 'discount_percent', 'old_total_price', 'new_total_price', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                        ->values([
                                            'product_id' => $product_id,
                                            'price_per_unit' => $available_quantity,
                                            'tax' => $minimum_qyuntity_for_sale,
                                            'total_price' => $label_in_stock,
                                            'discount' => $label_out_stock,
                                            'discount_percent' => $availability_date,
                                            'old_total_price' => $behaviour_out_stock,
                                            'new_total_price' => $behaviour_out_stock,
                                            'created_by' => $created_by,
                                            'created_date' => $created_date,
                                            'modified_by' => $modified_by,
                                            'modified_date' => $modified_date
                                        ])
                                        ->execute();
                                if ($insert_product_price_mapping) {
                                    $attribute_array = $this->request->data['attribute_type'];
                                    $feature_array = $this->request->data['feature_value'];

                                    if (!empty($attribute_array)) {
                                        if (count($attribute_array) == count($feature_array)) {
                                            foreach ($attribute_array as $key => $attr_arr) {
                                                $attribute_id = $attr_arr;
                                                $feature_id = $feature_array[$key];

                                                $created_by = $this->Auth->user('user_id');
                                                $modified_by = $this->Auth->user('user_id');
                                                $created_date = date('Y-m-d H:m:s');
                                                $modified_date = date('Y-m-d H:m:s');

                                                $product_attribute_feature_mappings_reg = TableRegistry::get('product_attribute_feature_mappings');
                                                $query = $product_attribute_feature_mappings_reg->query();
                                                $insert_product_attribute_feature_mapping = $query->insert(['product_id', 'attribute_id', 'feature_id', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                                        ->values([
                                                            'product_id' => $product_id,
                                                            'attribute_id' => $attribute_id,
                                                            'feature_id' => $feature_id,
                                                            'created_by' => $created_by,
                                                            'created_date' => $created_date,
                                                            'modified_by' => $modified_by,
                                                            'modified_date' => $modified_date
                                                        ])
                                                        ->execute();
                                            }
                                        }
                                    }
                                    $this->Flash->success(__('Attribute added successfully'));
                                    $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                                }
                            }
                        }
                    }
                } else {
                    $this->Flash->error(__($this->Error->getError("Same Product name already exists,Please fill another product name.")));
                    $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                }
            } else {
                $this->Flash->error(__($this->Error->getError("Please fill product name.")));
                $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
            }
        }




//            if(trim($this->request->data['brand_name']) == ''){
//                $this->Flash->error(__('Category name can not be blank'));
//                $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
//            } else {
//                $brand_name = trim($this->request->data['brand_name']);
//                $created_by = '1';
//                $modified_by = '1';
//                $status = 'Active';
//                $created_date = date('Y-m-d H:m:s');
//                $modified_date = date('Y-m-d H:m:s');
//                $brands_reg = TableRegistry::get('brands');
//                $query = $brands_reg->find('all')->where(['brand_name' => $brand_name]);
//                $brand_exists = $this->getResultArray('Brand',$query);
//                if(empty($brand_exists)){
//                    $query = $brands_reg->query();
//                    $insert = $query->insert(['brand_name','status','created_by','created_date','modified_by','modified_date'])
//                        ->values([
//                            'brand_name' => $brand_name,
//                            'status' => $status,
//                            'created_by' => $created_by,
//                            'created_date' => $created_date,
//                            'modified_by' => $modified_by,
//                            'modified_date' => $modified_date
//                        ])
//                        ->execute();
//                    if($insert){
//                        $this->Flash->success(__('Brand added successfully'));
//                        $this->redirect(array('controller'=>'Brand','action' => 'index'));
//                    }
//                } else {
//                    $this->Flash->error(__('This brand name already exists'));
//                    $this->redirect(array('controller'=>'Brand','action' => 'addBrand'));
//                }
//            }
//        }
    }

    function sampleProdcutExport($exportBidding = null) {
        require_once(ROOT . DS . 'vendor' . DS . 'Spreadsheet' . DS . 'Sheet.php');
        require_once(ROOT . DS . 'vendor' . DS . 'Spreadsheet' . DS . 'PHPExcel' . DS . 'Writer' . DS . 'Excel2007.php');
        require_once(ROOT . DS . 'vendor' . DS . 'Spreadsheet' . DS . 'PHPExcel' . DS . 'IOFactory.php');

        $objPHPExcel = new \PHPExcel();
        $objPHPExcel->getProperties()->setCreator("creator name");

        $i = 1;
        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->getActiveSheet()->setTitle('Add Product Sample');
        $objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth('28pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('15pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth('25pt');
        $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth('25pt');


        $objPHPExcel->getActiveSheet()->setCellValue('A1', 'S.No.');
        $objPHPExcel->getActiveSheet()->mergeCells('A1:A2');
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getFill()->getStartColor()->setARGB('FFEBF9E2');

        $objPHPExcel->getActiveSheet()->setCellValue('B1', 'Basic Settings');
        $objPHPExcel->getActiveSheet()->mergeCells('B1:G1');
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('B1:G1')->getFill()->getStartColor()->setARGB('FFD2B48C');

        $objPHPExcel->getActiveSheet()->setCellValue('H1', 'Quantity Details');
        $objPHPExcel->getActiveSheet()->mergeCells('H1:M1');
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getFill()->getStartColor()->setARGB('FFFFE4E1');

        $objPHPExcel->getActiveSheet()->setCellValue('N1', 'Shipping Details');
        $objPHPExcel->getActiveSheet()->mergeCells('N1:R1');
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('N1:R1')->getFill()->getStartColor()->setARGB('FFD2B48C');

        $objPHPExcel->getActiveSheet()->setCellValue('S1', 'Price Details');
        $objPHPExcel->getActiveSheet()->mergeCells('S1:T1');
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('S1:T1')->getFill()->getStartColor()->setARGB('FFFFE4E1');

        $objPHPExcel->getActiveSheet()->setCellValue('U1', 'Additional Details');
        $objPHPExcel->getActiveSheet()->mergeCells('U1:W1');
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->applyFromArray($this->styleThinBlackBorderOutline);
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
        $objPHPExcel->getActiveSheet()->getStyle('U1:W1')->getFill()->getStartColor()->setARGB('FFD2B48C');



        $details_array = array('Product Name', 'Description', 'Meta Tag Title', 'Meta Tag Description', 'Meta Tag Keywords', 'Product Tags', 'Quantity', 'Minimum Quantity For Sale', 'Behaviour When Out of Stock (Deny orders/Allow orders/Default)', 'Label When In Stock', 'Label When Out Of Stock', 'Availibility Date (dd/mm/yyyy)', 'Width', 'Height', 'Depth', 'Weight', 'Shipping Fees', 'Price With Tax', 'Price Without Tax', 'Attributes', 'Brand', 'Categories');
        $cell = 1;
        $p = 0;
        $row = 2;
        foreach ($details_array as $key => $detail) {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($cell + $p, $row, $detail);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->applyFromArray($this->styleThinBlackBorderOutline);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getFill()->getStartColor()->setARGB('#7CFC00');
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getAlignment()->setWrapText(true);
            $p++;
        }
        $format = 'dd/mm/yyyy';
        $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow('M2')->getNumberFormat()->setFormatCode($format);



        $details_array1 = array('1', "Dermawear Men's Shapewear", "It takes the shape of the body and gives a firm compression on the abdomen and the waist, reducing the overall measurement quickly yet effectively.", 'Meta Tag Title', 'Meta Tag Description', 'Meta Tag Keywords', 'Product Tags', '25', '22', 'Deny orders', 'In stock', 'Out Of Stock', '14/05/2017', '3.2', '7.6', '1', '3', '0', '673', '658', 'RAM:3GB,SIZE:12,ONIDA:32 inch', 'Nokia', 'Sportswear>Nike,Womens>Guess>Guess');
        $cell = 0;
        $p = 0;
        $row = 3;
        foreach ($details_array1 as $cell => $detail) {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($cell + $p, $row, $detail);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->applyFromArray($this->styleThinBlackBorderOutline);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getAlignment()->setWrapText(true);
            $p++;
        }

        $details_array2 = array('2', "Samsung S6 edge", "Better mobile,u just use, and it will explode in ur hand,Don't worry.", 'Meta Tag Title', 'Meta Tag Description', 'Meta Tag Keywords', 'Product Tags', '25', '22', 'Deny orders', 'In stock', 'Out Of Stock', '14/05/2017', '3.2', '7.6', '1', '3', '0', '673', '658', 'RAM:3GB,SIZE:12,ONIDA:32 inch', 'Nokia', 'Sportswear>Nike,Womens>Guess>Guess');
        $cell = 0;
        $p = 0;
        $row = 4;
        foreach ($details_array2 as $key => $detail) {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($cell + $p, $row, $detail);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->applyFromArray($this->styleThinBlackBorderOutline);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID);
            $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($cell + $p, $row)->getAlignment()->setWrapText(true);
            $p++;
        }


        $objPHPExcel->setActiveSheetIndex(0);

        $filename = 'Add_Product_Sample_File';
        // Redirect output to a client�s web browser (Excel5)
        $now = time();
        if ($exportBidding == true) {
            //$filename = $rfx_web_id . "_CostComparison.xls";

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
            $objWriter->save(Configure::read('Document_Path') . "quotation_export/" . $filename);
            //die(); 
        } else {
            //$filename = $rfx_web_id . "_CostComparison_" . $now . ".xls";
            //parent::AuditTrailLog($this->Auth->user('user_id'), Configure::read('DownloadAttachment') . ": " . $filename, $this->Auth->user("user_id"), $rfxdetails['Rfx']['rfx_id']);

            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename=' . $filename);
            header('Cache-Control: max-age=0');
            ob_clean();
            flush();

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
            $objWriter->save('php://output');
            die();
        }
    }

    public function importProduct() {
        $this->viewBuilder()->layout('blank');

        if (!empty($this->request->data)) {
//            debug($this->request->data);die;
            $namePart = explode(".", $this->request->data['file']['name']);
            $ext = $namePart[count($namePart) - 1];
            if ($this->request->data['file']['name'] == '' || strtolower($ext) != 'xls') {
                $this->Flash->error(__('Please upload XLS extension file only'));
                $this->redirect($this->referer());
            } else {
                $destination = WWW_ROOT . "masters\\" . $this->request->data['file']['name'];
                if (move_uploaded_file($this->request->data['file']['tmp_name'], $destination)) {
                    $file_path = WWW_ROOT . "masters\\" . $this->request->data['file']['name'];

                    require_once(ROOT . DS . 'vendor' . DS . 'excel_reader.php');
                    $ExcelReader = new \Spreadsheet_Excel_Reader($file_path, true);
                    //debug($ExcelReader->isReadAble);die;
                    if ($ExcelReader->isReadAble($file_path)) {
                        
                    } else {
                        $this->Flash->error(__('Sorry!File is not readable'));
                        $this->redirect($this->referer());
                    }
                    if (is_object($ExcelReader)) {
                        $arr = array();
                        $sheet_index = 0;
                        for ($row = 2; $row <= $ExcelReader->rowcount($sheet_index); $row++) {
                            for ($col = 1; $col <= $ExcelReader->colcount($sheet_index); $col++) {
                                $arr[$row][$col] = $ExcelReader->val($row, $col, $sheet_index);
                            }
                        }

                        $i = 2;
                        $error = 'Sorry!!Import failed due to following reasons:-</br/>';
                        if (count($arr) == 0) {
                            $this->Flash->error(__('Sorry!No items found in the XLS sheet'));
                            $this->redirect($this->referer());
                        } else {
                            $code_array = array();
                            $errordata = false;
                            $components = $arr[2];
                            $product_name = @trim($components[2]);
                            $description = @trim($components[3]);
                            $meta_tag_title = @trim($components[4]);
                            $meta_tag_desc = @trim($components[5]);
                            $meta_tag_keywords = @trim($components[6]);
                            $product_tags = @trim($components[7]);
                            $quantity = @trim($components[8]);
                            $min_quantity_for_sale = @trim($components[9]);
                            $behaviour_when_out_of_stock = @trim($components[10]);
                            $label_when_in_stock = @trim($components[11]);
                            $label_when_out_stock = @trim($components[12]);
                            $Availablity_date = @trim($components[13]);
                            $width = @trim($components[14]);
                            $height = @trim($components[15]);
                            $depth = @trim($components[16]);
                            $weight = @trim($components[17]);
                            $shipping_fees = @trim($components[18]);
                            $price_with_tax = @trim($components[19]);
                            $price_without_tax = @trim($components[20]);
                            $attributes = @trim($components[21]);
                            $brand = @trim($components[22]);
                            $categories = @trim($components[23]);
                            if ($product_name == '' || $product_name != 'Product Name') {
                                $error .= "Not in correct format: Error in Product Name heading";
                                $errordata = true;
                            } else if ($description == '' || $description != 'Description') {
                                $error .= "Not in correct format: Error in Description heading";
                                $errordata = true;
                            } else if ($meta_tag_title != 'Meta Tag Title') {
                                $error .= "Not in correct format: Error in Meta Tag Title heading";
                                $errordata = true;
                            } else if ($meta_tag_desc != 'Meta Tag Description') {
                                $error .= "Not in correct format: Error in Meta Tag Description heading";
                                $errordata = true;
                            } else if ($meta_tag_keywords != 'Meta Tag Keywords') {
                                $error .= "Not in correct format: Error in Meta Tag Keywords heading";
                                $errordata = true;
                            } else if ($product_tags != 'Product Tags') {
                                $error .= "Not in correct format: Error in Product Tags heading";
                                $errordata = true;
                            } else if ($quantity != 'Quantity') {
                                $error .= "Not in correct format: Error in Quantity heading";
                                $errordata = true;
                            } else if ($min_quantity_for_sale != 'Minimum Quantity For Sale') {
                                $error .= "Not in correct format: Error in Minimum Quantity For Sale heading";
                                $errordata = true;
                            } else if ($behaviour_when_out_of_stock != 'Behaviour When Out of Stock (Deny orders/Allow orders/Default)') {
                                $error .= "Not in correct format: Error in Behaviour When Out of Stock heading";
                                $errordata = true;
                            } else if ($label_when_in_stock != 'Label When In Stock') {
                                $error .= "Not in correct format: Error in Label When In Stock heading";
                                $errordata = true;
                            } else if ($label_when_out_stock != 'Label When Out Of Stock') {
                                $error .= "Not in correct format: Error in Label When Out Of Stock heading";
                                $errordata = true;
                            } else if ($Availablity_date != 'Availibility Date (dd/mm/yyyy)') {
                                $error .= "Not in correct format: Error in Availibility Date heading";
                                $errordata = true;
                            } else if ($width != 'Width') {
                                $error .= "Not in correct format: Error in Width heading";
                                $errordata = true;
                            } else if ($height != 'Height') {
                                $error .= "Not in correct format: Error in Height heading";
                                $errordata = true;
                            } else if ($depth != 'Depth') {
                                $error .= "Not in correct format: Error in Depth heading";
                                $errordata = true;
                            } else if ($weight != 'Weight') {
                                $error .= "Not in correct format: Error in Weight heading";
                                $errordata = true;
                            } else if ($shipping_fees != 'Shipping Fees') {
                                $error .= "Not in correct format: Error in Shipping Fees heading";
                                $errordata = true;
                            } else if ($price_with_tax != 'Price With Tax') {
                                $error .= "Not in correct format: Error in Price With Tax heading";
                                $errordata = true;
                            } else if ($price_without_tax != 'Price Without Tax') {
                                $error .= "Not in correct format: Error in Price Without Tax heading";
                                $errordata = true;
                            } else if ($attributes != 'Attributes') {
                                $error .= "Not in correct format: Error in Attributes heading";
                                $errordata = true;
                            } else if ($brand != 'Brand') {
                                $error .= "Not in correct format: Error in Brand heading";
                                $errordata = true;
                            } else if ($categories != 'Categories') {
                                $error .= "Not in correct format: Error in Categories heading";
                                $errordata = true;
                            }
                            if ($errordata == true) {
                                $this->Flash->error(__($error));
                                return $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                            }
                            $errordata1 = false;
                            $product_array = $arr;
                            unset($product_array[2]);
                            $i = 1;
                            $cat_main_product = array();
                            foreach ($product_array as $key => $product_array1) {
                                if (strlen(implode($product_array1)) != 0) {
                                    $product_name = @trim($product_array1[2]);
                                    $description = @trim($product_array1[3]);
                                    $meta_tag_title = @trim($product_array1[4]);
                                    $quantity = @trim($product_array1[8]);
                                    $price_with_tax = @trim($product_array1[19]);
                                    $price_without_tax = @trim($product_array1[20]);
                                    $attributes = @trim($product_array1[21]);
                                    $brand = @trim($product_array1[22]);
                                    $categories = @trim($product_array1[23]);

                                    if ($product_name == '') {
                                        $error .= "Product Name can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($description == '') {
                                        $error .= "Product Description can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($meta_tag_title == '') {
                                        $error .= "Product Meta Tag title can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($quantity == '') {
                                        $error .= "Product Quantity can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if (!is_numeric($quantity)) {
                                        $error .= "Product Quantity should be numeric for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($price_with_tax == '') {
                                        $error .= "Product price with tax can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($price_without_tax == '') {
                                        $error .= "Product price without tax can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($attributes == '') {
                                        $error .= "Product attributes can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($brand == '') {
                                        $error .= "Product Brand can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    if ($categories == '') {
                                        $error .= "Product categories can not be blank for S.No. " . $i . "<br/>";
                                        $errordata1 = true;
                                    }
                                    $main_attribute_array = array();
                                    $att_array = explode(",", $attributes);
                                    if (!empty($att_array)) {
                                        foreach ($att_array as $att_array1) {
                                            $attribute_array_descriptive = explode(":", $att_array1);
                                            $main_attribute_array[$attribute_array_descriptive[0]] = $attribute_array_descriptive[1];
                                        }
                                    }
                                    foreach ($main_attribute_array as $key => $main_attribute_array1) {
                                        //$attributes = TableRegistry::get('Products');
                                        $attribute_reg = TableRegistry::get('attribute_masters');
                                        $query = $attribute_reg->find('all')->where(['attribute_name' => $key]);
                                        $attribute_detail = $this->getResultArray('Attribute', $query);
                                        if (!empty($attribute_detail)) {
                                            $attribute_id = $attribute_detail['Attribute']['attribute_id'];

                                            $feature_reg = TableRegistry::get('feature_masters');
                                            $query = $feature_reg->find('all')->where(['feature_name' => $main_attribute_array1, 'attribute_id' => $attribute_id]);
                                            $feature = $this->getResultArray('Feature', $query);
                                            if (empty($feature)) {
                                                $error .= "Product feature does not exists for S.No. " . $i . "<br/>";
                                                $errordata1 = true;
                                                break;
                                            }
                                        } else {
                                            $error .= "Product attribute does not exists for S.No. " . $i . "<br/>";
                                            $errordata1 = true;
                                            break;
                                        }
                                    }
                                    $categories_array = explode(",", $categories);
                                    $cat1_id = '';
                                    if (!empty($categories_array)) {
                                        foreach ($categories_array as $key => $categories_array1) {
                                            $desriptive_cat_arr = explode(">", $categories_array1);

                                            foreach ($desriptive_cat_arr as $key => $desriptive_cat_arr1) {
                                                $categories_reg = TableRegistry::get('Categories');
                                                if ($key == 0) {
                                                    $query = $categories_reg->find('all')->where(['category_name' => $desriptive_cat_arr1]);
                                                } else {
                                                    if ($cat1_id != '') {
                                                        $query = $categories_reg->find('all')->where(['category_name' => $desriptive_cat_arr1, 'parent_category_id' => $cat1_id]);
                                                    }
                                                }
                                                $cat1 = $this->getResultArray('Categories', $query);
                                                if (!empty($cat1)) {
                                                    if (isset($cat1['Categories']['category_id'])) {
                                                        $cat1_id = $cat1['Categories']['category_id'];
                                                        $cat_main_product[$i][$categories_array1] = $cat1['Categories']['category_id'];
                                                    } else {
                                                        $error .= "May be two or more categories with same name exists in our DB, Please check it again for S.No. " . $i . "<br/>";
                                                        $errordata1 = true;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    $i++;
                                }
                            }
                            if ($errordata1 == true) {
                                $this->Flash->error(__($error));
                                return $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                            } else {
                                $j = 1;
                                $errordata2 = false;
                                foreach ($product_array as $key => $product_array1) {
                                    if (strlen(implode($product_array1)) != 0) {
                                        $sn = @trim($product_array1[1]);
                                        $product_name = @trim($product_array1[2]);
                                        $description = @trim($product_array1[3]);
                                        $meta_tag_title = @trim($product_array1[4]);
                                        $meta_tag_desc = @trim($product_array1[5]);
                                        $meta_tag_keywords = @trim($product_array1[6]);
                                        $product_tags = @trim($product_array1[7]);
                                        $quantity = @trim($product_array1[8]);
                                        $min_quantity_for_sale = @trim($product_array1[9]);
                                        $behaviour_when_out_of_stock = @trim($product_array1[10]);
                                        $label_when_in_stock = @trim($product_array1[11]);
                                        $label_when_out_stock = @trim($product_array1[12]);
                                        $Availablity_date = @trim($product_array1[13]);
                                        $width = @trim($product_array1[14]);
                                        $height = @trim($product_array1[15]);
                                        $depth = @trim($product_array1[16]);
                                        $weight = @trim($product_array1[17]);
                                        $shipping_fees = @trim($product_array1[18]);
                                        $price_with_tax = @trim($product_array1[19]);
                                        $price_without_tax = @trim($product_array1[20]);
                                        $attributes = @trim($product_array1[21]);
                                        $brand = @trim($product_array1[22]);
                                        $categories = @trim($product_array1[23]);
                                        $categories_array = explode(",", $categories);
                                        $cat1_id = '';
                                        $cat_main_product = array();
                                        if (!empty($categories_array)) {
                                            foreach ($categories_array as $key => $categories_array1) {
                                                $desriptive_cat_arr = explode(">", $categories_array1);
                                                foreach ($desriptive_cat_arr as $key => $desriptive_cat_arr1) {
                                                    $categories_reg = TableRegistry::get('Categories');
                                                    if ($key == 0) {
                                                        $query = $categories_reg->find('all')->where(['category_name' => $desriptive_cat_arr1]);
                                                    } else {
                                                        if ($cat1_id != '') {
                                                            $query = $categories_reg->find('all')->where(['category_name' => $desriptive_cat_arr1, 'parent_category_id' => $cat1_id]);
                                                        }
                                                    }
                                                    $cat1 = $this->getResultArray('Categories', $query);
                                                    if (!empty($cat1)) {
                                                        if (isset($cat1['Categories']['category_id'])) {
                                                            $cat1_id = $cat1['Categories']['category_id'];
                                                            $cat_main_product[$categories_array1] = $cat1['Categories']['category_id'];
                                                        } else {
                                                            $error .= "May be two or more categories with same name exists in our DB, Please check it again for S.No. " . $i . "<br/>";
                                                            $errordata1 = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        $mapped_cat_array = $cat_main_product;
                                        $mapped_category_ids = array();
                                        if (!empty($mapped_cat_array)) {
                                            foreach ($mapped_cat_array as $mapped_cat_array1) {
                                                $mapped_category_ids[] = '#' . $mapped_cat_array1 . '#';
                                            }
                                            $categoery_ids_mapped_final = implode(',', $mapped_category_ids);
                                        } else {
                                            $this->Flash->error(__('Sorry! categories does not exists, Plese check it again'));
                                            return $this->redirect($this->referer());
                                        }
                                        $main_category_id = '';
                                        $created_by = $this->Auth->user('user_id');
                                        $modified_by = $this->Auth->user('user_id');
                                        $status = 'Active';
                                        $created_date = date('Y-m-d H:m:s');
                                        $modified_date = date('Y-m-d H:m:s');

                                        $products_reg = TableRegistry::get('Products');
                                        $query = $products_reg->find('all')->where(['product_name' => $product_name]);
                                        $product_detail = $this->getResultArray('Products', $query);
                                        if(empty($product_detail)){
                                        
                                        //Insert Product added by Lokesh garg on 4-April-2017
                                        $products_reg = TableRegistry::get('products');
                                        $query = $products_reg->query();
                                        $insert = $query->insert(['product_name', 'brand_id', 'mapped_category_id', 'main_category_id', 'meta_tag_title', 'product_description', 'meta_tag_description', 'meta_tag_keyword', 'product_tags', 'jan_barcode', 'upc_barcode', 'status', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                                ->values([
                                                    'product_name' => $product_name,
                                                    'brand_id' => $brand,
                                                    'mapped_category_id' => $categoery_ids_mapped_final,
                                                    'main_category_id' => $main_category_id,
                                                    'meta_tag_title' => $meta_tag_title,
                                                    'product_description' => $description,
                                                    'meta_tag_description' => $meta_tag_desc,
                                                    'meta_tag_keyword' => $meta_tag_keywords,
                                                    'product_tags' => $product_tags,
                                                    'jan_barcode' => '',
                                                    'upc_barcode' => '',
                                                    'status' => $status,
                                                    'created_by' => $created_by,
                                                    'created_date' => $created_date,
                                                    'modified_by' => $modified_by,
                                                    'modified_date' => $modified_date
                                                ])
                                                ->execute();
                                        if ($insert) {
                                            $product_id = $insert->lastInsertId('products');

                                            $available_quantity = $quantity;
                                            $minimum_qyuntity_for_sale = $min_quantity_for_sale;
                                            $behaviour_out_stock = $behaviour_when_out_of_stock;
                                            $label_in_stock = $label_when_in_stock;
                                            $label_out_stock = $label_when_out_stock;
                                            //$availability_date = $this->request->data['availability_date'];
                                            $availability_date = date('Y-m-d H:i:s', strtotime($Availablity_date));
                                            $created_by = $this->Auth->user('user_id');
                                            $modified_by = $this->Auth->user('user_id');
                                            $created_date = date('Y-m-d H:m:s');
                                            $modified_date = date('Y-m-d H:m:s');
                                            $product_quantity_mapping_reg = TableRegistry::get('product_quantity_mappings');
                                            $query = $product_quantity_mapping_reg->query();
                                            $insert_product_quantity_mapping = $query->insert(['product_id', 'available_quantity', 'minimum_qyuntity_for_sale', 'label_in_stock', 'label_out_stock', 'availability_date', 'behaviour_out_stock', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                                    ->values([
                                                        'product_id' => $product_id,
                                                        'available_quantity' => $quantity,
                                                        'minimum_qyuntity_for_sale' => $min_quantity_for_sale,
                                                        'label_in_stock' => $label_when_in_stock,
                                                        'label_out_stock' => $label_when_out_stock,
                                                        'availability_date' => $availability_date,
                                                        'behaviour_out_stock' => $behaviour_when_out_of_stock,
                                                        'created_by' => $created_by,
                                                        'created_date' => $created_date,
                                                        'modified_by' => $modified_by,
                                                        'modified_date' => $modified_date
                                                    ])
                                                    ->execute();
                                            if ($insert_product_quantity_mapping) {
                                                $price_per_unit = $price_without_tax;
                                                $tax = '';
                                                $total_price = $price_with_tax;
                                                $discount = '';
                                                $discount_percent = '';
                                                $old_total_price = '';
                                                $new_total_price = $price_with_tax;

                                                $created_by = $this->Auth->user('user_id');
                                                $modified_by = $this->Auth->user('user_id');
                                                $created_date = date('Y-m-d H:m:s');
                                                $modified_date = date('Y-m-d H:m:s');

                                                $product_price_mapping_reg = TableRegistry::get('product_price_mappings');
                                                $query = $product_price_mapping_reg->query();
                                                $insert_product_price_mapping = $query->insert(['product_id', 'price_per_unit', 'tax', 'total_price', 'discount', 'discount_percent', 'old_total_price', 'new_total_price', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                                        ->values([
                                                            'product_id' => $product_id,
                                                            'price_per_unit' => $price_per_unit,
                                                            'tax' => $tax,
                                                            'total_price' => $total_price,
                                                            'discount' => $discount,
                                                            'discount_percent' => $discount_percent,
                                                            'old_total_price' => $old_total_price,
                                                            'new_total_price' => $new_total_price,
                                                            'created_by' => $created_by,
                                                            'created_date' => $created_date,
                                                            'modified_by' => $modified_by,
                                                            'modified_date' => $modified_date
                                                        ])
                                                        ->execute();
                                                if ($insert_product_price_mapping) {
                                                    $main_attribute_array = array();
                                                    $att_array = explode(",", $attributes);
                                                    if (!empty($att_array)) {
                                                        foreach ($att_array as $att_array1) {
                                                            $attribute_array_descriptive = explode(":", $att_array1);
                                                            $main_attribute_array[$attribute_array_descriptive[0]] = $attribute_array_descriptive[1];
                                                        }
                                                    }
                                                    if (!empty($main_attribute_array)) {
                                                        foreach ($main_attribute_array as $attr_value => $feature_value) {

                                                            $attribute_reg = TableRegistry::get('attribute_masters');
                                                            $query = $attribute_reg->find('all')->where(['attribute_name' => $attr_value]);
                                                            $attribute_detail = $this->getResultArray('Attribute', $query);

                                                            if (!empty($attribute_detail)) {
                                                                $attribute_id = $attribute_detail['Attribute']['attribute_id'];
                                                            } else {
                                                                $attribute_id = '';
                                                            }


                                                            $feature_reg = TableRegistry::get('feature_masters');
                                                            $query = $feature_reg->find('all')->where(['feature_name' => $feature_value, 'attribute_id' => $attribute_id]);
                                                            $feature = $this->getResultArray('Feature', $query);
                                                            if (!empty($feature)) {
                                                                $feature_id = $feature['Feature']['feature_id'];
                                                            } else {
                                                                $feature_id = '';
                                                            }

                                                            $created_by = $this->Auth->user('user_id');
                                                            $modified_by = $this->Auth->user('user_id');
                                                            $created_date = date('Y-m-d H:m:s');
                                                            $modified_date = date('Y-m-d H:m:s');

                                                            $product_attribute_feature_mappings_reg = TableRegistry::get('product_attribute_feature_mappings');
                                                            $query = $product_attribute_feature_mappings_reg->query();
                                                            $insert_product_attribute_feature_mapping = $query->insert(['product_id', 'attribute_id', 'feature_id', 'created_by', 'created_date', 'modified_by', 'modified_date'])
                                                                    ->values([
                                                                        'product_id' => $product_id,
                                                                        'attribute_id' => $attribute_id,
                                                                        'feature_id' => $feature_id,
                                                                        'created_by' => $created_by,
                                                                        'created_date' => $created_date,
                                                                        'modified_by' => $modified_by,
                                                                        'modified_date' => $modified_date
                                                                    ])
                                                                    ->execute();
                                                        }
                                                    }
                                                    if (!$insert_product_attribute_feature_mapping) {
                                                        $error .= "product Not inserted for S.No. " . $j . "<br/>";
                                                        $errordata2 = true;
                                                    }
                                                }
                                            }
                                        }
                                        //End product Insertion EOC
                                        } else {
                                            $error .= "Same Product name exists already for S.No. " . $j . ",Kindly fill the another product name"."<br/>";
                                            $errordata2 = true;
                                        }
                                    }
                                    $j++;
                                }
                                if ($errordata2 == true) {
                                    $this->Flash->error(__($error));
                                    return $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                                } else {
                                    $this->Flash->success(__('Product added successfully'));
                                    return $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public function editProduct() {
        $this->viewBuilder()->layout('admin');
        if ($this->request->params['pass'][0] != '') {
            $product_id = $this->request->params['pass'][0];
            if (trim($product_id) == '') {
                $this->Flash->error(__('Sorry! Product id not exists.'));
                $this->redirect(array('controller' => 'Products', 'action' => 'index'));
            } else {
                //debug($product_id);die;
                $products_reg = TableRegistry::get('Product_details');
                $query = $products_reg->find("all")->where(['product_id' => $product_id]);
                $products = $this->getResultArray('Products', $query);
//                debug($products);die;
                if (!empty($products)) {
                    $mapped_cat_ids = $products['Products']['mapped_category_ids'];
                    $categories = str_replace('#', '', $products['Products']['mapped_category_ids']);
                    $categories = explode(',', $categories);
                    $cat_arr = array();
                    foreach($categories as $category){
                        $categories_reg = TableRegistry::get('Categories');
                        $query = $categories_reg->find('all')->where(['category_id' => $category]);
                        $categories = $this->getResultArray('Categories',$query);
                        $cat_arr[] = $categories['Categories']['category_id'];
                    }
                    $products['Products']['mapped_categories_ids'] = implode(",", $cat_arr);
                    $this->set("product_details", $products);
                    
                    
                    $categories_reg = TableRegistry::get('categories');
                    $query = $categories_reg->find('threaded', [
                                'keyField' => $categories_reg->primaryKey(),
                                'parentField' => 'parent_category_id'
                            ])->where(['categories.status' => 'Active','categories.created_by' => $this->Auth->user('user_id')]);
                    $categories = $this->getResultArray('Category', $query);
                    $this->set("categories", $categories);
        
        
                    
                } else {
                    $this->Flash->error(__('Sorry! Product details not found.'));
                    $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                }
                
                if (!empty($this->request->data)) {
                    if (isset($this->request->data['product_name']) && trim($this->request->data['product_name']) != '') {
                
                        $product_name = @trim($this->request->data['product_name']);

                        $products_reg = TableRegistry::get('Products');
                        $query = $products_reg->find('all')->where(['product_id' => $product_id]);
                        $product_detail = $this->getResultArray('Products', $query);
                        if(!empty($product_detail)){

                            $brand_id = $this->request->data['brand_value'];
                            $main_category_id = '';
                            $meta_tag_title = $this->request->data['meta_tag_title'];
                            $product_desc = $this->request->data['product_desc'];
                            $meta_tag_desc = $this->request->data['meta_tag_desc'];
                            $meta_tag_keyword = $this->request->data['meta_tag_keyword'];
                            $product_tags = $this->request->data['product_tags'];
                            $condition = 'New';

                            $created_by = $this->Auth->user('user_id');
                            $modified_by = $this->Auth->user('user_id');
                            $status = 'Active';
                            $created_date = date('Y-m-d H:m:s');
                            $modified_date = date('Y-m-d H:m:s');



                            $mapped_cat_ids = $this->request->data['selected_cat_ids'];
                            $mapped_cat_id_array = explode(",", $mapped_cat_ids);

                            $mapped_category_ids = array();
                            foreach ($mapped_cat_id_array as $mapped_cat_id_array1) {
                                $mapped_category_ids[] = '#' . $mapped_cat_id_array1 . '#';
                            }
                            $categoery_ids_mapped_final = implode(',', $mapped_category_ids);


                            $product_exists = array();
                            if (empty($product_exists)) {



                                $products_reg = TableRegistry::get('products');
                                $query = $products_reg->query();
                                $update = $query->update()
                                        ->set([
                                            'product_name' => $product_name,
                                            'brand_id' => $brand_id,
                                            'mapped_category_id' => $categoery_ids_mapped_final,
                                            'main_category_id' => $main_category_id,
                                            'meta_tag_title' => $meta_tag_title,
                                            'product_description' => $product_desc,
                                            'meta_tag_description' => $meta_tag_desc,
                                            'meta_tag_keyword' => $meta_tag_keyword,
                                            'product_tags' => $product_tags,
                                            'jan_barcode' => '',
                                            'upc_barcode' => '',
                                            'status' => $status,
                                            'modified_by' => $modified_by,
                                            'modified_date' => $modified_date
                                        ])
                                        ->where(['product_id'=>$product_id])
                                        ->execute();
                                if ($update) {
                                    //$product_id = $insert->lastInsertId('products');

                                    $available_quantity = $this->request->data['quantity'];
                                    $minimum_qyuntity_for_sale = $this->request->data['minimum_quantity_for_sale'];
                                    $behaviour_out_stock = $this->request->data['behaviour_when_out_of_stock'];
                                    $label_in_stock = $this->request->data['label_when_in_stock'];
                                    $label_out_stock = $this->request->data['label_when_out_of_stock'];
                                    //$availability_date = $this->request->data['availability_date'];
                                    $availability_date = date('Y-m-d H:i:s', strtotime($this->request->data['availability_date']));
                                    $created_by = $this->Auth->user('user_id');
                                    $modified_by = $this->Auth->user('user_id');
                                    $created_date = date('Y-m-d H:m:s');
                                    $modified_date = date('Y-m-d H:m:s');


                                    $product_quantity_mapping_reg = TableRegistry::get('product_quantity_mappings');
                                    $query = $product_quantity_mapping_reg->query();
                                    $update_product_quantity_mapping = $query->update()
                                            ->set([
                                                'available_quantity' => $available_quantity,
                                                'minimum_qyuntity_for_sale' => $minimum_qyuntity_for_sale,
                                                'label_in_stock' => $label_in_stock,
                                                'label_out_stock' => $label_out_stock,
                                                'availability_date' => $availability_date,
                                                'behaviour_out_stock' => $behaviour_out_stock,
                                                'modified_by' => $modified_by,
                                                'modified_date' => $modified_date
                                            ])
                                            ->where(['product_id'=>$product_id])
                                            ->execute();
                                    if ($update_product_quantity_mapping) {
                                        $price_per_unit = $this->request->data['price_without_tax'];
                                        $tax = '';
                                        $total_price = $this->request->data['price_with_tax'];
                                        $discount = '';
                                        $discount_percent = '';
                                        $old_total_price = '';
                                        $new_total_price = $this->request->data['price_with_tax'];

                                        $created_by = $this->Auth->user('user_id');
                                        $modified_by = $this->Auth->user('user_id');
                                        $created_date = date('Y-m-d H:m:s');
                                        $modified_date = date('Y-m-d H:m:s');

                                        $product_price_mapping_reg = TableRegistry::get('product_price_mappings');
                                        $query = $product_price_mapping_reg->query();
                                        $update_product_price_mapping = $query->update()
                                                ->set([
                                                    'price_per_unit' => $available_quantity,
                                                    'tax' => $minimum_qyuntity_for_sale,
                                                    'total_price' => $label_in_stock,
                                                    'discount' => $label_out_stock,
                                                    'discount_percent' => $availability_date,
                                                    'old_total_price' => $behaviour_out_stock,
                                                    'new_total_price' => $behaviour_out_stock,
                                                    'modified_by' => $modified_by,
                                                    'modified_date' => $modified_date
                                                ])
                                                ->where(['product_id'=>$product_id])
                                                ->execute();
                                        if ($update_product_price_mapping) {
//                                            debug($this->request->data);die;
                                            $attribute_array = $this->request->data['attribute_type'];
                                            $feature_array = $this->request->data['feature_value'];

                                            if (!empty($attribute_array)) {
                                                if (count($attribute_array) == count($feature_array)) {
                                                    foreach ($attribute_array as $key => $attr_arr) {
                                                        $attribute_id = $attr_arr;
                                                        $feature_id = $feature_array[$key];

                                                        $created_by = $this->Auth->user('user_id');
                                                        $modified_by = $this->Auth->user('user_id');
                                                        $created_date = date('Y-m-d H:m:s');
                                                        $modified_date = date('Y-m-d H:m:s');

                                                        $product_attribute_feature_mappings_reg = TableRegistry::get('product_attribute_feature_mappings');
                                                        $query = $product_attribute_feature_mappings_reg->query();
                                                        $update_product_attribute_feature_mapping = $query->update()
                                                                ->set([
                                                                    'attribute_id' => $attribute_id,
                                                                    'feature_id' => $feature_id,
                                                                    'modified_by' => $modified_by,
                                                                    'modified_date' => $modified_date
                                                                ])
                                                                ->where(['product_id'=>$product_id])
                                                                ->execute();
                                                    }
                                                }
                                            }
                                            $this->Flash->success(__('Product updated successfully'));
                                            $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                                        }
                                    }
                                }
                            }
                        } else {
                            $this->Flash->error(__($this->Error->getError("No details found for this product id.")));
                            $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                        }
                    } 
                    else {
                        $this->Flash->error(__($this->Error->getError("Please fill product name.")));
                        $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                    }
                }
                
                
            }
        }
    }
    
    
    
    public function editProductOld() {
        $this->viewBuilder()->layout('admin');
        if ($this->request->params['pass'][0] != '') {
            $product_id = $this->request->params['pass'][0];
            if (trim($product_id) == '') {
                $this->Flash->error(__('Sorry! Product id not exists.'));
                $this->redirect(array('controller' => 'Products', 'action' => 'index'));
            } else {
                //debug($product_id);die;

                $products_reg = TableRegistry::get('Products');
                $query = $products_reg->find()
//                ->fields('ec_products.*', 'ec_product_attribute_feature_mappings.*', 'ec_product_price_mappings.*')
                        ->hydrate(false)
                        ->join([
                            'product_price_mappings' => [
                                'table' => 'ec_product_price_mappings',
                                'type' => 'LEFT',
                                'conditions' => 'product_price_mappings.product_id = products.product_id'
                            ],
                            'product_quantity_mappings' => [
                                'table' => 'ec_product_quantity_mappings',
                                'type' => 'LEFT',
                                'conditions' => 'product_quantity_mappings.product_id = products.product_id'
                            ]
                        ])
                        ->select([
                    'Products.product_id',
                    'Products.product_name',
                    'Products.brand_id',
                    'Products.mapped_category_id',
                    'Products.main_category_id',
                    'Products.meta_tag_title',
                    'Products.product_description',
                    'Products.meta_tag_description',
                    'Products.meta_tag_keyword',
                    'Products.product_tags',
                    'Products.condition',
                    'Products.jan_barcode',
                    'Products.upc_barcode',
                    'Products.status',
                    'Products.created_by',
                    'Products.created_date',
                    'Products.modified_by',
                    'Products.modified_date',
                    'product_price_mappings.product_price_mapping_id',
                    'product_price_mappings.price_per_unit',
                    'product_price_mappings.tax',
                    'product_price_mappings.total_price',
                    'product_price_mappings.discount',
                    'product_price_mappings.discount_percent',
                    'product_price_mappings.old_total_price',
                    'product_price_mappings.new_total_price',
                    'product_quantity_mappings.product_quantity_mapping_id',
                    'product_quantity_mappings.available_quantity',
                    'product_quantity_mappings.minimum_qyuntity_for_sale',
                    'product_quantity_mappings.label_in_stock',
                    'product_quantity_mappings.label_out_stock',
                    'product_quantity_mappings.availability_date',
                    'product_quantity_mappings.behaviour_out_stock'
                ])
                ->where(['Products.product_id' => $product_id]);
                $products = $this->getResultArray('Products', $query);
//                debug($products);die;
                if (!empty($products)) {
                    $mapped_cat_ids = $products['Products']['mapped_category_id'];
                    $categories = str_replace('#', '', $products['Products']['mapped_category_id']);
                    $categories = explode(',', $categories);
                    $cat_arr = array();
                    foreach($categories as $category){
                        $categories_reg = TableRegistry::get('Categories');
                        $query = $categories_reg->find('all')->where(['category_id' => $category]);
                        $categories = $this->getResultArray('Categories',$query);
                        $cat_arr[] = $categories['Categories']['category_id'];
                    }
                    $products['Products']['mapped_categories_ids'] = implode(",", $cat_arr);
                    
                    //Attribute details fetch
                    $product_id = $products['Products']['product_id'];
                    
                    $product_attr_feature_reg = TableRegistry::get('product_attribute_feature_mappings');
                    $query = $product_attr_feature_reg->find('all')->where(['product_id' => $product_id]);
                    $attribute_feature_details = $this->getResultArray('AttributeFeatureDetails',$query);
                    if(!empty($attribute_feature_details)){
//                        debug($attribute_feature_details);die;
                        $attr_feature_arr = array();
                        $k= 0;
                        if(count($attribute_feature_details)>1){
                        foreach($attribute_feature_details as $attribute_feature_details1){
                            $attribute_id = $attribute_feature_details1['AttributeFeatureDetails']['attribute_id'];
                            $feature_id = $attribute_feature_details1['AttributeFeatureDetails']['feature_id'];
                            
                            $attribute_reg = TableRegistry::get('attribute_masters');
                            $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                            $attribute_details = $this->getResultArray('Attribute',$query);
                            if(!empty($attribute_details)){
                                $attribute_name = $attribute_details['Attribute']['attribute_name'];
                            } else {
                                $attribute_name = '';
                            }
                            
                            
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['feature_id' => $feature_id]);
                            $feature_details = $this->getResultArray('Feature',$query);
                            if(!empty($feature_details)){
                                $feature_name = $feature_details['Feature']['feature_name'];
                            } else {
                                $feature_name = '';
                            }
                            
                            
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
                            $feature_details = $this->getResultArray('Feature',$query);
                            $feature_array = array("0" => "Select Feature");
                            if(!empty($feature_details)){
                                foreach ($feature_details as $feature_details1) {
                                    $feature_array[$feature_details1['Feature']['feature_id']] = $feature_details1['Feature']['feature_name'];
                                }
                            } else {
                                $feature_array = array();;
                            }
                            
                            $attr_feature_arr['attribute_id'] = $attribute_id;
                            $attr_feature_arr['attribute_name'] = $attribute_name;
                            $attr_feature_arr['feature_id'] = $feature_id;
                            $attr_feature_arr['feature_name'] = $feature_name;
                            $attr_feature_arr['feature_array_for_attr'] = $feature_array;
                            
                            $products['product_attribute_feature_mappings'][$k] = $attr_feature_arr;
                            
                            $k++;
                        }
                        } else {
                            $k = 0;
                            $attribute_id = $attribute_feature_details['AttributeFeatureDetails']['attribute_id'];
                            $feature_id = $attribute_feature_details['AttributeFeatureDetails']['feature_id'];
                            
                            $attribute_reg = TableRegistry::get('attribute_masters');
                            $query = $attribute_reg->find('all')->where(['attribute_id' => $attribute_id]);
                            $attribute_details = $this->getResultArray('Attribute',$query);
                            if(!empty($attribute_details)){
                                $attribute_name = $attribute_details['Attribute']['attribute_name'];
                            } else {
                                $attribute_name = '';
                            }
                            
                            
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['feature_id' => $feature_id]);
                            $feature_details = $this->getResultArray('Feature',$query);
                            if(!empty($feature_details)){
                                $feature_name = $feature_details['Feature']['feature_name'];
                            } else {
                                $feature_name = '';
                            }
                            
                            
                            $feature_reg = TableRegistry::get('feature_masters');
                            $query = $feature_reg->find('all')->where(['attribute_id' => $attribute_id]);
                            $feature_details = $this->getResultArray('Feature',$query);
                            $feature_array = array("0" => "Select Feature");
                            if(!empty($feature_details)){
                                foreach ($feature_details as $feature_details1) {
                                    $feature_array[$feature_details1['Feature']['feature_id']] = $feature_details1['Feature']['feature_name'];
                                }
                            } else {
                                $feature_array = array();;
                            }
                            
                            $attr_feature_arr['attribute_id'] = $attribute_id;
                            $attr_feature_arr['attribute_name'] = $attribute_name;
                            $attr_feature_arr['feature_id'] = $feature_id;
                            $attr_feature_arr['feature_name'] = $feature_name;
                            $attr_feature_arr['feature_array_for_attr'] = $feature_array;
                            
                            $products['product_attribute_feature_mappings'][$k] = $attr_feature_arr;
                        }
                    } else {
                        $products['product_attribute_feature_mappings'] = array();
                    }
                    
                    //attributes from attribute master
                    $attribute_reg = TableRegistry::get('attribute_masters');
                    $query = $attribute_reg->find('all');
                    $attributes = $this->getResultArray('Attribute', $query);
                    $atttr_array = array("0" => "Select Attribute");
                    if (!empty($attributes)) {
                        foreach ($attributes as $attribute1) {
                            $atttr_array[$attribute1['Attribute']['attribute_id']] = $attribute1['Attribute']['attribute_name'];
                        }
                    }
                    $this->set("attributes", $atttr_array);
        
                    
                    $brands_reg = TableRegistry::get('brands');
                    $query = $brands_reg->find('all')->where(['status' => 'Active']);
                    $brands = $this->getResultArray('Brand', $query);
                    $brand_arr = array("0" => "Select Brand");
                    if (!empty($brands)) {
                        foreach ($brands as $brands1) {
                            $brand_arr[$brands1['Brand']['brand_id']] = $brands1['Brand']['brand_name'];
                        }
                    }

                    $this->set("brands", $brand_arr);
                    
                    $categories_reg = TableRegistry::get('categories');
                    $query = $categories_reg->find('threaded', [
                                'keyField' => $categories_reg->primaryKey(),
                                'parentField' => 'parent_category_id'
                            ])->where(['categories.status' => 'Active']);
                    $categories = $this->getResultArray('Category', $query);
            //        debug($categories);die;
                    $this->set("categories", $categories);
        
        
                    $this->set("product_details", $products);
                } else {
                    $this->Flash->error(__('Sorry! Product details not found.'));
                    $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                }
                
                if (!empty($this->request->data)) {
                    if (isset($this->request->data['product_name']) && trim($this->request->data['product_name']) != '') {
                
                        $product_name = @trim($this->request->data['product_name']);

                        $products_reg = TableRegistry::get('Products');
                        $query = $products_reg->find('all')->where(['product_id' => $product_id]);
                        $product_detail = $this->getResultArray('Products', $query);
                        if(!empty($product_detail)){

                            $brand_id = $this->request->data['brand_value'];
                            $main_category_id = '';
                            $meta_tag_title = $this->request->data['meta_tag_title'];
                            $product_desc = $this->request->data['product_desc'];
                            $meta_tag_desc = $this->request->data['meta_tag_desc'];
                            $meta_tag_keyword = $this->request->data['meta_tag_keyword'];
                            $product_tags = $this->request->data['product_tags'];
                            $condition = 'New';

                            $created_by = $this->Auth->user('user_id');
                            $modified_by = $this->Auth->user('user_id');
                            $status = 'Active';
                            $created_date = date('Y-m-d H:m:s');
                            $modified_date = date('Y-m-d H:m:s');



                            $mapped_cat_ids = $this->request->data['selected_cat_ids'];
                            $mapped_cat_id_array = explode(",", $mapped_cat_ids);

                            $mapped_category_ids = array();
                            foreach ($mapped_cat_id_array as $mapped_cat_id_array1) {
                                $mapped_category_ids[] = '#' . $mapped_cat_id_array1 . '#';
                            }
                            $categoery_ids_mapped_final = implode(',', $mapped_category_ids);


                            $product_exists = array();
                            if (empty($product_exists)) {



                                $products_reg = TableRegistry::get('products');
                                $query = $products_reg->query();
                                $update = $query->update()
                                        ->set([
                                            'product_name' => $product_name,
                                            'brand_id' => $brand_id,
                                            'mapped_category_id' => $categoery_ids_mapped_final,
                                            'main_category_id' => $main_category_id,
                                            'meta_tag_title' => $meta_tag_title,
                                            'product_description' => $product_desc,
                                            'meta_tag_description' => $meta_tag_desc,
                                            'meta_tag_keyword' => $meta_tag_keyword,
                                            'product_tags' => $product_tags,
                                            'jan_barcode' => '',
                                            'upc_barcode' => '',
                                            'status' => $status,
                                            'modified_by' => $modified_by,
                                            'modified_date' => $modified_date
                                        ])
                                        ->where(['product_id'=>$product_id])
                                        ->execute();
                                if ($update) {
                                    //$product_id = $insert->lastInsertId('products');

                                    $available_quantity = $this->request->data['quantity'];
                                    $minimum_qyuntity_for_sale = $this->request->data['minimum_quantity_for_sale'];
                                    $behaviour_out_stock = $this->request->data['behaviour_when_out_of_stock'];
                                    $label_in_stock = $this->request->data['label_when_in_stock'];
                                    $label_out_stock = $this->request->data['label_when_out_of_stock'];
                                    //$availability_date = $this->request->data['availability_date'];
                                    $availability_date = date('Y-m-d H:i:s', strtotime($this->request->data['availability_date']));
                                    $created_by = $this->Auth->user('user_id');
                                    $modified_by = $this->Auth->user('user_id');
                                    $created_date = date('Y-m-d H:m:s');
                                    $modified_date = date('Y-m-d H:m:s');


                                    $product_quantity_mapping_reg = TableRegistry::get('product_quantity_mappings');
                                    $query = $product_quantity_mapping_reg->query();
                                    $update_product_quantity_mapping = $query->update()
                                            ->set([
                                                'available_quantity' => $available_quantity,
                                                'minimum_qyuntity_for_sale' => $minimum_qyuntity_for_sale,
                                                'label_in_stock' => $label_in_stock,
                                                'label_out_stock' => $label_out_stock,
                                                'availability_date' => $availability_date,
                                                'behaviour_out_stock' => $behaviour_out_stock,
                                                'modified_by' => $modified_by,
                                                'modified_date' => $modified_date
                                            ])
                                            ->where(['product_id'=>$product_id])
                                            ->execute();
                                    if ($update_product_quantity_mapping) {
                                        $price_per_unit = $this->request->data['price_without_tax'];
                                        $tax = '';
                                        $total_price = $this->request->data['price_with_tax'];
                                        $discount = '';
                                        $discount_percent = '';
                                        $old_total_price = '';
                                        $new_total_price = $this->request->data['price_with_tax'];

                                        $created_by = $this->Auth->user('user_id');
                                        $modified_by = $this->Auth->user('user_id');
                                        $created_date = date('Y-m-d H:m:s');
                                        $modified_date = date('Y-m-d H:m:s');

                                        $product_price_mapping_reg = TableRegistry::get('product_price_mappings');
                                        $query = $product_price_mapping_reg->query();
                                        $update_product_price_mapping = $query->update()
                                                ->set([
                                                    'price_per_unit' => $available_quantity,
                                                    'tax' => $minimum_qyuntity_for_sale,
                                                    'total_price' => $label_in_stock,
                                                    'discount' => $label_out_stock,
                                                    'discount_percent' => $availability_date,
                                                    'old_total_price' => $behaviour_out_stock,
                                                    'new_total_price' => $behaviour_out_stock,
                                                    'modified_by' => $modified_by,
                                                    'modified_date' => $modified_date
                                                ])
                                                ->where(['product_id'=>$product_id])
                                                ->execute();
                                        if ($update_product_price_mapping) {
//                                            debug($this->request->data);die;
                                            $attribute_array = $this->request->data['attribute_type'];
                                            $feature_array = $this->request->data['feature_value'];

                                            if (!empty($attribute_array)) {
                                                if (count($attribute_array) == count($feature_array)) {
                                                    foreach ($attribute_array as $key => $attr_arr) {
                                                        $attribute_id = $attr_arr;
                                                        $feature_id = $feature_array[$key];

                                                        $created_by = $this->Auth->user('user_id');
                                                        $modified_by = $this->Auth->user('user_id');
                                                        $created_date = date('Y-m-d H:m:s');
                                                        $modified_date = date('Y-m-d H:m:s');

                                                        $product_attribute_feature_mappings_reg = TableRegistry::get('product_attribute_feature_mappings');
                                                        $query = $product_attribute_feature_mappings_reg->query();
                                                        $update_product_attribute_feature_mapping = $query->update()
                                                                ->set([
                                                                    'attribute_id' => $attribute_id,
                                                                    'feature_id' => $feature_id,
                                                                    'modified_by' => $modified_by,
                                                                    'modified_date' => $modified_date
                                                                ])
                                                                ->where(['product_id'=>$product_id])
                                                                ->execute();
                                                    }
                                                }
                                            }
                                            $this->Flash->success(__('Product updated successfully'));
                                            $this->redirect(array('controller' => 'Products', 'action' => 'index'));
                                        }
                                    }
                                }
                            }
                        } else {
                            $this->Flash->error(__($this->Error->getError("No details found for this product id.")));
                            $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                        }
                    } 
                    else {
                        $this->Flash->error(__($this->Error->getError("Please fill product name.")));
                        $this->redirect(array('controller' => 'Products', 'action' => 'addProduct'));
                    }
                }
                
                
            }
        }
    }

}
