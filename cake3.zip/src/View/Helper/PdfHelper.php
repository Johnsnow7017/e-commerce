<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of pdf
 *
 * @author Brajendra
 */
namespace App\View\Helper;

use Cake\View\Helper;
use Cake\ORM\TableRegistry;
use Dompdf\Dompdf;

class PdfHelper extends Helper {
    //put your code here
    
    function createPdf($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        //require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'src' . DS . 'Autoloader.php');
        //debug(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');die;
//debug($html);die;
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();
        $dompdf->stream($filename);
        
        //header('Content-type: text/plain; charset=utf-8');
//        $output = $dompdf->output();
//        echo $output;
    }
    function savePdf($html ,$filename){
        //App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();

//        $file_to_save = Configure::read('Document_Path') . "mail_pdf/".$filename;
        //save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());     
            
    }
    
    function downloadPdf($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();

        $file_to_save = Configure::read('Document_Path') . "pdf/".$filename;
        
        //Save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());
        
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename);
        
		ob_clean();
		flush();
        readfile($file_to_save);
        die;
    }
    function downloadPrPdf($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html( utf8_decode( $html ) );
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();
        

        $file_to_save = Configure::read('Document_Path') . "pdf/".$filename;
        
        //Save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());
        
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename);
        
		ob_clean();
		flush();
        readfile($file_to_save);
        die;
    }
    function pdf_header_footer($rfx_web_id, $rfx_name, $name = "RFX") {
        $htm = '<script type="text/php">
            if ( isset($pdf) ) {
                
                $footer = $pdf->open_object();
                $font = Font_Metrics::get_font("arial", "normal");
                $w = $pdf->get_width();
                $h = $pdf->get_height();

                // Draw a line at the top
                $y = $h - 2 * 10 - 24;
                $pdf->line(16, 66, $w - 16, 66, array(".58", ".58", ".58"), .5);

                $pdf->image("'.Configure::read('BASE_PATH').'logo.png", $w - 190, 60);
                $pdf->page_text(20, 26, "Date: '.date('d-m-y H:i').'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 38, "'.$name.' ID: '.$rfx_web_id.'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 50, "'.$name.' Name: '.$rfx_name.'", $font, 8, array(".58", ".58", ".58"));
                
                // Draw a line along the bottom
                $pdf->line(16, $y+15, $w - 16, $y+15, array(".58", ".58", ".58"), .5);
                $pdf->page_text($w - 65, $y+25, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 8, array(".58", ".58", ".58"));
                $pdf->page_text(20, $y+25, "'.Router::url("/", true).'", $font, 8, array(".58", ".58", ".58"));

                // Close the object (stop capture)
                $pdf->close_object();

                // Add the object to every page. You can
                // also specify "odd" or "even"
                $pdf->add_object($footer, "all");

            }
        ';
        $htm .= "</script>";
        return $htm;
    }
    function demoPDF($html ,$filename){
//        App::import("Vendor", "pdfcrowd");
//        try
//        {   
//            // create an API client instance
//            $client = new Pdfcrowd("ybrajendra", "fe6622aa1830cb964b34a3c0209a8dce");
//            //debug($client);
//
//            // convert a web page and store the generated PDF into a $pdf variable
//            $pdf = $client->convertHtml($html);
//
//            // set HTTP response headers
//            header("Content-Type: application/pdf");
//            header("Cache-Control: no-cache");
//            header("Accept-Ranges: none");
//            header("Content-Disposition: attachment; filename=\"google_com.pdf\"");
//
//            // send the generated PDF 
//            echo $pdf;
//        }
//        catch(PdfcrowdException $why)
//        {
//            echo "Pdfcrowd Error: " . $why;
//        }
        App::import("Vendor", "html2pdf/html2pdf.class");
        $html2pdf = new HTML2PDF('P','A4','fr');
        $html2pdf->WriteHTML($html);
        $html2pdf->Output($filename);
    }
    
    function HTML2PDF($html ,$filename){
//        App::import("Vendor", "pdfcrowd");
//        try
//        {   
//            // create an API client instance
//            $client = new Pdfcrowd("ybrajendra", "fe6622aa1830cb964b34a3c0209a8dce");
//            //debug($client);
//
//            // convert a web page and store the generated PDF into a $pdf variable
//            $pdf = $client->convertHtml($html);
//
//            // set HTTP response headers
//            header("Content-Type: application/pdf");
//            header("Cache-Control: no-cache");
//            header("Accept-Ranges: none");
//            header("Content-Disposition: attachment; filename=\"google_com.pdf\"");
//
//            // send the generated PDF 
//            echo $pdf;
//        }
//        catch(PdfcrowdException $why)
//        {
//            echo "Pdfcrowd Error: " . $why;
//        }
        
        App::import("Vendor", "tcpdf/tcpdf");
        $pdf = new TCPDF("P", "mm", "A4", true, 'UTF-8', false);
        $pdf->AddPage();
        $pdf->WriteHTML($html);
        $pdf->Output($filename);
        
    }
    function savePdfGraph($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();

        $file_to_save = Configure::read('Document_Path') . "graph_pdf/".$filename;
        //save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());     
    
        
    }
    
    function savePoPdf($html ,$filename){
		
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
		
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
		
        $dompdf->set_paper("A4", 'portrait');
		
        $dompdf->render();

        $file_to_save = Configure::read('Document_Path') . "po_pdf/".$filename;
		//$file_to_save ="ftp://" . Configure::read('FTP_USER') . ":" . Configure::read('FTP_PASS') . "@" . Configure::read('FTP_HOST') . Configure::read('FTP_PATH') . $filename;
        //save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());     
        
    }
    
     function po_header_footer($po_web_id, $po_name, $name = "PO") {
        $htm = '<script type="text/php">
            if ( isset($pdf) ) {
                
                $footer = $pdf->open_object();
                $font = Font_Metrics::get_font("arial", "normal");
                $w = $pdf->get_width();
                $h = $pdf->get_height();

                // Draw a line at the top
                $y = $h - 2 * 10 - 24;
                $pdf->line(16, 66, $w - 16, 66, array(".58", ".58", ".58"), .5);

                $pdf->image("'.Configure::read('BASE_PATH').'logo.png", $w - 190, 60);
                $pdf->page_text(20, 26, "Date: '.date('d-m-y H:i').'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 38, "'.$name.' ID: '.$po_web_id.'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 50, "'.$name.' Name: '.$po_name.'", $font, 8, array(".58", ".58", ".58"));
                
                // Draw a line along the bottom
                $pdf->line(16, $y+15, $w - 16, $y+15, array(".58", ".58", ".58"), .5);
                $pdf->page_text($w - 65, $y+25, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 8, array(".58", ".58", ".58"));
                $pdf->page_text(20, $y+25, "'.Router::url("/", true).'", $font, 8, array(".58", ".58", ".58"));

                // Close the object (stop capture)
                $pdf->close_object();

                // Add the object to every page. You can
                // also specify "odd" or "even"
                $pdf->add_object($footer, "all");

            }
        ';
        $htm .= "</script>";
        return $htm;
    }
    function pr_header_footer($request_id, $request_title, $name = "Request") {
        $htm = '<script type="text/php">
            if ( isset($pdf) ) {
                
                $footer = $pdf->open_object();
                $font = Font_Metrics::get_font("arial", "normal");
                $w = $pdf->get_width();
                $h = $pdf->get_height();

                // Draw a line at the top
                $y = $h - 2 * 10 - 24;
                $pdf->line(16, 66, $w - 16, 66, array(".58", ".58", ".58"), .5);

                $pdf->image("'.Configure::read('BASE_PATH').'logo.png", $w - 190, 60);
                $pdf->page_text(20, 26, "Date: '.date('d-m-y H:i').'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 38, "'.$name.' ID: '.$request_id.'", $font, 8, array(".58", ".58", ".58"));
                    $pdf->page_text(20, 50, "'.$name.' Title: '.$request_title.'", $font, 8, array(".58", ".58", ".58"));
                
                // Draw a line along the bottom
                $pdf->line(16, $y+15, $w - 16, $y+15, array(".58", ".58", ".58"), .5);
                $pdf->page_text($w - 65, $y+25, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 8, array(".58", ".58", ".58"));
                $pdf->page_text(20, $y+25, "'.Router::url("/", true).'", $font, 8, array(".58", ".58", ".58"));

                // Close the object (stop capture)
                $pdf->close_object();

                // Add the object to every page. You can
                // also specify "odd" or "even"
                $pdf->add_object($footer, "all");

            }
        ';
        $htm .= "</script>";
        return $htm;
    }
    
    function downloadPOPdf($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
        require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();

        $file_to_save = Configure::read('Document_Path') . "po_pdf/".$filename;
		//$file_to_save ="ftp://" . Configure::read('FTP_USER') . ":" . Configure::read('FTP_PASS') . "@" . Configure::read('FTP_HOST') . Configure::read('FTP_PATH') . $filename;
        //Save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename);
		ob_clean();
		flush();
        readfile($file_to_save);
        
       die;
       
    }
    
   function downloadSubPOPdf($html ,$filename){
//        App::import("Vendor", "dompdf/dompdf_config");
       require_once(ROOT . DS  . 'vendor' . DS  . 'dompdf' . DS . 'autoload.inc.php');
        $dompdf = new DOMPDF();
//        debug($html);die;
        //$font = Font_Metrics::get_font("helvetica", "bold");
        $dompdf->load_html($html);
        $dompdf->set_paper("A4", 'portrait');
        $dompdf->render();
//debug(Configure::read('Document_Path'));die;
        $file_to_save = "C:/wamp64/www/cakephp3/webroot/files/attachements/temp_attachments";
		//$file_to_save ="ftp://" . Configure::read('FTP_USER') . ":" . Configure::read('FTP_PASS') . "@" . Configure::read('FTP_HOST') . Configure::read('FTP_PATH') . $filename;
        //Save the pdf file on the server
        file_put_contents($file_to_save, $dompdf->output());
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename);
		ob_clean();
		flush();
        readfile($file_to_save);
       die;
    }
    
    function subpo_header_footer($po_web_id, $name = "PO") {
        $htm = '<script type="text/php">
            if ( isset($pdf) ) {
                
                $footer = $pdf->open_object();
                $font = Font_Metrics::get_font("arial", "normal");
                $w = $pdf->get_width();
                $h = $pdf->get_height();
                $pdf->image("'.Configure::read('BASE_PATH').'logo.png", 10, 60);
                $pdf->close_object();
                $pdf->add_object($footer, "odd");
            }
        ';
        $htm .= "</script>";
        return $htm;
    }
}

?>
