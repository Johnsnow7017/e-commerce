-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2017 at 09:33 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coupon`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand_master`
--

CREATE TABLE `brand_master` (
  `brand_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand_master`
--

INSERT INTO `brand_master` (`brand_id`, `name`, `status`, `created_date`) VALUES
(1, 'Mac D', 'Active', '2017-06-18 00:00:00'),
(2, 'Puma', 'Active', '2017-06-20 00:00:00'),
(3, 'Addidas', 'Active', '2017-06-17 11:28:35'),
(4, 'Addidas', 'Active', '2017-06-17 11:28:35'),
(5, 'Addidas', 'Active', '2017-06-17 11:28:35');

-- --------------------------------------------------------

--
-- Table structure for table `city_master`
--

CREATE TABLE `city_master` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(200) NOT NULL,
  `state_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_master`
--

INSERT INTO `city_master` (`city_id`, `city_name`, `state_id`, `status`, `created_date`) VALUES
(1, 'Jaipur', 4, 'Active', '2017-06-17 00:00:00'),
(2, 'Jodhpur', 4, 'Active', '2017-06-17 18:33:35'),
(3, 'noida', 2, 'Active', '2017-06-25 13:03:36'),
(4, 'gaziabad', 1, 'Active', '2017-06-25 13:03:47'),
(5, 'gaziabad', 1, 'Active', '2017-06-25 13:03:47'),
(6, 'Gulmarg', 6, 'Active', '2017-07-30 11:20:33');

-- --------------------------------------------------------

--
-- Table structure for table `coupon_master`
--

CREATE TABLE `coupon_master` (
  `coupon_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `age_limit` int(4) DEFAULT '18',
  `added_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupon_master`
--

INSERT INTO `coupon_master` (`coupon_id`, `name`, `state_id`, `city_id`, `location_id`, `brand_id`, `age_limit`, `added_date`, `modified_date`, `status`) VALUES
(1, 'BigFish', 2, 3, 2, 1, 67, '2017-07-30 15:21:05', '2017-07-30 15:21:05', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `phone`, `age`, `email`, `gender`, `state_id`, `city_id`, `status`, `created_date`) VALUES
(1, 'Lokesh', '7210797032', 23, 'garg7017@gmail.com', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(2, 'Keshav', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(3, 'Lokesh1', '7210797032', 23, 'garg7017@gmail.com', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(4, 'Keshav2', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(5, 'Keshav3', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(6, 'Keshav4', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(7, 'Keshav5', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(8, 'Keshav6', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17'),
(9, 'Keshav7', '9636377696', 23, 'garg7017@gmail.com1', 'Male', 2, 34, 'Active', '2017-06-17 07:41:17');

-- --------------------------------------------------------

--
-- Table structure for table `email_queue`
--

CREATE TABLE `email_queue` (
  `queue_id` int(11) NOT NULL,
  `subject` varchar(2000) DEFAULT NULL,
  `email_data` varchar(8000) DEFAULT NULL,
  `template` varchar(50) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `email_to` varchar(50) DEFAULT NULL,
  `email_from` varchar(50) DEFAULT NULL,
  `attachments` varchar(8000) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `error_message` varchar(500) DEFAULT NULL,
  `added_date` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `cc` varchar(2000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_queue`
--

INSERT INTO `email_queue` (`queue_id`, `subject`, `email_data`, `template`, `type`, `email_to`, `email_from`, `attachments`, `status`, `error_message`, `added_date`, `delivery_date`, `cc`) VALUES
(1, 'Customer Mail', 'a:0:{}', 'invite_supplier_unregistered', 'html', 'garg7017@gmail.com', 'Samsung <amreek.s@samsung.com>', 'a:0:{}', 1, '', '2017-08-01 08:25:17', '2017-08-01 09:23:01', 'a:0:{}'),
(2, 'Customer Mail', 'a:1:{s:12:"email_footer";s:190:"This is an automated message from Samsung. Please do not reply to this message.<br /><br />\n                                Thanks & regards<br/>\n                                Team Samsung";}', 'invite_supplier_unregistered', 'html', 'garg7017@gmail.com', 'Samsung <amreek.s@samsung.com>', 'a:0:{}', 1, '', '2017-08-01 08:25:32', '2017-08-01 09:24:11', 'a:0:{}'),
(3, 'Customer Mail', 'a:2:{s:4:"name";s:13:"Customer Name";s:12:"email_footer";s:190:"This is an automated message from Samsung. Please do not reply to this message.<br /><br />\n                                Thanks & regards<br/>\n                                Team Samsung";}', 'invite_supplier_unregistered', 'html', 'garg7017@gmail.com', 'Samsung <amreek.s@samsung.com>', 'a:0:{}', 1, '', '2017-08-01 08:32:08', '2017-08-01 09:24:11', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `intelligent_questions`
--

CREATE TABLE `intelligent_questions` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location_master`
--

CREATE TABLE `location_master` (
  `location_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location_master`
--

INSERT INTO `location_master` (`location_id`, `name`, `state_id`, `city_id`, `status`, `created_date`) VALUES
(1, 'Sector 10, Pratap Nagar', 4, 1, 'Active', '2017-06-25 11:46:48'),
(2, 'sector52', 2, 3, 'Active', '2017-06-25 13:16:51'),
(3, 'sector52', 2, 3, 'Active', '2017-06-25 13:16:51');

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE `state_master` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`state_id`, `state_name`, `status`, `created_date`) VALUES
(1, 'up', 'Active', '2017-06-17 13:01:02'),
(2, 'delhi', 'Active', '2017-06-17 13:01:16'),
(4, 'Rajsthan', 'Active', '2017-07-30 00:00:00'),
(6, 'Kashmir', 'Active', '2017-07-30 11:20:02'),
(7, 'Kerla', 'Active', '2017-07-30 11:20:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `type`, `status`, `created_date`, `modified_date`) VALUES
(15, 'admin', 'admin@gmail.com', '96225ede1e345a1ce879be1331c45ef9', 'Admin', 'Active', '2017-06-08 20:06:32', '2017-06-08 20:06:32');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `age` int(2) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `coupon_type` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `name`, `mobile`, `age`, `email`, `gender`, `coupon_type`, `state`, `city`, `location`, `created_at`) VALUES
(22, 'Prashant', '9717248421', 89, 'tt@g.com', 'male', '28', '', '', '', '2017-07-30 13:00:31'),
(23, 'Prashant', '9717248421', 45, 'asd@g.com', 'male', '39', '2', '3', '2', '2017-07-30 14:38:32'),
(24, 'Prashant', '9717248421', 2, 'abc@g.com', 'male', '42', '4', '1', '1', '2017-07-30 15:02:03'),
(25, 'Sahil', '9717248421', 45, 'abc@g.com', 'male', '', '2', '3', '2', '2017-07-30 15:23:38'),
(26, 'Prashant', '9717248421', 56, 'asdf@g.com', 'male', '1', '4', '1', '1', '2017-07-30 15:29:59'),
(27, 'Sudhir', '7011273521', 21, 'abc@g.com', 'male', '1', '2', '3', '2', '2017-07-30 15:43:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand_master`
--
ALTER TABLE `brand_master`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `city_master`
--
ALTER TABLE `city_master`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `coupon_master`
--
ALTER TABLE `coupon_master`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `email_queue`
--
ALTER TABLE `email_queue`
  ADD PRIMARY KEY (`queue_id`);

--
-- Indexes for table `location_master`
--
ALTER TABLE `location_master`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `state_master`
--
ALTER TABLE `state_master`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand_master`
--
ALTER TABLE `brand_master`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `city_master`
--
ALTER TABLE `city_master`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `coupon_master`
--
ALTER TABLE `coupon_master`
  MODIFY `coupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `email_queue`
--
ALTER TABLE `email_queue`
  MODIFY `queue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `location_master`
--
ALTER TABLE `location_master`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `state_master`
--
ALTER TABLE `state_master`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
