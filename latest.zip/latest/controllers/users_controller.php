<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class UsersController extends AppController {
    //var $name = 'Users';
	//var $name = 'Suppliers';
    var $components = array('Session'); 
     
    //var $name = 'Users';

    var $uses = array("exam","intelligent_question","User");
	
    
    public function index() {
    
        
    }
//    public function register(){
////        $this->layout = "admin";
////        $exams = $this->exam->query("select * from exams");
////        $exams = parent::getDataAll('Exam', $exams);
////        $this->set("exams",$exams);
//        if(!empty($this->data)){
//            
//            debug($this->data);die;
//        }
//    }
    function register() {
        if (!empty($this->data)){
//            debug($this->data);die;
            
            $this->data['user']['password'] = security::hash($this->data['user']['password'], "", true);
            $this->data['user']['type'] = 'Student';
            $this->data['user']['status'] = 'Active';
            $this->data['user']['created_date'] = date('Y-m-d H:m:s');
            $this->data['user']['modified_date'] = date('Y-m-d H:m:s');
            //$this->User->create();
            //if ($this->User->save($this->data['user'])) {
                $exam_inserted = $this->exam->query("insert into users set username = '".$this->data['user']['username']."',email='".$this->data['user']['email']."',password='".$this->data['user']['password']."',type='".$this->data['user']['type']."',status='".$this->data['user']['status']."',created_date='".$this->data['user']['created_date']."',modified_date='".$this->data['user']['modified_date']."'");
                if($exam_inserted){
                    $this->redirect(array("controller" => "users", "action" => "login"));
                }
            //}
        }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        //$this->redirect(array("controller" => "quizzes", "action" => "index"));
        //$this->Auth->allow("register","intelligence_test","login","index");
    }
    
     public function logout(){
        //$session = $this->request->session();
        $this->Session->delete('AuthUser');
        $this->redirect(array("controller" => "users", "action" => "login"));
    }
    
    
    function login(){
		//debug("A");die;
        //debug($this->params["named"]["start_exam"]);die;
//        if(isset($this->params["named"]["start_exam"]) && $this->params["named"]["start_exam"] == 1){
//            
//        }
        if(!empty($this->data)) {
            $hashedPassword = Security::hash($this->data['user']['password'], NULL, true);
            $username = $this->data['user']['username'];
            $user_detail = $this->exam->query("select * from users where username = '".$username."' and password = '".$hashedPassword."'");
            $user_detail = parent::getData('User', $user_detail);
            if(!empty($user_detail)){
                $this->Session->renew();
                $this->Session->write("AuthUser", $user_detail);
                $this->redirect('/quizzes/home');
//                $this->redirect(array("controller" => "quizzes", "action" => "home"));
            }
        }
    }
    
    
//    public function third(){
//        
//    }
}

?>
