-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2017 at 04:55 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `group_id` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`exam_id`, `name`, `description`, `group_id`) VALUES
(1, 'sdf', 'scdvff', '1');

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_1_mappings`
--

CREATE TABLE `exam_section_1_mappings` (
  `section_1_mapping_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `exam_web_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `i_question_id` int(11) NOT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_section_1_mappings`
--

INSERT INTO `exam_section_1_mappings` (`section_1_mapping_id`, `table_id`, `exam_web_id`, `user_id`, `i_question_id`, `correct_answer`, `given_answer`, `correct`) VALUES
(137, 34, 'EXAM-U22-00034', 22, 67, 5, 5, 'Yes'),
(138, 34, 'EXAM-U22-00034', 22, 68, 3, 1, 'No'),
(139, 35, 'EXAM-U23-00035', 23, 73, 5, 3, 'No'),
(140, 35, 'EXAM-U23-00035', 23, 74, 3, 4, 'No'),
(141, 35, 'EXAM-U23-00035', 23, 75, 2, 5, 'No'),
(142, 35, 'EXAM-U23-00035', 23, 76, 5, 4, 'No'),
(143, 37, 'EXAM-U25-00037', 25, 99, 4, 3, 'No'),
(144, 37, 'EXAM-U25-00037', 25, 100, 3, 3, 'Yes'),
(145, 37, 'EXAM-U25-00037', 25, 101, 2, 3, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_2_mappings`
--

CREATE TABLE `exam_section_2_mappings` (
  `section_2_mapping_id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `exam_web_id` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `se_question_id` int(11) DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_section_2_mappings`
--

INSERT INTO `exam_section_2_mappings` (`section_2_mapping_id`, `table_id`, `exam_web_id`, `user_id`, `se_question_id`, `correct_answer`, `given_answer`, `correct`) VALUES
(12, 35, 'EXAM-U23-00035', 23, 4, 3, 4, 'No'),
(13, 35, 'EXAM-U23-00035', 23, 5, 4, 5, 'No'),
(14, 35, 'EXAM-U23-00035', 23, 6, 5, 4, 'No'),
(15, 36, 'EXAM-U24-00036', 24, 4, 3, 1, 'No'),
(16, 36, 'EXAM-U24-00036', 24, 5, 4, 1, 'No'),
(17, 36, 'EXAM-U24-00036', 24, 10, 5, 1, 'No'),
(18, 36, 'EXAM-U24-00036', 24, 11, 3, 2, 'No'),
(19, 36, 'EXAM-U24-00036', 24, 12, 4, 1, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_3_mappings`
--

CREATE TABLE `exam_section_3_mappings` (
  `section_3_mapping_id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `exam_web_id` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sp_question_id` int(11) DEFAULT NULL,
  `option_mapping_id` int(11) DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_section_3_mappings`
--

INSERT INTO `exam_section_3_mappings` (`section_3_mapping_id`, `table_id`, `exam_web_id`, `user_id`, `sp_question_id`, `option_mapping_id`, `correct_answer`, `given_answer`, `correct`, `type`) VALUES
(69, 1, 'SAM-EXAM-1-0001', 1, 1, 1, 1, 5, 'No', 3),
(70, 1, 'SAM-EXAM-1-0001', 1, 1, 2, 3, 5, 'No', 3),
(71, 1, 'SAM-EXAM-1-0001', 1, 1, 3, 1, 5, 'No', 3),
(72, 1, 'SAM-EXAM-1-0001', 1, 1, 4, 5, 5, 'Yes', 3),
(73, 1, 'SAM-EXAM-1-0001', 1, 1, 5, 3, 5, 'No', 3),
(74, 1, 'SAM-EXAM-1-0001', 1, 1, 6, 4, 5, 'No', 3),
(75, 1, 'SAM-EXAM-1-0001', 1, 1, 7, 4, 5, 'No', 3),
(76, 1, 'SAM-EXAM-1-0001', 1, 1, 8, 1, 5, 'No', 3),
(77, 1, 'SAM-EXAM-1-0001', 1, 1, 9, 2, 5, 'No', 3),
(78, 1, 'SAM-EXAM-1-0001', 1, 1, 10, 1, 5, 'No', 3);

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_4_mappings`
--

CREATE TABLE `exam_section_4_mappings` (
  `section_4_mapping_id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `exam_web_id` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `info_question_id` int(11) DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_section_5_mappings`
--

CREATE TABLE `exam_section_5_mappings` (
  `section_5_mapping_id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `exam_web_id` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `p_question_id` int(11) DEFAULT NULL,
  `correct_answer` int(11) DEFAULT NULL,
  `given_answer` int(11) DEFAULT NULL,
  `correct` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_user_mgmts`
--

CREATE TABLE `exam_user_mgmts` (
  `table_id` int(11) NOT NULL,
  `exam_web_id` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_start_time` datetime DEFAULT NULL,
  `log_ip` varchar(200) DEFAULT NULL,
  `exam_close_time` datetime DEFAULT NULL,
  `section_1_attempted` varchar(100) DEFAULT NULL,
  `section_2_attempted` varchar(100) DEFAULT NULL,
  `section_3_attempted` varchar(100) DEFAULT NULL,
  `section_4_attempted` varchar(100) DEFAULT NULL,
  `section_5_attempted` varchar(100) DEFAULT NULL,
  `section_1_marks` int(11) DEFAULT NULL,
  `section_2_marks` int(11) DEFAULT NULL,
  `section_3_marks` int(11) DEFAULT NULL,
  `section_4_marks` int(11) DEFAULT NULL,
  `section_5_marks` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_user_mgmts`
--

INSERT INTO `exam_user_mgmts` (`table_id`, `exam_web_id`, `user_id`, `exam_start_time`, `log_ip`, `exam_close_time`, `section_1_attempted`, `section_2_attempted`, `section_3_attempted`, `section_4_attempted`, `section_5_attempted`, `section_1_marks`, `section_2_marks`, `section_3_marks`, `section_4_marks`, `section_5_marks`) VALUES
(1, 'SAm-EXAM-1-0001', 1, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'EXAM-U15-00002', 15, '2017-06-08 21:55:07', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'EXAM-U15-00003', 15, '2017-06-08 21:56:16', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'EXAM-U15-00004', 15, '2017-06-09 14:35:19', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'EXAM-U15-00005', 15, '2017-06-11 00:43:42', '::1', NULL, 'Attempted', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(6, 'EXAM-U15-00006', 15, '2017-06-11 02:15:10', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'EXAM-U15-00007', 15, '2017-06-11 02:16:34', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'EXAM-U15-00008', 15, '2017-06-11 02:17:04', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'EXAM-U15-00009', 15, '2017-06-11 02:17:56', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'EXAM-U15-00010', 15, '2017-06-11 02:18:26', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'EXAM-U15-00011', 15, '2017-06-11 02:19:06', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'EXAM-U15-00012', 15, '2017-06-11 02:21:54', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'EXAM-U15-00013', 15, '2017-06-11 02:22:23', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'EXAM-U15-00014', 15, '2017-06-11 02:23:09', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'EXAM-U15-00015', 15, '2017-06-11 02:23:27', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'EXAM-U15-00016', 15, '2017-06-11 02:23:42', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'EXAM-U15-00017', 15, '2017-06-11 02:24:09', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'EXAM-U15-00018', 15, '2017-06-11 02:24:41', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'EXAM-U15-00019', 15, '2017-06-11 02:25:12', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'EXAM-U15-00020', 15, '2017-06-11 02:26:26', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'EXAM-U15-00021', 15, '2017-06-11 02:26:44', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'EXAM-U15-00022', 15, '2017-06-11 02:28:18', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'EXAM-U15-00023', 15, '2017-06-11 02:28:33', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'EXAM-U15-00024', 15, '2017-06-11 02:28:55', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 'EXAM-U15-00025', 15, '2017-06-11 02:29:04', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 'EXAM-U15-00026', 15, '2017-06-11 02:29:11', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'EXAM-U15-00027', 15, '2017-06-11 02:29:26', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 'EXAM-U15-00028', 15, '2017-06-11 02:29:34', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'EXAM-U15-00029', 15, '2017-06-11 04:54:45', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'EXAM-U15-00030', 15, '2017-06-11 04:56:24', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', 'Attempted', 0, 0, 0, 0, 0),
(31, 'EXAM-U15-00031', 15, '2017-06-12 04:44:47', '::1', NULL, 'Attempted', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(32, 'EXAM-U16-00032', 16, '2017-06-12 05:17:16', '::1', NULL, 'Attempted', 'Attempted', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL),
(33, 'EXAM-U21-00033', 21, '2017-06-12 05:25:31', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', 'Attempted', 0, 0, 0, 0, 0),
(34, 'EXAM-U22-00034', 22, '2017-06-12 06:33:35', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', NULL, 1, 0, 0, 0, NULL),
(35, 'EXAM-U23-00035', 23, '2017-06-12 13:42:45', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', 'Attempted', 0, 0, 0, 0, 0),
(36, 'EXAM-U24-00036', 24, '2017-06-12 15:10:03', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', 'Attempted', 0, 0, 0, 0, 0),
(37, 'EXAM-U25-00037', 25, '2017-06-12 16:12:32', '::1', NULL, 'Attempted', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(38, 'EXAM-U15-00038', 15, '2017-06-13 07:54:12', '::1', NULL, 'Attempted', 'Attempted', 'Attempted', 'Attempted', 'Attempted', 0, 0, 0, 0, 0),
(39, 'EXAM-U26-00039', 26, '2017-06-13 11:49:40', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(40, 'EXAM-U27-00040', 27, '2017-06-13 12:03:34', '::1', NULL, 'Attempted', 'Attempted', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL),
(41, 'EXAM-U27-00041', 27, '2017-06-13 12:29:55', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 'EXAM-U27-00042', 27, '2017-06-13 14:39:07', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `information_ordering_questions`
--

CREATE TABLE `information_ordering_questions` (
  `info_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `set_type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `information_ordering_questions`
--

INSERT INTO `information_ordering_questions` (`info_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`, `set_type`) VALUES
(6, '', 'information_ordering_test', '1', '6_1497271247_6667_ques4.PNG', NULL, 1),
(5, '', 'information_ordering_test', '2', '5_1497271207_5269_ques3.PNG', NULL, 1),
(3, '', 'information_ordering_test', '1', '3_1497271073_8295_ques1.PNG', NULL, 1),
(4, '', 'information_ordering_test', '1', '4_1497271115_6013_ques2.PNG', NULL, 1),
(7, '', 'information_ordering_test', '2', '7_1497271290_4519_ques5.PNG', NULL, 1),
(8, '', 'information_ordering_test', '2', '8_1497271318_6467_ques6.PNG', NULL, 1),
(9, '', 'information_ordering_test', '2', '9_1497271395_8819_ques7.PNG', NULL, 1),
(10, '', 'information_ordering_test', '1', '10_1497271431_2223_ques8.PNG', NULL, 1),
(11, '', 'information_ordering_test', '2', '11_1497271459_6812_ques9.PNG', NULL, 1),
(12, '', 'information_ordering_test', '3', '12_1497271490_8724_ques10.PNG', NULL, 1),
(13, '', 'information_ordering_test', '2', '13_1497271528_4468_ques11.PNG', NULL, 1),
(14, '', 'information_ordering_test', '1', '14_1497271577_4247_ques12.PNG', NULL, 1),
(15, '', 'information_ordering_test', '2', '15_1497271609_7297_ques13.PNG', NULL, 1),
(16, '', 'information_ordering_test', '1', '16_1497271648_4549_ques14.PNG', NULL, 1),
(17, '', 'information_ordering_test', '2', '17_1497271672_3041_ques15.PNG', NULL, 1),
(18, '', 'information_ordering_test', '2', '18_1497271702_983_ques16.PNG', NULL, 1),
(19, '', 'information_ordering_test', '3', '19_1497271756_6626_ques17.PNG', NULL, 1),
(20, '', 'information_ordering_test', '1', '20_1497271784_3499_ques18.PNG', NULL, 1),
(21, '', 'information_ordering_test', '1', '21_1497271808_9985_ques19.PNG', NULL, 1),
(22, '', 'information_ordering_test', '3', '22_1497271854_7417_ques20.PNG', NULL, 1),
(23, '', 'information_ordering_test', '1', '23_1497271894_7210_ques21.PNG', NULL, 1),
(24, '', 'information_ordering_test', '2', '24_1497271961_5979_ques22.PNG', NULL, 1),
(25, '', 'information_ordering_test', '2', '25_1497271993_5848_ques23.PNG', NULL, 1),
(26, '', 'information_ordering_test', '1', '26_1497272032_9613_ques24.PNG', NULL, 1),
(27, '', 'information_ordering_test', '2', '27_1497272145_3438_ques25.PNG', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `intelligent_questions`
--

CREATE TABLE `intelligent_questions` (
  `i_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `set_type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intelligent_questions`
--

INSERT INTO `intelligent_questions` (`i_question_id`, `question_desc`, `question_type`, `correct_answer`, `question_img_path`, `status`, `set_type`) VALUES
(108, '', 'intelligence_test', '3', '108_1497246627_87_ques35.PNG', NULL, 1),
(107, '', 'intelligence_test', '3', '107_1497246595_5825_ques34.PNG', NULL, 1),
(106, '', 'intelligence_test', '5', '106_1497246532_579_ques33.PNG', NULL, 1),
(105, '', 'intelligence_test', '1', '105_1497246488_9860_ques32.PNG', NULL, 1),
(104, '', 'intelligence_test', '3', '104_1497246458_5128_ques31.PNG', NULL, 1),
(103, '', 'intelligence_test', '1', '103_1497246396_431_ques30.PNG', NULL, 1),
(102, '', 'intelligence_test', '3', '102_1497246285_2038_ques29.PNG', NULL, 1),
(101, '', 'intelligence_test', '2', '101_1497246207_301_ques28.PNG', NULL, 1),
(100, '', 'intelligence_test', '3', '100_1497246167_8964_ques27.PNG', NULL, 1),
(99, '', 'intelligence_test', '4', '99_1497246131_1507_ques26.PNG', NULL, 1),
(98, '', 'intelligence_test', '3', '98_1497246094_3806_ques25.PNG', NULL, 1),
(97, '', 'intelligence_test', '4', '97_1497246042_385_ques24.PNG', NULL, 1),
(96, '', 'intelligence_test', '4', '96_1497245978_2598_ques23.PNG', NULL, 1),
(95, '', 'intelligence_test', '5', '95_1497245930_6159_ques22.PNG', NULL, 1),
(94, '', 'intelligence_test', '4', '94_1497245728_7871_ques21.PNG', NULL, 1),
(93, '', 'intelligence_test', '4', '93_1497245692_4599_ques20.PNG', NULL, 1),
(92, '', 'intelligence_test', '5', '92_1497245653_3289_ques19.PNG', NULL, 1),
(91, '', 'intelligence_test', '4', '91_1497245599_6671_ques18.PNG', NULL, 1),
(90, '', 'intelligence_test', '3', '90_1497245566_4342_ques17.PNG', NULL, 1),
(89, '', 'intelligence_test', '1', '89_1497245524_1962_ques16.PNG', NULL, 1),
(88, '', 'intelligence_test', '3', '88_1497245441_5296_ques15.PNG', NULL, 1),
(87, '', 'intelligence_test', '1', '87_1497245394_1330_ques14.PNG', NULL, 1),
(86, '', 'intelligence_test', '2', '86_1497245356_3592_ques13.PNG', NULL, 1),
(85, '', 'intelligence_test', '5', '85_1497245307_7247_ques12.PNG', NULL, 1),
(84, '', 'intelligence_test', '4', '84_1497245228_9865_ques11.PNG', NULL, 1),
(83, '', 'intelligence_test', '4', '83_1497245156_2448_ques11.PNG', NULL, 1),
(82, '', 'intelligence_test', '3', '82_1497245115_2395_ques10.PNG', NULL, 1),
(81, '', 'intelligence_test', '1', '81_1497245075_891_ques9.PNG', NULL, 1),
(79, '', 'intelligence_test', '5', '79_1497245013_2552_ques7.PNG', NULL, 1),
(80, '', 'intelligence_test', '5', '80_1497245045_5606_ques8.PNG', NULL, 1),
(78, '', 'intelligence_test', '1', '78_1497244959_1219_ques6.PNG', NULL, 1),
(77, '', 'intelligence_test', '4', '77_1497244925_3459_ques5.PNG', NULL, 1),
(76, '', 'intelligence_test', '5', '76_1497244894_9120_ques4.PNG', NULL, 1),
(75, '', 'intelligence_test', '2', '75_1497244721_9419_ques3.PNG', NULL, 1),
(74, '', 'intelligence_test', '3', '74_1497244678_1292_ques2.PNG', NULL, 1),
(73, '', 'intelligence_test', '5', '73_1497244531_7057_ques1.PNG', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `personality_test_questions`
--

CREATE TABLE `personality_test_questions` (
  `p_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `option_a` varchar(500) DEFAULT NULL,
  `option_b` varchar(500) DEFAULT NULL,
  `option_c` varchar(500) DEFAULT NULL,
  `option_d` varchar(500) DEFAULT NULL,
  `option_e` varchar(500) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `set_type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `quiz_id` int(11) NOT NULL,
  `quiz_name` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `selective_attension_questions`
--

CREATE TABLE `selective_attension_questions` (
  `se_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `option_a` varchar(500) DEFAULT NULL,
  `option_b` varchar(500) DEFAULT NULL,
  `option_c` varchar(500) DEFAULT NULL,
  `option_d` varchar(500) DEFAULT NULL,
  `option_e` varchar(500) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `set_type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selective_attension_questions`
--

INSERT INTO `selective_attension_questions` (`se_question_id`, `question_desc`, `question_type`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_answer`, `question_img_path`, `status`, `set_type`) VALUES
(5, '2 4 6 2 3 4 2 4 6 5 2 4 6 2 4 2 1 2 6 2 2 3 2 2 4 4 4 5 2 2 2 2 1 1 4 2 4 2 3 2 4 1 2 2 2 3 2', 'selective_attension_test', '24', '25', '27', '26', '28', '4', NULL, NULL, 1),
(4, '5 2 4 2 6 2 5 2 6 2 4 2 2 4 2 2 1 4 2 6 2 8 5 4 2 2 4 2 3 2 4 2 2 1 2 4 2 2 1 6 2 4 3 4 2 6 2 5 5 ', 'selective_attension_test', '28', '29', '34', '31', '32', '3', NULL, NULL, 1),
(6, '2 2 4  4 1 2 2 4 4 1 4 4 2 23 4 4 2 2 5 5 4 2 6 4 2 1 2 2 1 4 2 4 2 2 3 2 4 2 5 2 2 4 1 2 2 3 2', 'selective_attension_test', '30', '28', '26', '32', '29', '5', NULL, NULL, 1),
(7, '2 4 4 3 2 4 4 1 4 4 2 4 3 3 2 2 6 2 2 5 4 4 4 4 2 1 2 4 2 2 2 3 3 4 2 2 5 2 2 1 4 4 2 3', 'selective_attension_test', '20', '32', '31', '33', '35', '3', NULL, NULL, 1),
(8, '2 4 4 5 4 2 4 2 2 6 2 1 4 2 2 4  4 2 3 4 2 2 3 4 2 4 6 2 4 2 4 2 4 5 4 4 2 4 2 5 2 2 4 2 3 2', 'selective_attension_test', '24', '25', '28', '22', '35', '2', NULL, NULL, 1),
(9, ' 1 2 4 6 6 4 2 2 4 5 6 6 4 2 2 4 3 6 4 2 2 2 3 4 6 2 2 1 1 3 5 2 4 6 4 2 2 5 1 1 4 2 6 2 3 2', 'selective_attension_test', '32', '23', '29', '35', '4', '1', NULL, NULL, 1),
(10, '1 2 4 6 2 4  1 2 4 6 1 2 4 6 2 3 2 4 4 4 2 4 5 2 4 2 1 3 5 4 2 3 2 1 4 5 2 1 4 2', 'selective_attension_test', '36', '33', '27', '29', '30', '5', NULL, NULL, 1),
(11, '2 4 6 8 2 4 2 3 5 2 4 6 2 5 2 4 6 5 3 2 4 4 6 2 4 3 5 2 4 2 1 2 2 4 6', 'selective_attension_test', '36', '45', '30', '27', '35', '3', NULL, NULL, 1),
(12, '1 2 4 6 4 2 4 6 3 2 4 6 4 2 4 6 2 5 4 6 4 2 4 6 2 4 7 6 4 2 4 6 4 2 3 2 4 2 4 5 2 2 2', 'selective_attension_test', '28', '29', '21', '24', '27', '4', NULL, NULL, 1),
(13, '1 2 4 6 2 4 2 4 4 3 4 2 4 4 2 4 6 5 4 3 2 1 2 4 6 3 2 4 2 4 2 3 4 5 6 2 2 2 4 4 1', 'selective_attension_test', '25', '28', '31', '24', '27', '1', NULL, NULL, 1),
(14, '2 4 6 8 1 5 4 2 6 8 1 4 2 2 4 2 4 3 4 2 6 3 6 4 2 1 2 1 5 6 4 2 4 2 2 2 1', 'selective_attension_test', '27', '24', '90', '20', '22', '4', NULL, NULL, 1),
(15, '1 3 4 2 2 4 4 4 2 4 4 2 1 5 4 2 42 1 4 5 4 5 5 4 2 6 6 4 2 6 1 3 2 5 2 4 3 2 ', 'selective_attension_test', '40', '42', '38', '45', '35', '3', NULL, NULL, 1),
(16, '1 2 3 4 5 6 6 4 2 5 4 3 2 2 4 1 1 4 2 6 2 4 6 1 2 4 6 5 2 4 6 2 2 4 6 1 5 3 2 2 4', 'selective_attension_test', '39', '34', '31', '37', '40', '2', NULL, NULL, 1),
(17, '2 2 4 4 6 6 1 1 2 2 4 4 5 5 4 4 3 3 2 2 1 1 4 4 2 2 1 2 3 4 5 4 3 2 1 2 3 2', 'selective_attension_test', '33', '39', '36', '42', '45', '3', NULL, NULL, 1),
(18, '2 2 4 2 6 4 3 5 2 4 6 3 4 6 3 5 4 6 2 2 4 6 2 2 5 1 4 2 6 4 2 1 3 2 2 4 2', 'selective_attension_test', '26 ', '35', '29', '41', '32', '3', NULL, NULL, 1),
(19, '5 2 4 6 4 2 4 5 4 2 1 1 4 4 4 2 3 4 2 3 4 2 2 4 1 1 2 4 3 4 2 3 3 4 2 4 2 3 2', 'selective_attension_test', '29', '32', '35', '28', '26', '2', NULL, NULL, 1),
(20, '2 4 3 2 4 6 2 4 5 4 2 2 4 5 4 2 6 4 2 4 2 4 4 5 2 4 1 1 2 4 6 2 1 1 2 4 3 3 2 4', 'selective_attension_test', '28 ', '23', '26', '20', '32', '1', NULL, NULL, 1),
(21, '2 4 2 4 1 1 4 2 4 4 4 5 4 4 2 4 5 4 4 2 3 3 1 1 5 5 4 2 4 4 2 4 1 3 4 2 4 4 2 4 6 8 1 4', 'selective_attension_test', '43', '38', '32', '53', '35', '5', NULL, NULL, 1),
(22, '1 2 3 5 4 2 6 4 3 2 4 6 4 2 6 1 5 4 2 2 4 2 4 4 2 1 1 5 4 2 2 4 3 3 4 2 4 2 4 2', 'selective_attension_test', '31', '34', '28', '13', '37', '1', NULL, NULL, 1),
(23, '2 4 6 4 2 1 35 4 2 2 4 4 6 5 4 2 6 4 2 6 3 4 2 4 3 3 4 2 4 2 2 4 4 4 4 2 4 1 5', 'selective_attension_test', '26', '32', '41', '37', '29', '5', NULL, NULL, 1),
(24, '1 2 4 4 2 3 4 4 5 4 4 2 2 3 4 2 4 4 5 4 4 3 4 4 2 5 4 4 2 4 1 5 4 4 2 3 2 1', 'selective_attension_test', '28', '53', '35', '32', '38', '3', NULL, NULL, 1),
(25, '2 4 6 2 5 4 2 4 2 5 2 2 3 3 4 2 5 4 2 6 5 4 2 1 1 4 2 5 1 2 4 4 2 6 6', 'selective_attension_test', '40', '34', '37', '31', '41', '2', NULL, NULL, 1),
(26, '5 3 2 4 2 4 2 4 2 5 4 2 4 2 4 2 1 4 2 4 2 1 4 2 1 4 2 3 4 2 5 4 2 5 4 4 2 5 2 1 2', 'selective_attension_test', '33', '27', '35', '30', '40', '3', NULL, NULL, 1),
(27, '2 3 4 2 4 2 3 2 1 5 4 2 3 2 4 4 2 2 4 2 4 2 1 4 2 2 4 2 1 4 4 2 2 4 2 2 2 4 2 3', 'selective_attension_test', '17', '20', '23', '27', '30', '2', NULL, NULL, 1),
(28, '2 4 4 2 1 4 2 4 4 2 2 3 5 7 4 2 4 2 4 2 2 4 3 4 2 2 5 4 2 4 2 5 4 2 3 2 1 4 4 2 4', 'selective_attension_test', '33', '36', '30', '35', '38', '1', NULL, NULL, 1),
(29, '3 4 4 2 1 4 2 3 2 1 5 4 2 6 4 2 1 5 4 2 4 3 2 4 1 5 4 3 2 2 4 2 1 5 4 2', 'selective_attension_test', '42', '43', '40', '34', '37', '5', NULL, NULL, 1),
(31, '2 4 2 2 4 2 1 1 4 2 1 4 2 2 3 4 3 2 4 4 5 4 4 2 4 5 4 2 3 4 2 4 3 4 4 2 1 4', 'selective_attension_test', '31', '33', '28', '23', '25', '3', NULL, NULL, 1),
(32, '2 4 2 2 4 2 1 1 4 2 1 4 2 2 3 4 3 2 4 4 5 4 4 2 4 5 4 2 3 4 2 4 3 4 4 2 1 4', 'selective_attension_test', '23', '26', '21', '31', '29', '2', NULL, NULL, 1),
(33, '4 2 2 4 1 4 2 4 5 4 2 6 4 5 6 4 2 4 1 5 4 3 2 1 4 4 2 2 4 2 4 1 5 4 2 2 4 2 1 4 2', 'selective_attension_test', '23', '33', '25', '28', '31', '4', NULL, NULL, 1),
(34, '2 3 2 1 4 2 3 3 1 4 4 2 4 6 4 5 4 5 6 4 4 5 4 4 2 2 4 2 2 4 1 3 4 2 4 6 5 4 2 2 4', 'selective_attension_test', '42', '32', '35', '38', '30', '3', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `spatial_scanning_questions`
--

CREATE TABLE `spatial_scanning_questions` (
  `sp_question_id` int(11) NOT NULL,
  `question_desc` varchar(2000) DEFAULT NULL,
  `question_type` varchar(100) DEFAULT NULL,
  `question_img_path` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `set_type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spatial_scanning_questions`
--

INSERT INTO `spatial_scanning_questions` (`sp_question_id`, `question_desc`, `question_type`, `question_img_path`, `status`, `set_type`) VALUES
(6, '', 'spatial_scanning_test', '6_1497264348_4534_section4.PNG', NULL, 1),
(5, '', 'spatial_scanning_test', '5_1497264144_7787_section3.PNG', NULL, 1),
(3, '', 'spatial_scanning_test', '3_1497263644_9136_section1.PNG', NULL, 1),
(4, '', 'spatial_scanning_test', '4_1497263898_9810_section2.PNG', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sp_question_option_mappings`
--

CREATE TABLE `sp_question_option_mappings` (
  `mapping_id` int(11) NOT NULL,
  `sp_question_id` int(11) NOT NULL,
  `shortest_route_from` varchar(100) NOT NULL,
  `option_a` varchar(20) NOT NULL,
  `option_b` varchar(20) NOT NULL,
  `option_c` varchar(20) NOT NULL,
  `option_d` varchar(20) NOT NULL,
  `option_e` varchar(20) NOT NULL,
  `correct_answer` varchar(10) NOT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_question_option_mappings`
--

INSERT INTO `sp_question_option_mappings` (`mapping_id`, `sp_question_id`, `shortest_route_from`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_answer`, `status`) VALUES
(1, 1, 'A To P', '1', '2', '3', '4', '5', '1', NULL),
(2, 1, 'B To Q', '7', '6', '4', '9', '10', '3', NULL),
(3, 1, 'C To R', '6', '8', '3', '5', '1', '1', NULL),
(4, 1, 'D To S', '2', '5', '7', '3', '1', '5', NULL),
(5, 1, 'E To T', '6', '9', '3', '10', '1', '3', NULL),
(6, 1, 'F To U', '2', '4', '7', '5', '1', '4', NULL),
(7, 1, 'H To V', '10', '9', '6', '7', '8', '4', NULL),
(8, 1, 'I To W', '4', '5', '6', '7', '8', '1', NULL),
(9, 1, 'J To X', '9', '8', '7', '6', '5', '2', NULL),
(10, 1, 'K To Y', '2', '4', '6', '8', '9', '1', NULL),
(11, 2, 'r', 'tyyu', 'tyu', 'tu', 'tyut', 'yut', '2', NULL),
(12, 2, 'ut', 'ut', 'yu', 'tgyut', 'yu', 'tyu', '3', NULL),
(13, 2, 'tyutyu', 'tyu', 't', 'yjt', 'tg', 'yut', '2', NULL),
(14, 2, 'yut', 'yut', 'yut', 'YU', 'TYU', 'TYU', '4', NULL),
(15, 2, 'TYU', 'T', 'YUT', 'YUT', 'YUT', 'YUT', '4', NULL),
(16, 2, 'YU', 'TYU', 'TYU', 'TYU', 'TYU', 'T', '2', NULL),
(17, 2, 'YUT', 'YUT', 'YU', 'TYU', 'TYU', 'T', '2', NULL),
(18, 2, 'YUT', 'YUT', 'YUT', 'YU', 'TYU', 'TYU', '4', NULL),
(19, 2, 'T', 'YUT', 'YUT', 'YU', 'TYU', 'T', '5', NULL),
(20, 2, 'YUT', 'YUT', 'YUT', 'YU', 'TYU', 'T', '2', NULL),
(21, 3, 'Y - D', '1', '2', '3', '4', '5', '1', NULL),
(22, 3, 'F - P', '1', '2', '3', '4', '5', '4', NULL),
(23, 3, 'V -H', '4', '5', '6', '7', '9', '5', NULL),
(24, 3, 'A-U', '1', '2', '3', '4', '5', '2', NULL),
(25, 3, 'B-Q', '1', '2', '3', '4', '5', '3', NULL),
(26, 3, 'D-E', '5', '6', '7', '8', '9', '3', NULL),
(27, 3, 'U-P', '5', '6', '7', '8', '9', '4', NULL),
(28, 3, 'J-N', '1', '2', '3', '4', '5', '5', NULL),
(29, 3, 'R-L', '1', '2', '3', '4', '5', '4', NULL),
(30, 3, 'N-E', '5', '6', '7', '8', '9', '3', NULL),
(31, 4, 'A-V', '1', '2', '3', '4', '5', '2', NULL),
(32, 4, 'W-D', '1', '2', '3', '4', '5', '3', NULL),
(33, 4, 'Q-M', '1', '2', '3', '4', '5', '5', NULL),
(34, 4, 'S-Q', '1', '2', '3', '4', '5', '3', NULL),
(35, 4, 'D-G', '5', '6', '7', '8', '9', '5', NULL),
(36, 4, 'O-E', '5', '6', '7', '8', '9', '2', NULL),
(37, 4, 'U-B', '1', '2', '3', '4', '5', '2', NULL),
(38, 4, 'C-Q', '6', '7', '8', '9', '10', '5', NULL),
(39, 4, 'G-K', '6', '7', '8', '9', '10', '4', NULL),
(40, 4, 'N-Q', '1', '2', '3', '4', '5', '5', NULL),
(41, 5, 'R-C', '1', '2', '3', '4', '5', '4', NULL),
(42, 5, 'R-K', '6', '7', '8', '9', '10', '1', NULL),
(43, 5, 'Y-D', '6', '7', '8', '9', '10', '4', NULL),
(44, 5, 'U-Q', '1', '2', '3', '4', '5', '4', NULL),
(45, 5, 'Q-Y', '1', '2', '3', '4', '5', '4', NULL),
(46, 5, 'U-A', '6', '7', '8', '9', '10', '4', NULL),
(47, 5, 'I-E', '1', '2', '3', '4', '5', '3', NULL),
(48, 5, 'P-R', '1', '2', '3', '4', '5', '5', NULL),
(49, 5, 'M-J', '6', '7', '8', '9', '10', '1', NULL),
(50, 5, 'I-Q', '6', '7', '8', '9', '10', '2', NULL),
(51, 6, 'C-X', '1 ', '2', '3', '4', '5', '2', NULL),
(52, 6, 'D-A', '1', '2', '3', '4', '5', '2', NULL),
(53, 6, 'R-K', '6', '7', '8', '9', '10', '1', NULL),
(54, 6, 'U-A', '6', '7', '8', '9', '10', '4', NULL),
(55, 6, 'C-I', '1', '2', '3', '4', '5', '3', NULL),
(56, 6, 'E-Q', '6', '7', '8', '9', '10', '5', NULL),
(57, 6, 'I-L', '1', '2', '3', '4', '5', '4', NULL),
(58, 6, 'T-P', '6', '7', '8', '9', '10', '3', NULL),
(59, 6, 'E-A', '1', '2', '3', '4', '5', '2', NULL),
(60, 6, 'J -P', '6', '7', '8', '9', '10', '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `exam_sets` varchar(500) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `type`, `status`, `exam_sets`, `created_date`, `modified_date`) VALUES
(15, 'p', 'p', '5608db379935e0425055aaf4f368fe04c4ae9851', 'Student', 'Active', '1,2,3,4,5,6', '2017-06-08 20:06:32', '2017-06-08 20:06:32'),
(16, 'a', 'a', 'fbbfabe5ddedfb8adeee3da3e1eae447ba2e978e', 'Student', 'Active', '1', '2017-06-11 00:06:23', '2017-06-11 00:06:23'),
(17, 'b', 'b', '35893ab85d3aaae3bb74a330a2a6f445e30c3c0f', 'Student', 'Active', NULL, '2017-06-11 00:06:03', '2017-06-11 00:06:03'),
(18, 'o', 'o', 'aa24d832af7d1eef3cbb83f5d3c77e26867f5f86', 'Student', 'Active', NULL, '2017-06-11 00:06:19', '2017-06-11 00:06:19'),
(19, '', '', '7f229a119cfedbc4ecca4e7c0cc36c7568f480f5', 'Student', 'Active', NULL, '2017-06-11 09:06:33', '2017-06-11 09:06:33'),
(20, '', '', '7f229a119cfedbc4ecca4e7c0cc36c7568f480f5', 'Student', 'Active', NULL, '2017-06-11 09:06:30', '2017-06-11 09:06:30'),
(21, 'kes', 'akakbakb@gh.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-12 05:06:00', '2017-06-12 05:06:00'),
(22, 'farook00', 'farook.aryan2016@gmail.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-12 06:06:19', '2017-06-12 06:06:19'),
(23, 'rakesh00', 'rakeshmeena053@gmail.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-12 13:06:35', '2017-06-12 13:06:35'),
(24, 'HJK', 'HJK@GH.COM', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-12 15:06:32', '2017-06-12 15:06:32'),
(25, 'jk', 'jk@gh.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-12 16:06:55', '2017-06-12 16:06:55'),
(26, 'chunnu', 'ch@ch.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-13 11:06:55', '2017-06-13 11:06:55'),
(27, 'zxc', 'zxc@zx.com', 'e2cfc3cdb8e69f5c7705ba0aa4cae776985f8530', 'Student', 'Active', '1', '2017-06-13 12:06:36', '2017-06-13 12:06:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_section_1_mappings`
--
ALTER TABLE `exam_section_1_mappings`
  ADD PRIMARY KEY (`section_1_mapping_id`);

--
-- Indexes for table `exam_section_2_mappings`
--
ALTER TABLE `exam_section_2_mappings`
  ADD PRIMARY KEY (`section_2_mapping_id`);

--
-- Indexes for table `exam_section_3_mappings`
--
ALTER TABLE `exam_section_3_mappings`
  ADD PRIMARY KEY (`section_3_mapping_id`);

--
-- Indexes for table `exam_section_4_mappings`
--
ALTER TABLE `exam_section_4_mappings`
  ADD PRIMARY KEY (`section_4_mapping_id`);

--
-- Indexes for table `exam_section_5_mappings`
--
ALTER TABLE `exam_section_5_mappings`
  ADD PRIMARY KEY (`section_5_mapping_id`);

--
-- Indexes for table `exam_user_mgmts`
--
ALTER TABLE `exam_user_mgmts`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `information_ordering_questions`
--
ALTER TABLE `information_ordering_questions`
  ADD PRIMARY KEY (`info_question_id`);

--
-- Indexes for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  ADD PRIMARY KEY (`i_question_id`);

--
-- Indexes for table `personality_test_questions`
--
ALTER TABLE `personality_test_questions`
  ADD PRIMARY KEY (`p_question_id`);

--
-- Indexes for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  ADD PRIMARY KEY (`se_question_id`);

--
-- Indexes for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  ADD PRIMARY KEY (`sp_question_id`);

--
-- Indexes for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  ADD PRIMARY KEY (`mapping_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `exam_section_1_mappings`
--
ALTER TABLE `exam_section_1_mappings`
  MODIFY `section_1_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;
--
-- AUTO_INCREMENT for table `exam_section_2_mappings`
--
ALTER TABLE `exam_section_2_mappings`
  MODIFY `section_2_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `exam_section_3_mappings`
--
ALTER TABLE `exam_section_3_mappings`
  MODIFY `section_3_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `exam_section_4_mappings`
--
ALTER TABLE `exam_section_4_mappings`
  MODIFY `section_4_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `exam_section_5_mappings`
--
ALTER TABLE `exam_section_5_mappings`
  MODIFY `section_5_mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `exam_user_mgmts`
--
ALTER TABLE `exam_user_mgmts`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `information_ordering_questions`
--
ALTER TABLE `information_ordering_questions`
  MODIFY `info_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `intelligent_questions`
--
ALTER TABLE `intelligent_questions`
  MODIFY `i_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `personality_test_questions`
--
ALTER TABLE `personality_test_questions`
  MODIFY `p_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `selective_attension_questions`
--
ALTER TABLE `selective_attension_questions`
  MODIFY `se_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `spatial_scanning_questions`
--
ALTER TABLE `spatial_scanning_questions`
  MODIFY `sp_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `sp_question_option_mappings`
--
ALTER TABLE `sp_question_option_mappings`
  MODIFY `mapping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
