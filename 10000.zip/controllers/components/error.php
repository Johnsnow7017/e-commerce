<?php
//start
class ErrorComponent extends Object {

    var $components = array("Auth", "Session");

    public function getError($code, $codeShow = true) {
        App::import("model", "Error");
        $this->Error = new Error();
      // $error = $this->Error->find("first", array("conditions" => array("error_code" => $code)));
        $error_details=$this->Error->query("Exec spGetError '".$this->spParams($code)."'");
        $error=$this->getData("Error",$error_details);
        if($codeShow == true) {
            if($error) {
                return "Error No. ".$code. ": ".$error["Error"]["error_description"];
            } else {
                return $code;
            }
        } else {
            if($error) {
                return $error["Error"]["error_description"];
            } else {
                return $code;
            }
        }
    }

    public function getMessage($code) {
        App::import("model", "Error");
        $this->Error = new Error();
       // $error = $this->Error->find("first", array("conditions" => array("error_code" => $code)));
        $error_details=$this->Error->query("Exec spGetError '".$this->spParams($code)."'");
        $error=$this->getData("Error",$error_details);
        if($error) {
            return $error["Error"]["error_description"];
        } else {
            return $code;
        }
    }
    
    function getData($model, $datadetails) {
        $dataDetailsnew = array();
        $dataDetailsArray = array();
        $datanew=array();
        if($datadetails === true) {
           return $dataDetailsArray;
        } 
        for ($i = 0; $i < count($datadetails); $i++) {
            foreach ($datadetails[$i] as $data) {
                $dataDetailsnew[$model] = $data;
                $dataDetailsArray[] = $dataDetailsnew;
            }
        }
        for ($i = 0; $i < count($dataDetailsArray); $i++) {
                    foreach ($dataDetailsArray[$i] as $timezone) {
                        $datanew[$model] = $timezone;
                    }
                }
        return $datanew;
    }
	public function spParams($value){
        $value=preg_replace("/'/", "''", $value);
        return $value;
   }
}
?>