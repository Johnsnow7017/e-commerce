<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class QuizzesController extends AppController {

//    var $name = 'Actions';
    var $uses = array("exam", "intelligent_question");
    var $components = array('Session', 'Auth');

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow("register", "index", "generate_exam_id", "timeover_spatial_scanning_test_main", "exam_instruction", "exam_instruction_next", "timeover_spatial_scanning_instruction", "save_step5", "timeover_personality_test_instruction", "personality_test", "personality_test_instructions", "timeover_information_ordering_test", "save_step4", "timeover_info_ordering_test_instruction", "information_ordering_test", "information_ordering_test_instructions", "spatial_scanning2", "spatial_scanning3", "spatial_scanning4", "save_step3_two", "save_step3_three", "save_step3_four", "save_step3_one", "spatial_scanning_test_instructions", "spatial_scanning1", "timeover_selective_test_main", "save_step2", "intelligence_test", "spatial_scanning_test", "save_step1", "intelligence_test_instructions", "timeover_intelligence_test_main", "timeover_intelligence_test_instruction", "selective_attension_test", "timeover_selective_test_instruction", "selective_attension_test_instructions", "selective_test");
    }

    public function index() {
        parent::checkLoginUser();
    }

    public function exam_instruction() {
        
    }

    public function exam_instruction_next() {
        
    }
    
    

    public function generate_exam_id() {
        $user_details = $this->Session->read('AuthUser');
        //$user_details = array();
        if (!empty($user_details)) {
            $examwebid = $this->generateWebIdPmg($user_details);
            $ip = $_SERVER['REMOTE_ADDR'];
            $exam_start_time = date("Y-m-d H:i:s");
            $exam_save_inserted = $this->exam->query("insert into exam_user_mgmts set exam_web_id = '" . $examwebid . "',user_id='" . $user_details['User']['user_id'] . "',log_ip='" . $ip . "',exam_start_time='" . $exam_start_time . "'");
//            debug($exam_save_inserted);die;
            if ($exam_save_inserted) {
                $this->Session->write("exam_id", $examwebid);
                $this->Session->write("user_id", $user_details['User']['user_id']);
                $this->redirect(array("controller" => "quizzes", "action" => "intelligence_test_instructions"));
            } else {
                $this->redirect(array("controller" => "quizzes", "action" => "exam_instruction"));
            }
        } else {
            $this->Session->write("error_msg", "Sorry! First You have to Login to start your test.");
            $this->redirect(array("controller" => "quizzes", "action" => "exam_instruction"));
        }
    }

    private function generateWebIdPmg($user_details = array()) {


        $exam_count = $this->exam->query("select count(*) as count from exam_user_mgmts");
        $exam_count = parent::getData('Exam', $exam_count);


        $examcount = $exam_count['Exam']['count'];
        $examcount = $examcount + 1;
        $examcountpadding = str_pad($examcount, 5, "0", STR_PAD_LEFT);
        $examwebid = strtoupper('EXAM-' . 'U' . $user_details['User']['user_id'] . '-' . $examcountpadding);


        $count = $this->exam->query("select count(*) as count from exam_user_mgmts where exam_web_id='" . $examwebid . "'");
        $examwebidcheck = $count[0][0]['count'];
        if ($examwebidcheck > 0) {
            return $this->countExam($exam_count);
        } else {
            return $examwebid;
        }
    }

    function countRfx($rfxcount) {
        $rfxcount = $rfxcount + 1;
        $rfxcountpadding = str_pad($rfxcount, 5, "0", STR_PAD_LEFT);
        //$rfxwebid = strtoupper($comanyString . "-RFX-" . $rfxcountpadding);
        $examwebid = strtoupper('EXAM-' . 'U' . $user_details['User']['user_id'] . '-' . $examcountpadding);
        //$count = $this->Rfx->query("EXEC spRFXWebIdCheck @rfx_web_id='" . parent::spParams($rfxwebid) . "'");
        $count = $this->exam->query("select count(*) as count from exam_user_mgmts where exam_web_id='" . $examwebid . "'");
        $rfxwebidcheck = $count[0][0]['count'];
        // $rfxwebidcheck = $this->Rfx->find("count", array("conditions" => array("rfx_web_id" => $rfxwebid)));
        if ($rfxwebidcheck > 0) {
            return $this->countRfx($rfxcount);
        } else {
            return $examwebid;
        }
    }
    
    
    

    public function save_step1() {
        if (!empty($this->data)) {
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {
                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $question_id = $key;

                    $intelligence_exam_select = $this->exam->query("select * from exam_section_1_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and i_question_id='" . $question_id . "'");
                    $intelligence_exam_select = parent::getData('IntelligenceTest', $intelligence_exam_select);

                    if (empty($intelligence_exam_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_1_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',i_question_id='" . $question_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_1_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and i_question_id='" . $question_id . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_1_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and i_question_id='" . $question_id . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }

    public function save_step2() {
        if (!empty($this->data)) {
//            debug($this->data);die;
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {
                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $question_id = $key;

                    $selective_exam_select = $this->exam->query("select * from exam_section_2_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and se_question_id='" . $question_id . "'");
                    $selective_exam_select = parent::getData('SelectiveTest', $selective_exam_select);

                    if (empty($selective_exam_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_2_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',se_question_id='" . $question_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_2_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and se_question_id='" . $question_id . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_2_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and se_question_id='" . $question_id . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }

    public function save_step3_one() {
        //debug($this->data);die;
        if (!empty($this->data)) {
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {

                    $main_question_id = $this->data['quiz']['main_question_id'];

                    $type = '1';

                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $option_mapping_id = $key;

                    $spatial_scanning_q_select = $this->exam->query("select * from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and sp_question_id='" . $main_question_id . "' and option_mapping_id = '" . $option_mapping_id . "' and type='" . $type . "'");
                    $spatial_scanning_q_select = parent::getData('SpatialScanning', $spatial_scanning_q_select);

                    if (empty($spatial_scanning_q_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_3_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',sp_question_id='" . $main_question_id . "',option_mapping_id='" . $option_mapping_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "',type='" . $type . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_3_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }

    public function save_step3_two() {
        parent::checkLoginUser();
        //debug($this->data);die;
        if (!empty($this->data)) {
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {

                    $main_question_id = $this->data['quiz']['main_question_id'];

                    $type = '2';

                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $option_mapping_id = $key;

                    $spatial_scanning_q_select = $this->exam->query("select * from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and sp_question_id='" . $main_question_id . "' and option_mapping_id = '" . $option_mapping_id . "' and type='" . $type . "'");
                    $spatial_scanning_q_select = parent::getData('SpatialScanning', $spatial_scanning_q_select);

                    if (empty($spatial_scanning_q_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_3_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',sp_question_id='" . $main_question_id . "',option_mapping_id='" . $option_mapping_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "',type='" . $type . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_3_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }
    
    public function save_step3_three() {
        //debug($this->data);die;
        if (!empty($this->data)) {
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {

                    $main_question_id = $this->data['quiz']['main_question_id'];

                    $type = '3';

                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $option_mapping_id = $key;

                    $spatial_scanning_q_select = $this->exam->query("select * from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and sp_question_id='" . $main_question_id . "' and option_mapping_id = '" . $option_mapping_id . "' and type='" . $type . "'");
                    $spatial_scanning_q_select = parent::getData('SpatialScanning', $spatial_scanning_q_select);

                    if (empty($spatial_scanning_q_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_3_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',sp_question_id='" . $main_question_id . "',option_mapping_id='" . $option_mapping_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "',type='" . $type . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_3_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }

    public function save_step3_four() {
        //debug($this->data);die;
        if (!empty($this->data)) {
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {

                    $main_question_id = $this->data['quiz']['main_question_id'];

                    $type = '4';

                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $option_mapping_id = $key;

                    $spatial_scanning_q_select = $this->exam->query("select * from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and sp_question_id='" . $main_question_id . "' and option_mapping_id = '" . $option_mapping_id . "' and type='" . $type . "'");
                    $spatial_scanning_q_select = parent::getData('SpatialScanning', $spatial_scanning_q_select);

                    if (empty($spatial_scanning_q_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_3_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',sp_question_id='" . $main_question_id . "',option_mapping_id='" . $option_mapping_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "',type='" . $type . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_3_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_3_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and sp_question_id='" . $main_question_id . "' and option_mapping_id='" . $option_mapping_id . "' and type='" . $type . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }
    
    public function save_step4() {
//        debug($this->data);die;
        if (!empty($this->data)) {
//            debug($this->data);die;
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {
                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $question_id = $key;

                    $selective_exam_select = $this->exam->query("select * from exam_section_4_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and info_question_id='" . $question_id . "'");
                    $selective_exam_select = parent::getData('SelectiveTest', $selective_exam_select);

                    if (empty($selective_exam_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_4_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',info_question_id='" . $question_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_4_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and info_question_id='" . $question_id . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_4_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and info_question_id='" . $question_id . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }
    
    public function save_step5() {
        if (!empty($this->data)) {
//            debug($this->data);die;
            if (isset($this->data['quiz']['answer']) && !empty($this->data['quiz']['answer'])) {
                foreach ($this->data['quiz']['answer'] as $key => $correct_answers) {
                    $correct_answer = $correct_answers;
//                    $key_another = 'question_options'.$key;
                    $given_answer = $this->data['quiz']['question_options'][$key];
//                    if($given_answer != ''){
//                    debug($given_answer);

                    $exam_web_id = 'SAM-EXAM-1-0001';
                    $user_id = '1';
                    $table_id = '1';
                    $question_id = $key;

                    $selective_exam_select = $this->exam->query("select * from exam_section_5_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'and p_question_id='" . $question_id . "'");
                    $selective_exam_select = parent::getData('SelectiveTest', $selective_exam_select);

                    if (empty($selective_exam_select)) {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $exam_save_inserted = $this->exam->query("insert into exam_section_5_mappings set table_id = '" . $table_id . "',exam_web_id='" . $exam_web_id . "',user_id='" . $user_id . "',p_question_id='" . $question_id . "',correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "'");
                        }
                    } else {
                        if ($given_answer != '') {
                            if ($correct_answer == $given_answer) {
                                $correct = 'Yes';
                            } else {
                                $correct = 'No';
                            }
                            $intelligence_exam_select = $this->exam->query("update exam_section_5_mappings set correct_answer='" . $correct_answer . "',given_answer='" . $given_answer . "',correct='" . $correct . "' where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and p_question_id='" . $question_id . "'");
                        } else {
                            $intelligence_exam_select = $this->exam->query("delete from exam_section_5_mappings where table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "' and p_question_id='" . $question_id . "'");
                        }
                    }
//                }
                }
            }


//            debug($this->data['quiz']['answer']);die;
            if (isset($this->data['quiz']['form_type']) && $this->data['quiz']['form_type'] == 0) {
                echo "success";
                die;
            } else {
                $step1_marks = $this->exam->query("select count(*) AS count from exam_section_1_mappings where correct = 'Yes' and table_id = '" . $table_id . "' and exam_web_id='" . $exam_web_id . "' and user_id='" . $user_id . "'");
                $intelligence_exam_result = parent::getData('IntelligenceTestResult', $step1_marks);
                //debug($intelligence_exam_result['IntelligenceTestResult']['count']);die;
                if (!empty($intelligence_exam_result) && isset($intelligence_exam_result['IntelligenceTestResult']['count'])) {
                    $i_marks = $intelligence_exam_result['IntelligenceTestResult']['count'];
                } else {
                    $i_marks = 0;
                }
                $this->redirect(array("controller" => "quizzes", "action" => "third"));
            }
        }
    }
    
    
    
    public function randomQuestionKey($count_questions) {
        return rand(0, $count_questions);
    }
    
    
    public function timeover_intelligence_test_instruction() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "intelligence_test"));
        }
    }
    
    public function timeover_intelligence_test_main() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "selective_attension_test_instructions"));
        }
    }

    public function timeover_selective_test_instruction() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "selective_test"));
        }
    }
    
    public function timeover_selective_test_main() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "spatial_scanning_test_instructions"));
        }
    }

    public function timeover_spatial_scanning_instruction() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "spatial_scanning1"));
        }
    }
    
    public function timeover_spatial_scanning_test_main() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "information_ordering_test_instructions"));
        }
    }

    public function timeover_info_ordering_test_instruction() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "information_ordering_test"));
        }
    }
    
    public function timeover_information_ordering_test() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "personality_test_instructions"));
        }
    }
    
    public function timeover_personality_test_instruction() {
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "personality_test"));
        }
    }
    
    

    

    public function intelligence_test() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT *FROM intelligent_questions ORDER BY RAND() LIMIT 35");
        $intelligent_questions = parent::getDataAll('IntelligentQuestions', $exams);
        $count_questions = count($intelligent_questions);
        $this->set("intelligent_questions", $intelligent_questions);
    }
    
    public function selective_test() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT * FROM selective_attension_questions ORDER BY RAND() LIMIT 30");
//        $exams = $this->exam->query("SELECT * FROM selective_attension_questions where i_question_id = '1'");
        $selective_questions = parent::getDataAll('SelectiveQuestions', $exams);
        //debug($intelligent_questions);
        $count_questions = count($selective_questions);
        $this->set("selective_questions", $selective_questions);
    }
    

    public function spatial_scanning1() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT * FROM spatial_scanning_questions ORDER BY RAND() LIMIT 1");
        $spatial_scanning_q_details = parent::getData('SpatialScanningQuestions', $exams);
        if (!empty($spatial_scanning_q_details)) {

            $this->set("spatial_scanning_q_details", $spatial_scanning_q_details);

            $sp_question_id = $spatial_scanning_q_details['SpatialScanningQuestions']['sp_question_id'];

            $sp_questions = $this->exam->query("SELECT * FROM sp_question_option_mappings where sp_question_id = '" . $sp_question_id . "'");
            $sp_questions = parent::getDataAll('SpatialScanningOptionQuestions', $sp_questions);
            if (!empty($sp_questions)) {
                $this->set("sp_option_questions", $sp_questions);
            }
        }
    }

    public function spatial_scanning2() {
        parent::checkLoginUser();
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "spatial_scanning2"));
        } else {
            $exams = $this->exam->query("SELECT * FROM spatial_scanning_questions ORDER BY RAND() LIMIT 1");
            $spatial_scanning_q_details = parent::getData('SpatialScanningQuestions', $exams);
            if (!empty($spatial_scanning_q_details)) {

                $this->set("spatial_scanning_q_details", $spatial_scanning_q_details);

                $sp_question_id = $spatial_scanning_q_details['SpatialScanningQuestions']['sp_question_id'];

                $sp_questions = $this->exam->query("SELECT * FROM sp_question_option_mappings where sp_question_id = '" . $sp_question_id . "'");
                $sp_questions = parent::getDataAll('SpatialScanningOptionQuestions', $sp_questions);
                if (!empty($sp_questions)) {
                    $this->set("sp_option_questions", $sp_questions);
                }
            }
        }
    }

    public function spatial_scanning3() {
        parent::checkLoginUser();
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "spatial_scanning3"));
        } else {
            $exams = $this->exam->query("SELECT * FROM spatial_scanning_questions ORDER BY RAND() LIMIT 1");
            $spatial_scanning_q_details = parent::getData('SpatialScanningQuestions', $exams);
            if (!empty($spatial_scanning_q_details)) {

                $this->set("spatial_scanning_q_details", $spatial_scanning_q_details);

                $sp_question_id = $spatial_scanning_q_details['SpatialScanningQuestions']['sp_question_id'];

                $sp_questions = $this->exam->query("SELECT * FROM sp_question_option_mappings where sp_question_id = '" . $sp_question_id . "'");
                $sp_questions = parent::getDataAll('SpatialScanningOptionQuestions', $sp_questions);
                if (!empty($sp_questions)) {
                    $this->set("sp_option_questions", $sp_questions);
                }
            }
        }
    }
    
    public function spatial_scanning4() {
        parent::checkLoginUser();
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            $this->redirect(array("controller" => "quizzes", "action" => "spatial_scanning4"));
        } else {
            $exams = $this->exam->query("SELECT * FROM spatial_scanning_questions ORDER BY RAND() LIMIT 1");
            $spatial_scanning_q_details = parent::getData('SpatialScanningQuestions', $exams);
            if (!empty($spatial_scanning_q_details)) {

                $this->set("spatial_scanning_q_details", $spatial_scanning_q_details);

                $sp_question_id = $spatial_scanning_q_details['SpatialScanningQuestions']['sp_question_id'];

                $sp_questions = $this->exam->query("SELECT * FROM sp_question_option_mappings where sp_question_id = '" . $sp_question_id . "'");
                $sp_questions = parent::getDataAll('SpatialScanningOptionQuestions', $sp_questions);
                if (!empty($sp_questions)) {
                    $this->set("sp_option_questions", $sp_questions);
                }
            }
        }
    }

    public function information_ordering_test() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT *FROM information_ordering_questions ORDER BY RAND() LIMIT 25");
        $info_ordering_questions = parent::getDataAll('InformationOrderingQuestions', $exams);
        $count_questions = count($info_ordering_questions);
        $this->set("info_ordering_questions", $info_ordering_questions);
    }
    
    public function personality_test() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT * FROM personality_test_questions ORDER BY RAND() LIMIT 36");
        $personality_questions = parent::getDataAll('PersonalityQuestions', $exams);
        $count_questions = count($personality_questions);
        $this->set("personality_questions", $personality_questions);
    }

   

    

   

    public function test1_instruction() {
        
    }

    public function selective_instructions() {
        parent::checkLoginUser();
    }

    public function intelligence_test_instructions() {
        parent::checkLoginUser();
    }
    
    public function selective_attension_test_instructions() {
        parent::checkLoginUser();
    }
    
    public function spatial_scanning_test_instructions() {
        parent::checkLoginUser();
    }
    
    public function information_ordering_test_instructions() {
        parent::checkLoginUser();
    }
    
    public function personality_test_instructions() {
        parent::checkLoginUser();
    }
    

    public function spatial_scanning_test() {
        parent::checkLoginUser();
        $exams = $this->exam->query("SELECT * FROM selective_attension_questions ORDER BY RAND() LIMIT 30");
//        $exams = $this->exam->query("SELECT * FROM selective_attension_questions where i_question_id = '1'");
        $selective_questions = parent::getDataAll('SelectiveQuestions', $exams);
        //debug($intelligent_questions);
        $count_questions = count($selective_questions);
        $this->set("selective_questions", $selective_questions);
    }

}

?>
