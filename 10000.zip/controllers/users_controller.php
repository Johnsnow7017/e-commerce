<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class UsersController extends AppController {
    var $name = 'Users';
	//var $name = 'Suppliers';
    var $components = array('Auth'); 
     
    //var $name = 'Users';

    var $uses = array("exam","intelligent_question","User");
	
    
    public function index() {
    
        
    }
//    public function register(){
////        $this->layout = "admin";
////        $exams = $this->exam->query("select * from exams");
////        $exams = parent::getDataAll('Exam', $exams);
////        $this->set("exams",$exams);
//        if(!empty($this->data)){
//            
//            debug($this->data);die;
//        }
//    }
    function register() {
        if (!empty($this->data)){
//            debug($this->data);die;
            $this->data['user']['password'] = security::hash($this->data['user']['password'], "", true);
            $this->data['user']['type'] = 'Student';
            $this->data['user']['status'] = 'Active';
            $this->data['user']['created_date'] = date('Y-m-d H:m:s');
            $this->data['user']['modified_date'] = date('Y-m-d H:m:s');
            $this->User->create();
            if ($this->User->save($this->data['user'])) {
                
            }
        }
    }
    
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow("register","intelligence_test","login","logout_user");
    }
    
    function login(){
        if(!empty($this->data)) {
            $hashedPassword = Security::hash($this->data['user']['password'], NULL, true);
            $username = $this->data['user']['username'];
            $user_detail = $this->exam->query("select * from users where username = '".$username."' and password = '".$hashedPassword."'");
            $user_detail = parent::getData('User', $user_detail);
            if(!empty($user_detail)){
                $this->Session->renew();
                $this->Session->write("AuthUser", $user_detail);
                $this->redirect(array("controller" => "quizzes", "action" => "index"));
            }
            //debug($user_detail);die;
        }
    }
    
    public function logout_user(){
        //$session = $this->request->session();
        $this->Session->delete('AuthUser');
        $this->redirect(array("controller" => "users", "action" => "login"));
    }
    
    
//    public function third(){
//        
//    }
}

?>
