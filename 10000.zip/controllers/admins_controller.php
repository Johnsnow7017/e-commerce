<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of actions_controller
 *
 * @author Brajendra
 */
class AdminsController extends AppController {
//    var $name = 'Actions';
	//var $name = 'Suppliers';
    var $uses = array("exam","intelligent_question");
	public function beforeFilter() {
            parent::beforeFilter();
            $this->Auth->allow("exam_list","add_exam","add_question","getQuestionType");
	}
    
    public function index() {
    
        
    }
    public function exam_list(){
        $this->layout = "admin";
        $exams = $this->exam->query("select * from exams");
        $exams = parent::getDataAll('Exam', $exams);
        $this->set("exams",$exams);
    }
    public function add_exam(){
        $this->layout = "admin";
        if(!empty($this->data)){
            if(isset($this->data['admin']['exam_name']) && trim($this->data['admin']['exam_name']) != ''){
                $exam_name = trim($this->data['admin']['exam_name']);
                $exam_desc = trim($this->data['admin']['exam_description']);
                $group_id = $this->data['admin']['Group'];
                
                $exams = $this->exam->query("select * from exams where name = '".$exam_name."'");
                $exams = parent::getData('Exam', $exams);
                if(empty($exams)){
                    $exam_inserted = $this->exam->query("insert into exams set name = '".$exam_name."',description='".$exam_desc."',group_id='".$group_id."'");
                    //debug($exam_inserted);die;
                    if($exam_inserted){
                        //$this->_flash('Success!!! Account has been created.', "success");
                        $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                    }
                } else {
                    //Kindly choose another name
                }
                //debug($exams);die;

                
            } else {
                
            }
        }
        
    }
    public function add_question(){
        $this->layout = "admin";
        $question_desc = $this->data['admin']['exam_description'];
        $question_type = $this->data['admin']['question_type'];
        if($question_type == "intelligence_test"){
            if($this->data['answer'] != ''){
                $question_inserted = $this->exam->query("insert into intelligent_questions set question_desc = '".$question_desc."',question_type='".$question_type."',correct_answer='".$this->data['answer']."'");
                if($question_inserted){
                    $question_id = mysql_insert_id();
                    //$fileprefix = $this->data['admin']['file']['name'];
                    $filename = str_replace(' ', '_', $this->data['admin']['file']['name']);
                    $fileprefix = $question_id . "_" . time() . "_" . rand(1, 10000) . "_" . $filename;
                    $folder = 'upload/intelligence_test_questions';
                    $folder_url = WWW_ROOT.$folder;
                    $rel_url = $folder;
                    if(!is_dir($folder_url)) {
                        mkdir($folder_url);
                    }
                    if(!file_exists($folder_url.'/'.$fileprefix)) {
                        $full_url = $folder_url.'/'.$fileprefix;
                        $url = $rel_url.'/'.$fileprefix;
                        $success = move_uploaded_file($this->data['admin']['file']['tmp_name'], $url);
                        if($success){
                            $question_img_update = $this->exam->query("update intelligent_questions set question_img_path = '".$fileprefix."' where i_question_id='".$question_id."'");
                            if($question_img_update){
                                $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                            } else {
                                
                            }
                        }
                    } else {
                        //error - This file already exists
                    }
                }
            }
        } elseif($question_type == "selective_attension_test"){ 
            if($this->data['answer'] != ''){
                
                $question_inserted = $this->exam->query("insert into selective_attension_questions set question_desc = '".$question_desc."',question_type='".$question_type."',option_a='".$this->data['option_a']."',option_b='".$this->data['option_b']."',option_c='".$this->data['option_c']."',option_d='".$this->data['option_d']."',option_e='".$this->data['option_e']."',correct_answer='".$this->data['answer']."'");
                if($question_inserted){
                    $question_id = mysql_insert_id();
                    //$fileprefix = $this->data['admin']['file']['name'];
                    $filename = str_replace(' ', '_', $this->data['admin']['file']['name']);
                    $fileprefix = $question_id . "_" . time() . "_" . rand(1, 10000) . "_" . $filename;
                    $folder = 'upload/selective_attension_test_questions';
                    $folder_url = WWW_ROOT.$folder;
                    $rel_url = $folder;
                    if(!is_dir($folder_url)) {
                        mkdir($folder_url);
                    }
                    if(!file_exists($folder_url.'/'.$fileprefix)) {
                        $full_url = $folder_url.'/'.$fileprefix;
                        $url = $rel_url.'/'.$fileprefix;
                        $success = move_uploaded_file($this->data['admin']['file']['tmp_name'], $url);
                        if($success){
                            $question_img_update = $this->exam->query("update selective_attension_questions set question_img_path = '".$fileprefix."' where se_question_id='".$question_id."'");
                            if($question_img_update){
                                $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                            } else {
                                
                            }
                        }
                    } else {
                        //error - This file already exists
                    }
                }
            }
        } elseif($question_type == "spatial_scanning_test"){
            if(isset($this->data['question_answer_special_scanning']) && !empty($this->data['question_answer_special_scanning'])){
                $all_answers = 'yes';
                foreach($this->data['question_answer_special_scanning'] as $ans){
                    if($ans == 0){
                        $all_answers = 'no';
                    }
                }
                if($all_answers == 'yes'){
                    $question_inserted = $this->exam->query("insert into spatial_scanning_questions set question_desc = '".$question_desc."',question_type='".$question_type."'");
                    if($question_inserted){
                        $sp_question_id = mysql_insert_id();
                        for($i=0;$i<10;$i++){
                            $shortest_route = $this->data['shortest_route'][$i];
                            $option_a = $this->data['option_a'][$i];
                            $option_b = $this->data['option_b'][$i];
                            $option_c = $this->data['option_c'][$i];
                            $option_d = $this->data['option_d'][$i];
                            $option_e = $this->data['option_e'][$i];
                            $correct_answer = $this->data['question_answer_special_scanning'][$i];
                            $question_mapping_inserted = $this->exam->query("insert into sp_question_option_mappings set sp_question_id = '".$sp_question_id."',shortest_route_from='".$shortest_route."',option_a='".$option_a."',option_b='".$option_b."',option_c='".$option_c."',option_d='".$option_d."',option_e='".$option_e."',correct_answer='".$correct_answer."'");
                        }
                        $filename = str_replace(' ', '_', $this->data['admin']['file']['name']);
                        $fileprefix = $sp_question_id . "_" . time() . "_" . rand(1, 10000) . "_" . $filename;
                        $folder = 'upload/special_scanningquestions';
                        $folder_url = WWW_ROOT.$folder;
                        $rel_url = $folder;
                        if(!is_dir($folder_url)) {
                            mkdir($folder_url);
                        }
                        if(!file_exists($folder_url.'/'.$fileprefix)) {
                            $full_url = $folder_url.'/'.$fileprefix;
                            $url = $rel_url.'/'.$fileprefix;
                            $success = move_uploaded_file($this->data['admin']['file']['tmp_name'], $url);
                            if($success){
                                $question_img_update = $this->exam->query("update spatial_scanning_questions set question_img_path = '".$fileprefix."' where sp_question_id='".$sp_question_id."'");
                                if($question_img_update){
                                    $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                                } else {

                                }
                            }
                        } else {
                            //error - This file already exists
                        }
                    }
                }
                
            }
        } elseif($question_type == "information_ordering_test"){
            if($this->data['answer'] != ''){
                $question_inserted = $this->exam->query("insert into information_ordering_questions set question_desc = '".$question_desc."',question_type='".$question_type."',correct_answer='".$this->data['answer']."'");
                if($question_inserted){
                    $question_id = mysql_insert_id();
                    //$fileprefix = $this->data['admin']['file']['name'];
                    $filename = str_replace(' ', '_', $this->data['admin']['file']['name']);
                    $fileprefix = $question_id . "_" . time() . "_" . rand(1, 10000) . "_" . $filename;
                    $folder = 'upload/information_ordering_questions';
                    $folder_url = WWW_ROOT.$folder;
                    $rel_url = $folder;
                    if(!is_dir($folder_url)) {
                        mkdir($folder_url);
                    }
                    if(!file_exists($folder_url.'/'.$fileprefix)) {
                        $full_url = $folder_url.'/'.$fileprefix;
                        $url = $rel_url.'/'.$fileprefix;
                        $success = move_uploaded_file($this->data['admin']['file']['tmp_name'], $url);
                        if($success){
                            $question_img_update = $this->exam->query("update information_ordering_questions set question_img_path = '".$fileprefix."' where info_question_id='".$question_id."'");
                            if($question_img_update){
                                $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                            } else {
                                
                            }
                        }
                    } else {
                        //error - This file already exists
                    }
                }
            }
        } elseif($question_type == "personality_test"){
            if($this->data['question_answer_prsonality_test'] != ''){
                $option_a = $this->data['option_a'];
                $option_b = $this->data['option_b'];
                $option_c = $this->data['option_c'];
                $option_d = $this->data['option_d'];
                $option_e = $this->data['option_e'];
                $question_inserted = $this->exam->query("insert into personality_test_questions set question_desc = '".$question_desc."',question_type='".$question_type."',correct_answer='".$this->data['question_answer_prsonality_test']."',option_a='".$option_a."',option_b='".$option_b."',option_c='".$option_c."',option_d='".$option_d."',option_e='".$option_e."'");
                if($question_inserted){
                    $question_id = mysql_insert_id();
                    //$fileprefix = $this->data['admin']['file']['name'];
                    $filename = str_replace(' ', '_', $this->data['admin']['file']['name']);
                    $fileprefix = $question_id . "_" . time() . "_" . rand(1, 10000) . "_" . $filename;
                    $folder = 'upload/personality_test';
                    $folder_url = WWW_ROOT.$folder;
                    $rel_url = $folder;
                    if(!is_dir($folder_url)) {
                        mkdir($folder_url);
                    }
                    if(!file_exists($folder_url.'/'.$fileprefix)) {
                        $full_url = $folder_url.'/'.$fileprefix;
                        $url = $rel_url.'/'.$fileprefix;
                        $success = move_uploaded_file($this->data['admin']['file']['tmp_name'], $url);
                        if($success){
                            $question_img_update = $this->exam->query("update personality_test_questions set question_img_path = '".$fileprefix."' where p_question_id='".$question_id."'");
                            if($question_img_update){
                                $this->redirect(array("controller" => "admins", "action" => "exam_list"));
                            } else {
                                
                            }
                        }
                    } else {
                        //error - This file already exists
                    }
                }
            }
        }
    }
    public function getQuestionType(){
        $this->layout = false;
        if (isset($_POST) && $_POST["question_type"] != "") {
            $question_type = $_POST["question_type"];
            $this->set("question_type",$question_type);
            
        }
    }
    

    public function timeover(){
        if (isset($this->params['named']['step']) && $this->params['named']['step'] != '') {
            debug($this->params['named']['step']);
            debug("d");die;
        }
    }
    public function exam_instruction(){}
    
    public function exam_instruction_next(){}
    
    public function test1_instruction(){}
    
//    public function third(){
//        
//    }
}

?>
