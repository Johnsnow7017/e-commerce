<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of action
 *
 * @author Brajendra
 */
class Quiz extends AppModel {
     var $name = 'quizzes';
}

?>