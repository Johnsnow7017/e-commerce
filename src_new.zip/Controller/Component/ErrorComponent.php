<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use Cake\Event\Event;
use Cake\Routing\Router;
use Cake\Utility\Hash;
use Cake\ORM\TableRegistry;

/**
 * Error component
 */
class ErrorComponent extends Component {

    public function getError($code, $codeShow = true) {
        $errors_reg = TableRegistry::get('errors');
        $error_details = $errors_reg->find('all')->where(['error_code' => $code]);
        $error = $this->getResultArray('Error', $error_details);
        if ($codeShow == true) {
            if ($error) {
                return "Error No. " . $code . ": " . $error["Error"]["error_description"];
            } else {
                return $code;
            }
        } else {
            if ($error) {
                return $error["Error"]["error_description"];
            } else {
                return $code;
            }
        }
    }

    public function getMessage($code) {
        $errors_reg = TableRegistry::get('errors');
        $error_details = $errors_reg->find('all')->where(['error_code' => $code]);
        $error = $this->getResultArray('Error', $error_details);
        if ($error) {
            return $error["Error"]["error_description"];
        } else {
            return $code;
        }
    }

    function getResultArray($model, $query) {
        $query->hydrate(false);
        $result = $query->toList();
        $final_result = array();
        $i = 0;
        if (count($result) == 1) {
            $final_result[$model] = $result[0];
        } else {
            foreach ($result as $res) {
                $final_result[$i][$model] = $res;
                $i++;
            }
        }
        return $final_result;
    }

}
