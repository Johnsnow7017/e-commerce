var formchanges = false;
/* Tipsy */
$(function(){
    $('.tips').tipsy({
        gravity: 's',
        html: true
    });
});
$(function(){
    $('.tips-right').tipsy({
        gravity: 'w',
        html: true
    });
});
$(function(){
    $('.tips-left').tipsy({
        gravity: 'e',
        html: true
    });
});
$(function(){
    $('.tips-bottom').tipsy({
        gravity: 'n',
        html: true
    });
});


/* Ie7 z-index fix */
/*
$(function() {
    var zIndexNumber = 10000;
    $('div').each(function() {
        $(this).css('zIndex', zIndexNumber);
        zIndexNumber -= 10;
    });
});
*/


/* Form Style */
$(function(){
    if(top.location != self.location) {
      top.location = self.location;
    }
    $(".st-forminput").focus(function(){

        //$(this).attr('class','st-forminput-active ');

    });

    $(".st-forminput").blur(function(){

        //$(this).attr('class','st-forminput');

    });

});




/* Login Input Form */
$(function(){

    $(".login-input-pass").focus(function(){

        $(this).attr('class','login-input-pass-active ');

    });

    $(".login-input-pass").blur(function(){

        $(this).attr('class','login-input-pass');

    });

});
$(function(){

    $(".login-input-user").focus(function(){

        $(this).attr('class','login-input-user-active ');

    });

    $(".login-input-user").blur(function(){

        $(this).attr('class','login-input-user');

    });

});




/* Uniform */
$(function(){
    $(".uniform").uniform();
});


/* jWYSIWYG editor */
$(function()
{
    //$('.wysiwyg').wysiwyg();
});


/* Table Shorter */
$(document).ready(function() 
{ 
    // $("#myTable").tablesorter();
    } 
    );




/* Full Calendar */

$(document).ready(function() {
	
    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();
		
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,basicWeek,basicDay'
        },
        editable: true,
        events: [
        {
            title: 'All Day Event',
            start: new Date(y, m, 1)
        },
        {
            title: 'Long Event',
            start: new Date(y, m, d-5),
            end: new Date(y, m, d-2)
        },
        {
            id: 999,
            title: 'Repeating Event',
            start: new Date(y, m, d-3, 16, 0),
            allDay: false
        },
        {
            id: 999,
            title: 'Repeating Event',
            start: new Date(y, m, d+4, 16, 0),
            allDay: false
        },
        {
            title: 'Meeting',
            start: new Date(y, m, d, 10, 30),
            allDay: false
        },
        {
            title: 'Lunch',
            start: new Date(y, m, d, 12, 0),
            end: new Date(y, m, d, 14, 0),
            allDay: false
        },
        {
            title: 'Birthday Party',
            start: new Date(y, m, d+1, 19, 0),
            end: new Date(y, m, d+1, 22, 30),
            allDay: false
        },
        {
            title: 'Click for Google',
            start: new Date(y, m, 28),
            end: new Date(y, m, 29),
            url: 'http://google.com/'
        }
        ]
    });
		
});




/* iphone style switches */
$(document).ready( function(){ 
    $(".cb-enable").click(function(){
        var parent = $(this).parents('.switch');
        $('.cb-disable',parent).removeClass('selected');
        $(this).addClass('selected');
        $('.checkbox',parent).attr('checked', true);
    });
    $(".cb-disable").click(function(){
        var parent = $(this).parents('.switch');
        $('.cb-enable',parent).removeClass('selected');
        $(this).addClass('selected');
        $('.checkbox',parent).attr('checked', false);
    });
});


function saveDraftFunction(saveURL, formId) {
    $("a").bind("click", function() {
        if(!$(this).hasClass('editQuotation')){
            var hrefLink = $(this).attr("href");
            if(hrefLink != "" && hrefLink != "javascript://" && hrefLink != "#" && hrefLink != undefined) {
                if(safesubmit == true) {
                    return true;
                }else {
                    $("#confirmationdiv").dialog({
                        width: 300,
                        height: 130,
                        modal: true,
                        title: "RFX Draft",
                        open: function() {
                            $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Do you want to save the draft ?</a>");
                        },
                        buttons:
                        {
                            "Yes": function() {
                                if(saveURL != "") {
                                    $.ajax({
                                        type: 'POST',
                                        async: false,
                                        url: saveURL,
                                        data: $("#" + formId).serialize()
                                    });
                                }
                                if(hrefLink != "" && hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            },
                            "No": function() {
                                if(hrefLink != "" && hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            }
                        }
                    });
                    return false;
                }
            }
        }
        
    });
}

function saveDraftConfirmation(saveURL, cancelURL, formId) {
    /*
    $("a").bind("click", function() {
        alert(formchanges);
        return false;
    });
    */	
    $("a").bind("click", function() {
        if($(this).hasClass('ignorlink')) {
            return true;
        } else if($(this).hasClass('editQuotation')) {
            return true;
        } else {
            var hrefLink = $(this).attr("href");
            if(hrefLink != "" && hrefLink != "javascript://" && hrefLink != "#" && hrefLink != undefined) {
                $(".simple-tips").remove();
                if(formId == 'createstep') {
                    if($(this).hasClass('rfxstep')) {
                        if($("#RfxRfxName").val() == "") {
                            $("#RfxRfxName").addClass("st-error-input");
                            $("#RfxRfxName").removeClass("st-forminput");
                            if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                $("#RfxRfxName").parent().find(".fielderror").html("RFX Name already used in previous RFX");
                            } else {
                                $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name already used in previous RFX</div>");
                            }
                            $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! RFX Name cannot be blank. Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                            $(".albox .close").click(function(event){
                                $(this).parents(".albox").slideUp();
                                return false;
                            });
                        } else {
                            $.ajax({
                                type: 'POST',
                                async: false,
                                dataType: 'json',
                                data: "name=" + $("#RfxRfxName").val(),
                                url: pageURL + 'rfx/getRfxname/rfxid:' + $("#rfxid").val(),
                                success: function(response) {
                                    if(response.status == "Yes") {
                                        $("#RfxRfxName").addClass("st-error-input");
                                        $("#RfxRfxName").removeClass("st-forminput");
                                        if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                            $("#RfxRfxName").parent().find(".fielderror").html("RFX Name already used in previous RFX");
                                        } else {
                                            $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name already used in previous RFX</div>");
                                        }
                                        $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! RFX name is already in use in a previous RFX.  Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                        $(".albox .close").click(function(event){
                                            $(this).parents(".albox").slideUp();
                                            return false;
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            url: saveURL,
                                            data: $("#" + formId).serialize(),
                                            success: function(response) {
                                                jsondata = $.parseJSON(response);
                                                if(jsondata.type == 'false'){
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });


                                                } else{
                                                    if(hrefLink != "" && hrefLink != "javascript://") {
                                                      document.location.href = hrefLink;
                                                    }
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    } else {
                        $("#confirmationdiv").dialog({
                            width: 330,
                            height: 160,
                            modal: true,
                            title: "RFX Save",
                            open: function() {
                                $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Do you want to save the RFX as draft?</a>");
                            },
                            buttons:
                            {
                                "Yes": function() {
                                    dialogbox = $(this);
                                    dialogbox.dialog("close");
                                    if($("#RfxRfxName").val() == "") {
                                        $("#RfxRfxName").addClass("st-error-input");
                                        $("#RfxRfxName").removeClass("st-forminput");
                                        if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                            $("#RfxRfxName").parent().find(".fielderror").html("RFX Name can not be blank");
                                        } else {
                                            $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name can not be blank</div>");
                                        }
                                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! RFX Name cannot be blank. Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                        $(".albox .close").click(function(event){
                                            $(this).parents(".albox").slideUp();
                                            return false;
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            dataType: 'json',
                                            data: "name=" + $("#RfxRfxName").val(),
                                            url: pageURL + 'rfx/getRfxname/rfxid:' + $("#rfxid").val(),
                                            success: function(response) {
                                                if(response.status == "Yes") {
                                                    $("#RfxRfxName").addClass("st-error-input");
                                                    $("#RfxRfxName").removeClass("st-forminput");
                                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                                        $("#RfxRfxName").parent().find(".fielderror").html("RFX Name already used in previous RFX");
                                                    } else {
                                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name already used in previous RFX</div>");
                                                    }
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! RFX name is already in use in a previous RFX.  Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                } else {
                                                    $.ajax({
                                                        type: 'POST',
                                                        async: false,
                                                        url: saveURL,
                                                        data: $("#" + formId).serialize(),
                                                        success: function(response) {
                                                            jsondata = $.parseJSON(response);
                                                            if(jsondata.type == 'false'){
                                                                $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                                $(".albox .close").click(function(event){
                                                                    $(this).parents(".albox").slideUp();
                                                                    return false;
                                                                });
                                                                dialogbox.dialog("close");

                                                            } else{
                                                                if(hrefLink != "" && hrefLink != "javascript://") {
                                                                  document.location.href = hrefLink;
                                                                }
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    }

                                },
                                "No": function() {
                                    document.location.href = hrefLink;
                                }
                            }
                        })
                    }
                } else if(formId == "step1" && $("#RfxRfxName").val() != undefined && $("#RfxRfxName").val() == "") {
                    $("#RfxRfxName").addClass("st-error-input");
                        $("#RfxRfxName").removeClass("st-forminput");
                        if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                            $("#RfxRfxName").parent().find(".fielderror").html("RFX Name can not be blank");
                        } else {
                            $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name can not be blank</div>");
                        }
                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! RFX Name cannot be blank. Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                        $(".albox .close").click(function(event){
                            $(this).parents(".albox").slideUp();
                            return false;
                        });
                } else if(formId == "step5") {
                    if(fileUploadCount != undefined) {
                        if(fileUploadCount > 0) {
                            $("#confirmationdiv").dialog({
                                width: 330,
                                height: 160,
                                modal: true,
                                title: "RFX Save",
                                open: function() {
                                    $("#confirmationdiv").html("<div align='center' style='padding: 10px'>File uploads are in progress. Upload progess will be stopped. Are you sure to navigate away?</a>");
                                },
                                buttons:
                                {
                                    "Yes": function() {
                                        if(hrefLink != "" || hrefLink != "javascript://") {
                                            document.location.href = hrefLink;
                                        }
                                    },
                                    "No": function() {
                                        $(this).dialog("close");
                                    }
                                }
                            });
                        } else {
                            if(hrefLink != "" || hrefLink != "javascript://") {
                                document.location.href = hrefLink;
                            }
                        }
                    }
                } else if(formchanges == true) {
                    $("#confirmationdiv").dialog({
                        width: 330,
                        height: 160,
                        modal: true,
                        title: "RFX Save",
                        open: function() {
                            $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Some modification has been done in the form. Do you want to save the changes ?</a>");
                        },
                        buttons:
                        {
                            "Yes": function() {
                                dialogbox = $(this);
                                if(formId == "step1" && $("#RfxRfxName").val() == "") {
                                    $("#RfxRfxName").addClass("st-error-input");
                                    $("#RfxRfxName").removeClass("st-forminput");
                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                        $("#RfxRfxName").parent().find(".fielderror").html("RFX Name can not be blank");
                                    } else {
                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name can not be blank</div>");
                                    }
                                    $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! RFX Name cannot be blank. Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                    $(".albox .close").click(function(event){
                                        $(this).parents(".albox").slideUp();
                                        return false;
                                    });
                                    dialogbox.dialog("close");
                                } else {
                                    if(formId == "step1") {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            dataType: 'json',
                                            data: "name=" + $("#RfxRfxName").val(),
                                            url: pageURL + 'rfx/getRfxname/rfxid:' + $("#rfxid").val(),
                                            success: function(response) {
                                                if(response.status == "Yes") {
                                                    $("#RfxRfxName").addClass("st-error-input");
                                                    $("#RfxRfxName").removeClass("st-forminput");
                                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                                        $("#RfxRfxName").parent().find(".fielderror").html("RFX Name already used in previous RFX");
                                                    } else {
                                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>RFX Name already used in previous RFX</div>");
                                                    }
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! RFX name is already in use in a previous RFX.  Please input a unique RFX name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    dialogbox.dialog("close");
                                                } else {
                                                    $.ajax({
                                                        type: 'POST',
                                                        async: false,
                                                        url: saveURL,
                                                        data: $("#" + formId).serialize(),
                                                        success: function(response) {
                                                            if(response.indexOf("csrf") > -1){
                                                                
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                            jsondata = $.parseJSON(response);
                                                            
                                                            if(jsondata.type == 'false'){
                                                                $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                                $(".albox .close").click(function(event){
                                                                    $(this).parents(".albox").slideUp();
                                                                    return false;
                                                                });
                                                                dialogbox.dialog("close");

                                                            } else{
                                                                if(hrefLink != "" && hrefLink != "javascript://") {
                                                                    document.location.href = hrefLink;
                                                                }
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            url: saveURL,
                                            data: $("#" + formId).serialize(),
                                            success: function(response) {
                                                if(response.indexOf("csrf") > -1){
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                jsondata = $.parseJSON(response);
                                                if(jsondata.type == 'false'){
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    dialogbox.dialog("close");

                                                } else{
                                                    if(hrefLink != "" && hrefLink != "javascript://") {
                                                        document.location.href = hrefLink;
                                                    }
                                                }
                                            }
                                        });
                                    }
                                }
                            },
                            "No": function() {
                                $(this).dialog("close");
                                if(hrefLink != "" || hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            }
                        }

                    });
                } else {
                    if(hrefLink != "" || hrefLink != "javascript://") {
                        document.location.href = hrefLink;
                    }
                }
                return false;
            }
        }
    });
}

function saveDraftConfirmationAuction(saveURL, cancelURL, formId) {
    /*
    $("a").bind("click", function() {
        alert(formchanges);
        return false;
    });
    */
    $("a").bind("click", function() {
        if($(this).hasClass('ignorlink')) {
            return true;
        } else if($(this).hasClass('editQuotation')) {
            return true;
        } else {
            var hrefLink = $(this).attr("href");
            if(hrefLink != "" && hrefLink != "javascript://" && hrefLink != "#" && hrefLink != undefined) {
                $(".simple-tips").remove();
                if(formId == 'createstep') {
                    if($(this).hasClass('rfxstep')) {
                        if($("#AuctionAuctionName").val() == "") {
                            $("#AuctionAuctionName").addClass("st-error-input");
                            $("#AuctionAuctionName").removeClass("st-forminput");
                            if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name already used in previous Auction");
                            } else {
                                $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name already used in previous Auction</div>");
                            }
                            $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! Auction Name cannot be blank. Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                            $(".albox .close").click(function(event){
                                $(this).parents(".albox").slideUp();
                                return false;
                            });
                        } else {
                            $.ajax({
                                type: 'POST',
                                async: false,
                                dataType: 'json',
                                data: "name=" + $("#RfxRfxName").val(),
                                url: pageURL + 'auctions/getauctionname/auctionid:' + $("#auctionid").val(),
                                success: function(response) {
                                    if(response.status == "Yes") {
                                        $("#AuctionAuctionName").addClass("st-error-input");
                                        $("#AuctionAuctionName").removeClass("st-forminput");
                                        if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                            $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name already used in previous Auction");
                                        } else {
                                            $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name already used in previous Auction</div>");
                                        }
                                        $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! Auction name is already in use in a previous Auction.  Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                        $(".albox .close").click(function(event){
                                            $(this).parents(".albox").slideUp();
                                            return false;
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            url: saveURL,
                                            data: $("#" + formId).serialize(),
                                            success: function(response) { 
                                                if(response.indexOf("csrf") > -1){
                                                                
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                jsondata = $.parseJSON(response);
                                               
                                                if(jsondata.type == 'false'){
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    

                                                } else{
                                                    if(hrefLink != "" && hrefLink != "javascript://") {
                                                      document.location.href = hrefLink;

                                                    }
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    } else {
                        $("#confirmationdiv").dialog({
                            width: 330,
                            height: 160,
                            modal: true,
                            title: "Auction Save",
                            open: function() {
                                $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Do you want to save the Auction as draft?</a>");
                            },
                            buttons:
                            {
                                "Yes": function() {
                                    dialogbox = $(this);
                                    dialogbox.dialog("close");
                                    if($("#AuctionAuctionName").val() == "") {
                                        $("#AuctionAuctionName").addClass("st-error-input");
                                        $("#AuctionAuctionName").removeClass("st-forminput");
                                        if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                            $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name can not be blank");
                                        } else {
                                            $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name can not be blank</div>");
                                        }
                                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! Auction Name cannot be blank. Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                        $(".albox .close").click(function(event){
                                            $(this).parents(".albox").slideUp();
                                            return false;
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            dataType: 'json',
                                            data: "name=" + $("#AuctionAuctionName").val(),
                                            url: pageURL + 'auctions/getauctionname/auctionid:' + $("#auctionid").val(),
                                            success: function(response) {
                                                if(response.status == "Yes") {
                                                    $("#AuctionAuctionName").addClass("st-error-input");
                                                    $("#AuctionAuctionName").removeClass("st-forminput");
                                                    if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                                        $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name already used in previous Auction");
                                                    } else {
                                                        $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name already used in previous Auction</div>");
                                                    }
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! Auction name is already in use in a previous Auction.  Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                } else {
                                                    $.ajax({
                                                        type: 'POST',
                                                        async: false,
                                                        url: saveURL,
                                                        data: $("#" + formId).serialize(),
                                                        success: function(response) {
                                                            if(response.indexOf("csrf") > -1){
                                                                
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                            jsondata = $.parseJSON(response);
                                                            if(jsondata.type == 'false'){
                                                                $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                                $(".albox .close").click(function(event){
                                                                    $(this).parents(".albox").slideUp();
                                                                    return false;
                                                                });
                                                                dialogbox.dialog("close");

                                                            } else{
                                                                if(hrefLink != "" && hrefLink != "javascript://") {
                                                                  document.location.href = hrefLink;
                                                                }
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    }

                                },
                                "No": function() {
                                    document.location.href = hrefLink;
                                }
                            }
                        })
                    }
                } else if(formId == "step1" && $("#AuctionAuctionName").val() != undefined && $("#AuctionAuctionName").val() == "") {
                    $("#AuctionAuctionName").addClass("st-error-input");
                        $("#AuctionAuctionName").removeClass("st-forminput");
                        if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                            $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name can not be blank");
                        } else {
                            $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name can not be blank</div>");
                        }
                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! Auction Name cannot be blank. Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                        $(".albox .close").click(function(event){
                            $(this).parents(".albox").slideUp();
                            return false;
                        });
                } else if(formId == "step4") {
                    if(fileUploadCount != undefined) {
                        if(fileUploadCount > 0) {
                            $("#confirmationdiv").dialog({
                                width: 330,
                                height: 160,
                                modal: true,
                                title: "Auction Save",
                                open: function() {
                                    $("#confirmationdiv").html("<div align='center' style='padding: 10px'>File uploads are in progress. Upload progess will be stopped. Are you sure to navigate away?</a>");
                                },
                                buttons:
                                {
                                    "Yes": function() {
                                        if(hrefLink != "" || hrefLink != "javascript://") {
                                            document.location.href = hrefLink;
                                        }
                                    },
                                    "No": function() {
                                        $(this).dialog("close");
                                    }
                                }
                            });
                        } else {
                            if(hrefLink != "" || hrefLink != "javascript://") {
                                document.location.href = hrefLink;
                            }
                        }
                    }
                } else if(formchanges == true) {
                    $("#confirmationdiv").dialog({
                        width: 330,
                        height: 160,
                        modal: true,
                        title: "Auction Save",
                        open: function() {
                            $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Some modification has been done in the form. Do you want to save the changes ?</a>");
                        },
                        buttons:
                        {
                            "Yes": function() {
                                dialogbox = $(this);
                                if(formId == "step1" && $("#AuctionAuctionName").val() == "") {
                                    $("#AuctionAuctionName").addClass("st-error-input");
                                    $("#AuctionAuctionName").removeClass("st-forminput");
                                    if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                        $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name can not be blank");
                                    } else {
                                        $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name can not be blank</div>");
                                    }
                                    $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry! Auction Name cannot be blank. Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                    $(".albox .close").click(function(event){
                                        $(this).parents(".albox").slideUp();
                                        return false;
                                    });
                                    dialogbox.dialog("close");
                                } else {
                                    if(formId == "step1") {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            dataType: 'json',
                                            data: "name=" + $("#AuctionAuctionName").val(),
                                            url: pageURL + 'auctions/getauctionname/auctionid:' + $("#auctionid").val(),
                                            success: function(response) {
                                                if(response.status == "Yes") {
                                                    $("#AuctionAuctionName").addClass("st-error-input");
                                                    $("#AuctionAuctionName").removeClass("st-forminput");
                                                    if($("#AuctionAuctionName").parent().find(".fielderror").html() != undefined) {
                                                        $("#AuctionAuctionName").parent().find(".fielderror").html("Auction Name already used in previous Auction");
                                                    } else {
                                                        $("#AuctionAuctionName").parent().append("<div class='fielderror' style='color: #99616B'>Auction Name already used in previous Auction</div>");
                                                    }
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry! Auction name is already in use in a previous Auction.  Please input a unique Auction name to navigate away<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    dialogbox.dialog("close");
                                                } else {
                                                    $.ajax({
                                                        type: 'POST',
                                                        async: false,
                                                        url: saveURL,
                                                        data: $("#" + formId).serialize(),
                                                        success: function(response) {
                                                            if(response.indexOf("csrf") > -1){
                                                                
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                            jsondata = $.parseJSON(response);
                                                            if(jsondata.type == 'false'){
                                                                $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                                $(".albox .close").click(function(event){
                                                                    $(this).parents(".albox").slideUp();
                                                                    return false;
                                                                });
                                                                dialogbox.dialog("close");
                                                                
                                                            } else{
                                                                if(hrefLink != "" && hrefLink != "javascript://") {
                                                                    document.location.href = hrefLink;
                                                                }
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            url: saveURL,
                                            data: $("#" + formId).serialize(),
                                            success: function(response) {
                                                if(response.indexOf("csrf") > -1){
                                                                
                                                            alert("Access Denied");
                                                             dialogbox.dialog("close");
                                                            return false;
                                                            }
                                                jsondata = $.parseJSON(response);
                                                if(jsondata.type == 'false'){
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    dialogbox.dialog("close");

                                                }else{
                                                    if(hrefLink != "" && hrefLink != "javascript://") {
                                                        document.location.href = hrefLink;
                                                    }
                                                }
                                            }
                                        });
                                    }
                                }
                            },
                            "No": function() {
                                $(this).dialog("close");
                                if(hrefLink != "" || hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            }
                        }

                    });
                } else {
                    if(hrefLink != "" || hrefLink != "javascript://") {
                        document.location.href = hrefLink;
                    }
                }
                return false;
            }
        }
    });
}

function createConfirmation(saveURL, cancelURL, formId) {
    $("a").bind("click", function() {
        if($(this).hasClass('ignorlink')) {
            return true;
        } else if($(this).hasClass('editQuotation')) {
            return true;
        } else {
            var hrefLink = $(this).attr("href");
            if(hrefLink != "" && hrefLink != "javascript://" && hrefLink != "#" && hrefLink != undefined) {
                $(".simple-tips").remove();
                if(formId == 'createstep') {
                    if($("#RfxRfxName").val() == "") {
                        $("#RfxRfxName").addClass("st-error-input");
                        $("#RfxRfxName").removeClass("st-forminput");
                        if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                            $("#RfxRfxName").parent().find(".fielderror").html("Rfx name can't be blank.");
                        } else {
                            $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>Rfx name can't be blank.</div>");
                        }
                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry!! Rfx name can\'t be blank.<a class="close tips" href="#" original-title="Close">close</a></div>');
                        $(".albox .close").click(function(event){
                            $(this).parents(".albox").slideUp();
                            return false;
                        });
                    } else {
                        $.ajax({
                            type: 'POST',
                            async: false,
                            dataType: 'json',
                            data: "name=" + $("#RfxRfxName").val(),
                            url: pageURL + 'rfx/getRfxname/rfxid:' + $("#rfxid").val(),
                            success: function(response) {
                                if(response.status == "Yes") {
                                    $("#RfxRfxName").addClass("st-error-input");
                                    $("#RfxRfxName").removeClass("st-forminput");
                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                        $("#RfxRfxName").parent().find(".fielderror").html("Rfx name already used in previous rfx.");
                                    } else {
                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>Rfx name already used in previous rfx.</div>");
                                    }
                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry!! Rfx name has been used in previous rfx.<a class="close tips" href="#" original-title="Close">close</a></div>');
                                    $(".albox .close").click(function(event){
                                        $(this).parents(".albox").slideUp();
                                        return false;
                                    });
                                } else {
                                    $.ajax({
                                        type: 'POST',
                                        async: false,
                                        url: saveURL,
                                        data: $("#" + formId).serialize(),
                                        success: function() {
                                            if(hrefLink != "" && hrefLink != "javascript://") {
                                              document.location.href = hrefLink;
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    }
                } else if(formId == "step1" && $("#RfxRfxName").val() != undefined && $("#RfxRfxName").val() == "") {
                    $("#RfxRfxName").addClass("st-error-input");
                        $("#RfxRfxName").removeClass("st-forminput");
                        if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                            $("#RfxRfxName").parent().find(".fielderror").html("Rfx name can't be blank.");
                        } else {
                            $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>Rfx name can't be blank.</div>");
                        }
                        $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry!! Rfx name can\'t be blank.<a class="close tips" href="#" original-title="Close">close</a></div>');
                        $(".albox .close").click(function(event){
                            $(this).parents(".albox").slideUp();
                            return false;
                        });
                } else if(formchanges == true) {
                    $("#confirmationdiv").dialog({
                        width: 330,
                        height: 160,
                        modal: true,
                        title: "RFX Save",
                        open: function() {
                            $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Some modification has been done in the form. Do you want to save the changes ?</a>");
                        },
                        buttons:
                        {
                            "Yes": function() {
                                dialogbox = $(this);
                                if(formId == "step1" && $("#RfxRfxName").val() == "") {
                                    $("#RfxRfxName").addClass("st-error-input");
                                    $("#RfxRfxName").removeClass("st-forminput");
                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                        $("#RfxRfxName").parent().find(".fielderror").html("Rfx name can't be blank.");
                                    } else {
                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>Rfx name can't be blank.</div>");
                                    }
                                    $(".simplebox").prepend('<div class="simple-tips albox errorbox" style="z-index: 690;">Sorry!!! Rfx name can\'t be blank. Please enter the rfx name to navigate away.<a class="close tips" href="#" original-title="Close">close</a></div>');
                                    $(".albox .close").click(function(event){
                                        $(this).parents(".albox").slideUp();
                                        return false;
                                    });
                                    dialogbox.dialog("close");
                                } else {
                                    if(formId == "step1") {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            dataType: 'json',
                                            data: "name=" + $("#RfxRfxName").val(),
                                            url: pageURL + 'rfx/getRfxname/rfxid:' + $("#rfxid").val(),
                                            success: function(response) {
                                                if(response.status == "Yes") {
                                                    $("#RfxRfxName").addClass("st-error-input");
                                                    $("#RfxRfxName").removeClass("st-forminput");
                                                    if($("#RfxRfxName").parent().find(".fielderror").html() != undefined) {
                                                        $("#RfxRfxName").parent().find(".fielderror").html("Rfx name already used in previous rfx.");
                                                    } else {
                                                        $("#RfxRfxName").parent().append("<div class='fielderror' style='color: #99616B'>Rfx name already used in previous rfx.</div>");
                                                    }
                                                    $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">Sorry!! Rfx name has been used in previous rfx. Please enter the unique rfx name to navigate away.<a class="close tips" href="#" original-title="Close">close</a></div>');
                                                    $(".albox .close").click(function(event){
                                                        $(this).parents(".albox").slideUp();
                                                        return false;
                                                    });
                                                    dialogbox.dialog("close");
                                                } else {
                                                    $.ajax({
                                                        type: 'POST',
                                                        async: false,
                                                        url: saveURL,
                                                        data: $("#" + formId).serialize(),
                                                        success: function() {
                                                            if(hrefLink != "" && hrefLink != "javascript://") {
                                                                document.location.href = hrefLink;
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    } else {
                                        $.ajax({
                                            type: 'POST',
                                            async: false,
                                            url: saveURL,
                                            data: $("#" + formId).serialize(),
                                            success: function() {
                                                if(hrefLink != "" && hrefLink != "javascript://") {
                                                    document.location.href = hrefLink;
                                                }
                                            }
                                        });
                                    }
                                }
                            },
                            "No": function() {
                                $(this).dialog("close");
                                if(hrefLink != "" || hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            }
                        }

                    });
                } else {
                    if(hrefLink != "" || hrefLink != "javascript://") {
                        document.location.href = hrefLink;
                    }
                }
                return false;
            }
        }
    });
}

function saveResponse(saveURL, formId) {
    $("a").bind("click", function() {
        if($(this).hasClass('ignorlink')) {
            return true;
        } else if($(this).hasClass('editQuotation')) {
            return true;
        } else {
            var hrefLink = $(this).attr("href");
            if(hrefLink != "" && hrefLink != "javascript://" && hrefLink != "#" && hrefLink != undefined) {
                $(".simple-tips").remove();
                if(formId == 'response_Step6') {
                    if(fileUploadCount != undefined) {
                        if(fileUploadCount > 0) {
                            $("#confirmationdiv").dialog({
                                width: 330,
                                height: 160,
                                modal: true,
                                title: "RFX Save",
                                open: function() {
                                    $("#confirmationdiv").html("<div align='center' style='padding: 10px'>File uploads are in progress. Upload progess will be stopped. Are you sure to navigate away?</a>");
                                },
                                buttons:
                                {
                                    "Yes": function() {
                                        if(hrefLink != "" || hrefLink != "javascript://") {
                                            document.location.href = hrefLink;
                                        }
                                    },
                                    "No": function() {
                                        $(this).dialog("close");
                                    }
                                }
                            });
                        } else {
                            if(hrefLink != "" || hrefLink != "javascript://") {
                                document.location.href = hrefLink;
                            }
                        }
                    }
                } else if(formchanges == true) {
                    var csrf_error='csrf_error';
                    $("#confirmationdiv").dialog({
                        width: 330,
                        height: 160,
                        modal: true,
                        title: "Save Response",
                        open: function() {
                            $("#confirmationdiv").html("<div align='center' style='padding: 10px'>Some modification has been done in the form. Do you want to save the changes ?</a>");
                        },
                        buttons:
                        {
                            "Yes": function() {
                                dialogbox = $(this);
                                $.ajax({
                                    type: 'POST',
                                    async: false,
                                    url: saveURL,
                                    data: $("#" + formId).serialize() +'&csrf_error='+csrf_error,
                                    success: function(response) {
                                         
//                                        if(response.indexOf("csrf") > -1){
//                                                            alert("Access Denied");
//                                                             dialogbox.dialog("close");
//                                                            return false;
//                                                            }
                                        jsondata = $.parseJSON(response);
                                        if(jsondata.type=='csrf'){
                                    
                                            alert(jsondata.Message);
                                            dialogbox.dialog("close");
                                            return false;
                                        }
                                        if(jsondata.type == 'false'){
                                            $(".simplebox").prepend('<div class="simple-tips albox  errorbox" style="z-index: 690;">'+jsondata.message+'<a class="close tips" href="#" original-title="Close">close</a></div>');
                                            $(".albox .close").click(function(event){
                                                $(this).parents(".albox").slideUp();
                                                return false;
                                            });
                                            dialogbox.dialog("close");

                                        } else{
                                            if(hrefLink != "" && hrefLink != "javascript://") {
                                                document.location.href = hrefLink;
                                            }
                                        }
                                    }
                                });
                            },
                            "No": function() {
                                $(this).dialog("close");
                                if(hrefLink != "" || hrefLink != "javascript://") {
                                    document.location.href = hrefLink;
                                }
                            }
                        }
                    });
                } else {
                    if(hrefLink != "" || hrefLink != "javascript://") {
                        document.location.href = hrefLink;
                    }
                }
                return false;
            }
        }
    });
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function preload(arrayOfImages) {
    $(arrayOfImages).each(function(){
        $('<img/>')[0].src = this;
    // Alternatively you could use:
    // (new Image()).src = this;
    });
}

function clockDisplay(dateObject) {
    // Create two variable with the names of the months and days in an array
    var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
    var dayNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

    var newDate = dateObject;
    // Extract the current date from Date object
    newDate.setDate(newDate.getDate());
    // Output the day, date, month and year
    $('#datediv').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

    setInterval( function() {
        // Create a newDate() object and extract the seconds of the current time on the visitor's
        var seconds = new Date().getSeconds();
        // Add a leading zero to seconds value
        $("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
    },1000);

    setInterval( function() {
        // Create a newDate() object and extract the minutes of the current time on the visitor's
        var minutes = new Date().getMinutes();
        // Add a leading zero to the minutes value
        $("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
    },1000);

    setInterval( function() {
        // Create a newDate() object and extract the hours of the current time on the visitor's
        var hours = new Date().getHours();
        // Add a leading zero to the hours value
        $("#hours").html(( hours < 10 ? "0" : "" ) + hours);
    }, 1000);
}
/**Function Added by Ashish Jain on 31-Dec-2013*/
$(function(){
	
    $(".onlyNumber").on("keypress keyup blur",function (event) {
        //this.value = this.value.replace(/[^0-9\.]/g,'');
        //$(this).val($(this).val().replace(/[^0-9\.]/g,''));
        if ((event.which != 0 ) && (event.which != 8 ) && ( event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }else{
            $(this).format({ type:'decimal', precision: 4, allow_negative: false, autofix:true });
        }
    });
//    $(".onlyNumber").each(function(){
//        $(this).format({ type:'decimal', precision: 20, allow_negative: false, autofix:true });
//    });
});
function setOnlyNumber(){
    $(".onlyNumber").on("keypress keyup blur",function (event) {
        //this.value = this.value.replace(/[^0-9\.]/g,'');
        //$(this).val($(this).val().replace(/[^0-9\.]/g,''));
        if ((event.which != 0 ) && (event.which != 8 ) &&( event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57 )) {
            event.preventDefault();
        }else{
            $(this).format({ type:'decimal', precision: 4, allow_negative: false, autofix:true });
        }
    });
//    $(".onlyNumber").each(function(){
//        $(this).format({ type:'decimal', precision: 20, allow_negative: false, autofix:true });
//    });
}

/**EOF Added by Ashish Jain on 31-Dec-2013*/